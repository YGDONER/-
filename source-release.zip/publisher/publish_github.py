#!/usr/bin/env python3
"""Verify local release assets and publish them using the Actions job token."""
import argparse
import hashlib
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def project_file(value):
    path = (ROOT / value).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        raise ValueError('Invalid project file: ' + str(value))
    return path


def verify_release():
    config = json.loads((ROOT / 'release.json').read_text(encoding='utf-8'))
    version = config['version']
    manifest = json.loads((ROOT / 'xhs-note-desk/manifest.json').read_text(encoding='utf-8'))
    if not re.fullmatch(r'\d+(?:\.\d+){0,3}', version) or version != manifest['version']:
        raise ValueError('Release version must match manifest.json')
    project_file(config['notes'])
    assets = []
    names = set()
    for item in config['assets']:
        path = project_file(item['path'])
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != item['sha256'] or path.name in names:
            raise ValueError('Release asset digest or name mismatch: ' + path.name)
        names.add(path.name)
        assets.append((path, digest))
        if path.suffix == '.zip':
            with zipfile.ZipFile(path) as archive:
                if archive.testzip():
                    raise ValueError('Invalid ZIP: ' + path.name)
                prefix = 'xhs-note-desk/' if 'xhs-note-desk/manifest.json' in archive.namelist() else ''
                packaged = {p[len(prefix):] for p in archive.namelist()
                            if not p.endswith('/') and p.startswith(prefix)}
                source = {p.relative_to(ROOT / 'xhs-note-desk').as_posix(): p
                          for p in (ROOT / 'xhs-note-desk').rglob('*') if p.is_file()}
                if packaged != set(source):
                    raise ValueError('ZIP extension files differ from source: ' + path.name)
                for name, original in source.items():
                    if archive.read(prefix + name) != original.read_bytes():
                        raise ValueError('ZIP source mismatch: ' + name)
        print('Verified', path.name, digest)
    expected = ''.join(f'{digest}  {path.name}\n' for path, digest in assets if path.suffix == '.zip')
    checksums = project_file('downloads/SHA256SUMS.txt').read_text(encoding='utf-8')
    if checksums != expected:
        raise ValueError('SHA256SUMS.txt does not match release ZIP files')
    return config, assets


def publish(config, assets):
    repository = os.environ.get('GITHUB_REPOSITORY', '')
    commit = os.environ.get('GITHUB_SHA', '')
    token = os.environ.get('GH_TOKEN', '')
    if (os.environ.get('GITHUB_ACTIONS') != 'true' or not token
            or not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository)
            or not re.fullmatch(r'[0-9a-f]{40}', commit)):
        raise ValueError('Publishing requires a GitHub Actions job token and commit SHA')
    base = 'https://api.github.com/repos/' + repository

    def request(method, url, payload=None, content_type='application/json', allow_missing=False):
        headers = {'Accept': 'application/vnd.github+json', 'Authorization': 'Bearer ' + token,
                   'X-GitHub-Api-Version': '2026-03-10', 'User-Agent': 'got-you-release',
                   'Content-Type': content_type}
        body = payload if isinstance(payload, bytes) else (
            json.dumps(payload).encode('utf-8') if payload is not None else None)
        try:
            with urllib.request.urlopen(urllib.request.Request(url, body, headers, method=method), timeout=120) as response:
                return json.load(response)
        except urllib.error.HTTPError as error:
            if allow_missing and error.code == 404:
                return None
            # Never print request headers or credentials.
            raise RuntimeError(f'GitHub API {method} failed with HTTP {error.code}') from None

    tag = 'v' + config['version']
    notes = project_file(config['notes']).read_text(encoding='utf-8')
    release = request('GET', base + '/releases/tags/' + tag, allow_missing=True)
    if release is None:
        release = request('POST', base + '/releases', {
            'tag_name': tag, 'target_commitish': commit,
            'name': config['name'], 'body': notes, 'draft': True, 'prerelease': False})
    if release.get('draft') and release.get('target_commitish') != commit:
        raise ValueError('Existing draft belongs to another commit; inspect it before publishing')
    existing = {a['name']: a for a in request('GET', base + f"/releases/{release['id']}/assets?per_page=100")}
    for path, digest in assets:
        item = existing.get(path.name)
        if item:
            if item.get('digest') != 'sha256:' + digest or item['size'] != path.stat().st_size:
                raise ValueError('Existing release asset differs: ' + path.name)
            continue
        if not release['draft']:
            raise ValueError('Published release is missing an expected asset; inspect it before modifying')
        url = (f"https://uploads.github.com/repos/{repository}/releases/{release['id']}/assets?"
               + urllib.parse.urlencode({'name': path.name}))
        item = request('POST', url, path.read_bytes(),
                       'application/zip' if path.suffix == '.zip' else 'text/plain')
        if item.get('digest') != 'sha256:' + digest or item['size'] != path.stat().st_size:
            raise ValueError('Uploaded release asset failed verification: ' + path.name)
    if release['draft']:
        release = request('PATCH', base + f"/releases/{release['id']}",
                          {'draft': False, 'make_latest': 'true'})
    print('Published:', release['html_url'])
    summary = os.environ.get('GITHUB_STEP_SUMMARY')
    if summary:
        with open(summary, 'a', encoding='utf-8') as output:
            output.write(f"## {config['name']}\n\n[打开版本与下载页]({release['html_url']})\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Only verify files; no network or credentials')
    args = parser.parse_args()
    config, assets = verify_release()
    if not args.check:
        publish(config, assets)


if __name__ == '__main__':
    main()
