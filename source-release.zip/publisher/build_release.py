#!/usr/bin/env python3
"""Build complete local-install and store-upload archives using Python stdlib only."""
import argparse, hashlib, json, re, shutil, tempfile, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'xhs-note-desk' if (ROOT / 'xhs-note-desk').is_dir() else ROOT / 'extension'
def version(value):
    if not re.fullmatch(r'\d+(?:\.\d+){0,3}', value or ''):
        raise argparse.ArgumentTypeError('版本格式：4.1.1（1–4 段数字）')
    nums = tuple(map(int, value.split('.')))
    if not any(nums) or any(n > 65535 for n in nums) or any(len(p)>1 and p.startswith('0') for p in value.split('.')):
        raise argparse.ArgumentTypeError('版本段必须在 0–65535，不能全为零或有前导零')
    return value

def archive(folder, output, prefix=''):
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file():
                z.write(p, prefix+p.relative_to(folder).as_posix())
    with zipfile.ZipFile(output) as z:
        if z.testzip(): raise RuntimeError('ZIP 校验失败')

def validate(ext):
    m=json.loads((ext/'manifest.json').read_text(encoding='utf-8'))
    paths=[m['background']['service_worker'],m['action']['default_popup'],m['options_page'],*m['icons'].values()]
    for cs in m.get('content_scripts',[]): paths.extend(cs.get('js',[]))
    for rel in paths:
        if not (ext/rel).is_file(): raise RuntimeError('缺少文件：'+rel)
    for p in ext.glob('*.js'):
        text=p.read_text(encoding='utf-8')
        for rel in re.findall(r"from ['\"](\.[^'\"]+)['\"]",text):
            if not (p.parent/rel).is_file(): raise RuntimeError('缺少模块：'+rel)
    if any('qa-chrome' in p.name for p in ext.rglob('*')): raise RuntimeError('不能包含 QA 桩')
    html=(ext/'app.html').read_text(encoding='utf-8');ids=set(re.findall(r'id="([^\"]+)"',html))
    used=set()
    for name in ['app.js','workspace-tools.js','note-gallery.js','visual-ui.js']: used.update(re.findall(r"\$\('([^']+)'\)",(ext/name).read_text(encoding='utf-8')))
    if used-ids: raise RuntimeError('缺少界面元素：'+str(used-ids))
    return m

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version',type=version)
    parser.add_argument('--previous',type=version)
    parser.add_argument('--out',type=Path,default=ROOT/'dist')
    args=parser.parse_args();current=validate(SOURCE)['version'];target=args.version or current
    if args.previous:
        key=lambda x:tuple(map(int,x.split('.')))+(0,)*(4-len(x.split('.')))
        if key(target)<=key(args.previous): parser.error('新版本必须大于 --previous')
    args.out.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='link-note-build-') as temp:
        stage=Path(temp);ext=stage/'xhs-note-desk'
        shutil.copytree(SOURCE,ext,ignore=shutil.ignore_patterns('legacy-metadata.js','__pycache__','*.map','package.json'))
        manifest=json.loads((ext/'manifest.json').read_text(encoding='utf-8'));manifest['version']=target
        (ext/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        for p in ext.iterdir():
            if p.suffix in ['.html','.js']:
                p.write_text(p.read_text(encoding='utf-8').replace(current,target),encoding='utf-8')
        validate(ext)
        store=args.out/f'got-you-store-v{target}.zip';archive(ext,store)
        guide=ROOT/'发布资料'/'安装与更新.txt'
        if guide.exists(): (stage/'安装说明.txt').write_text(guide.read_text(encoding='utf-8').replace(current,target),encoding='utf-8')
        install=args.out/f'got-you-v{target}.zip';archive(stage,install)
    sums=[]
    for p in [install,store]:
        digest=hashlib.sha256(p.read_bytes()).hexdigest();sums.append(digest+'  '+p.name);print(p)
    (args.out/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n',encoding='utf-8')
if __name__=='__main__': main()
