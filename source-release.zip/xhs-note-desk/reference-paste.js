// Reads only a paste event initiated by the user. No clipboard-read permission or polling.
export function clipboardImageFile(data){
 for(const item of Array.from(data?.items||[])){if(item.kind==='file'&&item.type?.startsWith('image/')){const file=item.getAsFile();if(file)return file;}}
 return Array.from(data?.files||[]).find(file=>file.type?.startsWith('image/'))||null;
}
export function installReferencePaste({target,isEnabled,onImage}){
 const onPaste=event=>{if(event.defaultPrevented||!isEnabled())return;const file=clipboardImageFile(event.clipboardData);if(!file)return;event.preventDefault();onImage(file);};
 target.addEventListener('paste',onPaste);return ()=>target.removeEventListener('paste',onPaste);
}
