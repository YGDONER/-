import {VISUAL_ENGINES,selectedPlatforms,visualContext,engineHost,scopedVisualUrl,validateReference,mergeVisualCandidates,candidateWork} from './visual-core.js';
import {submitReferenceImage,collectVisualPage} from './visual-page.js';
import {transact,latestState} from './database.js';
import {uid,mergeWorks,workKey} from './core.js';
let initialized=false;const running=new Set();
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function init(){if(initialized)return;initialized=true;await transact(s=>{const v=s.visualSearch;if(v?.state==='running'){v.state='attention';for(const t of v.tasks)if(['pending','processing'].includes(t.state)){t.state='attention';t.error='浏览器后台已恢复，请点击继续收集';}}});}
async function edit(id,fn){return transact(s=>{if(s.visualSearch?.id===id)return fn(s.visualSearch,s);});}
async function current(id){const v=(await latestState()).visualSearch;if(v?.id!==id||v.state==='cancelled')throw new Error('检索已停止');return v;}
function settle(v){if(v.state==='cancelled')return;if(v.tasks.some(t=>['pending','processing'].includes(t.state))){v.state='running';return;}v.state=v.tasks.some(t=>t.state==='attention')?'attention':'completed';}
async function waitTab(tabId,id){for(let i=0;i<60;i++){await current(id);const t=await chrome.tabs.get(tabId);if(t.status==='complete')return t;await delay(400);}throw new Error('搜索页加载超时，可打开搜索页后继续收集');}
async function readPage(tabId){const [r]=await chrome.scripting.executeScript({target:{tabId},func:collectVisualPage});if(!r?.result)throw new Error('没有读取到搜索页内容');return r.result;}
async function waitResults(id,task){for(let n=0;n<45;n++){const v=await current(id),tab=await chrome.tabs.get(task.tabId);if(!engineHost(tab.url,v.engine))throw new Error('搜索标签页已跳转到其他网站，请重新开始检索');
  try{const data=await readPage(task.tabId);if(data.blocked)throw Object.assign(new Error(data.message),{stop:true});const context=visualContext(tab.url,v.engine);if(context&&(data.candidates?.length||data.empty||n>=10&&data.ready))return {data,context};}catch(e){if(e.stop||/权限|permission|Cannot access|not allowed/i.test(e.message))throw e;}
  await delay(700);
 }throw new Error('搜索页尚未返回图像结果，请打开搜索页检查，再继续收集');}
async function processTask(id,task){let v=await current(id),tab;
 if(task.tabId){try{tab=await chrome.tabs.get(task.tabId);}catch{throw new Error('搜索标签页已关闭，请重新检索参考素材');}}
 else{tab=await chrome.tabs.create({url:task.url||VISUAL_ENGINES[v.engine].home,active:false});task.tabId=tab.id;await edit(id,x=>{x.tasks.find(t=>t.id===task.id).tabId=tab.id;});}
 await waitTab(tab.id,id);v=await current(id);tab=await chrome.tabs.get(tab.id);if(!engineHost(tab.url,v.engine))throw new Error('搜索标签页已跳转到其他网站，未传送参考图');
 if(task.kind==='reference'&&!visualContext(tab.url,v.engine)){
  const saved=(await chrome.storage.local.get('visualReferenceV4')).visualReferenceV4,frame=saved?.id===v.referenceId?saved.frames.find(f=>f.id===task.frameId):null;
  if(!frame)throw new Error('本机参考画面已移除，请重新上传');
  const [r]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:submitReferenceImage,args:[{engine:v.engine,dataUrl:frame.dataUrl}]});if(!r?.result?.submitted)throw new Error(r?.result?.message||'搜索服务尚未接收参考图，请打开搜索页检查');
 }
 const {data,context}=await waitResults(id,task);await current(id);
 await edit(id,x=>{const t=x.tasks.find(t=>t.id===task.id);if(!t)return;t.state='completed';t.context=context;t.error='';
  if(task.kind==='reference'){
   // Upload pages establish the image context only. Never import their broad results.
   t.count=0;
   if(!t.scopesCreated){t.scopesCreated=true;for(const platform of x.platforms)x.tasks.push({id:uid(),kind:'scope',platform,frameId:task.frameId,time:task.time,url:scopedVisualUrl(context,x.engine,platform,x.keyword),state:'pending',count:0,error:''});}
  }else{
   if(!x.platforms.includes(task.platform))throw new Error('检索任务不属于本次所选平台');
   x.results=mergeVisualCandidates(x.results,data.candidates||[],task.frameId,[task.platform]);
   t.count=mergeVisualCandidates([],data.candidates||[],task.frameId,[task.platform]).length;
  }
  if(data.query&&!x.detectedQuery)x.detectedQuery=data.query.slice(0,150);settle(x);
 });
}
async function pump(id){if(running.has(id))return;running.add(id);try{async function worker(){while(true){let task;await edit(id,v=>{if(v.state==='cancelled')return;const next=v.tasks.find(t=>t.state==='pending');if(next){next.state='processing';task={...next};}});if(!task)return;try{await processTask(id,task);}catch(e){await edit(id,v=>{if(v.state==='cancelled')return;const t=v.tasks.find(x=>x.id===task.id);if(t){t.state='attention';t.error=e.message||'图片检索失败';}settle(v);});}}}await Promise.all([worker(),worker()]);await edit(id,settle);}finally{running.delete(id);}}

export async function handleVisualMessage(m){await init();
 switch(m.type){
 case 'VISUAL_START':{
  const engine=m.engine||'bing',config=VISUAL_ENGINES[engine];if(!config)throw new Error('请选择有效的图片搜索服务');if(!await chrome.permissions.contains({origins:config.origins}))throw new Error('请先允许访问所选图片搜索服务');
  const reference=validateReference(m.reference,m.frameIds),platforms=selectedPlatforms(m.platforms,m.mode||'multi');
  const id=uid();await chrome.storage.local.set({visualReferenceV4:reference});const result=await transact(s=>{s.visualSearch={id,referenceId:reference.id,name:reference.name,type:reference.type,engine,platforms,keyword:String(m.keyword||'').trim().slice(0,100),scopeVersion:2,mode:m.mode==='single'?'single':'multi',state:'running',createdAt:Date.now(),results:[],tasks:reference.frames.map((f,i)=>({id:uid(),kind:'reference',frameId:f.id,time:f.time,primary:i===0,state:'pending',count:0,error:''})),expanded:false};return {visualId:id};});void pump(id);return result;
 }
 case 'VISUAL_CONTINUE':{const v=(await latestState()).visualSearch;if(!v)throw new Error('还没有参考检索任务');if(running.has(v.id))throw new Error('检索仍在运行，请稍候');if(v.scopeVersion!==2)throw new Error('这是旧版检索任务，请重新点击开始以使用指定平台检索');if(v.state==='cancelled')throw new Error('任务已停止，请重新开始检索');await edit(v.id,x=>{for(const t of x.tasks)if(t.state==='attention'){t.state='pending';t.error='';}settle(x);});void pump(v.id);return {state:await latestState()};}
 case 'VISUAL_CANCEL':return transact(s=>{const v=s.visualSearch;if(v){v.state='cancelled';for(const t of v.tasks)if(['pending','processing'].includes(t.state))t.state='cancelled';}});
 case 'VISUAL_CLEAR':{await chrome.storage.local.remove('visualReferenceV4');return transact(s=>{s.visualSearch=null;});}
 case 'VISUAL_IMPORT':return transact(s=>{const v=s.visualSearch;if(!v||m.visualId!==v.id)throw new Error('检索结果已变化，请重新选择');const candidates=v.results.filter(x=>m.ids?.includes(x.id));if(!candidates.length)throw new Error('请先勾选需要收录的候选');const category=String(m.category||'灵感参考').trim().slice(0,32)||'灵感参考';const merged=mergeWorks(s.works,candidates.map(x=>candidateWork(x,category)));s.works=merged.works;if(!s.categories.includes(category))s.categories.push(category);return {added:merged.added,merged:merged.merged,workIds:candidates.map(c=>s.works.find(w=>workKey(w.url)===workKey(c.url)).id)};});
 default:throw new Error('相似检索操作无效');
 }
}
export async function restoreVisualJobs(){await init();}
