// These functions run in the selected search page. They must have no module dependencies.
export async function submitReferenceImage({engine,dataUrl}){
 const host=location.hostname;if(location.protocol!=='https:'||!(engine==='bing'?(host==='bing.com'||host.endsWith('.bing.com')):['www.google.com','lens.google.com'].includes(host)))throw new Error('搜索标签页已离开图片搜索网站，停止传送参考图');
 const body=(document.body?.innerText||'').slice(0,18000);
 if(/\/sorry|captcha|challenge/i.test(location.pathname)||/unusual traffic|verify you are human|人机验证|安全验证/i.test(document.title+' '+body))return {submitted:false,message:'搜索服务需要验证，请打开搜索页处理后点击继续收集'};
 if(document.querySelector('#bnp_container')?.getBoundingClientRect().height>0||location.hostname==='consent.google.com')return {submitted:false,message:'请打开搜索页处理 Cookie 选项，再继续搜索'};
 const trigger=engine==='bing'?document.querySelector('#sb_sbi'):document.querySelector('[aria-label="Search by image"],[aria-label="按图搜索"],[aria-label="以图搜图"],[aria-label="使用图片搜索"],[aria-label="使用图像搜索"]');
 if(trigger)trigger.click();
 let input;for(let n=0;n<20;n++){input=document.querySelector(engine==='bing'?'#sb_fileinput':'input[type="file"][name="encoded_image"],input[type="file"]');if(input)break;await new Promise(r=>setTimeout(r,150));}
 if(!input)return {submitted:false,message:'图片搜索上传入口发生变化，请在打开的搜索页手动上传参考图，再点击继续收集'};
 const match=dataUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);if(!match)throw new Error('参考图片格式无效');const raw=atob(match[2]),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0)),file=new File([bytes],'reference.'+(match[1]==='image/png'?'png':match[1]==='image/webp'?'webp':'jpg'),{type:match[1]});const transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;input.dispatchEvent(new Event('change',{bubbles:true}));return {submitted:true};
}

export function collectVisualPage(){
 const safe=(raw,base=location.href)=>{try{if(typeof raw!=='string'||!raw.trim())return '';const u=new URL(raw,base);return /^https?:$/.test(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}};
 const body=(document.body?.innerText||'').slice(0,22000),title=document.title||'';
 if(/\/sorry|captcha|challenge/i.test(location.pathname)||/unusual traffic|verify you are human|人机验证|安全验证/i.test(title+' '+body))return {blocked:true,message:'搜索服务需要验证，请打开搜索页处理后继续收集',candidates:[]};
 if(document.querySelector('#bnp_container')?.getBoundingClientRect().height>0||location.hostname==='consent.google.com')return {blocked:true,message:'请在搜索页处理 Cookie 选项后继续收集',candidates:[]};
 const candidates=[],seen=new Set();
 function unwrap(raw){let url=safe(raw);for(let n=0;n<3&&url;n++){const u=new URL(url),engine=/^(?:www\.)?(?:bing|google)\.com$/.test(u.hostname);if(!engine)break;let next=u.searchParams.get('imgrefurl')||u.searchParams.get('purl')||u.searchParams.get('url');if(!next&&u.pathname==='/url')next=u.searchParams.get('q');if(!next&&u.pathname==='/ck/a'){const enc=u.searchParams.get('u');if(enc?.startsWith('a1'))try{const b64=enc.slice(2).replace(/-/g,'+').replace(/_/g,'/');next=decodeURIComponent(escape(atob(b64)));}catch{}}if(!next)break;url=safe(next);}return url;}
 for(const a of document.querySelectorAll('a[href]')){
  let metadata={};try{metadata=JSON.parse(a.getAttribute('m')||'{}');}catch{}
  const href=safe(a.href||a.getAttribute('href'));if(!href)continue;const link=new URL(href),url=unwrap(metadata.purl||metadata.surl||href);if(!url)continue;const u=new URL(url);if(/(?:^|\.)(?:google|bing)\.com$/.test(u.hostname))continue;
  const image=a.querySelector('img'),card=a.closest('[data-ved],.isv-r,.imgpt,li,.b_algo')||a,near=image||card.querySelector('img');const imageUrl=safe(metadata.murl||link.searchParams.get('mediaurl')||link.searchParams.get('imgurl')||''),rawThumb=near?.currentSrc||near?.src||metadata.turl||imageUrl||'',thumbnail=safe(rawThumb)||(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(rawThumb)&&rawThumb.length<250000?rawThumb:'');
  // Skip navigation, account links and ordinary text results. A candidate needs image evidence.
  if(!imageUrl&&!thumbnail)continue;const key=url+'|'+imageUrl;if(seen.has(key))continue;seen.add(key);
  const label=String(metadata.t||a.getAttribute('aria-label')||a.getAttribute('title')||near?.alt||a.innerText||'').replace(/[\uE000-\uF8FF]/g,'').trim();candidates.push({url,title:label||u.hostname,thumbnail,imageUrl});if(candidates.length>=150)break;
 }
 const u=new URL(location.href),query=u.searchParams.get('q')||document.querySelector('input[name="q"],textarea[name="q"]')?.value||'';
 return {candidates,query,message:candidates.length?'已读取搜索服务返回的图片候选':'当前页暂未读取到图片候选',ready:document.readyState==='complete',empty:/no results|没有找到|未找到|找不到.*结果/i.test(body)};
}
