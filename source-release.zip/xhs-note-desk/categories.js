import {CATEGORIES} from './core.js';
export function categoryName(value){const s=String(value||'').replace(/[\r\n\t]+/g,' ').trim();if(!s||s.length>32)throw new Error('分类名称需为 1–32 个字');return s;}
export function resolveCategory(state,name){const aliases=state.settings.categoryAliases||{};let current=name||'未分类';const seen=new Set();while(aliases[current]&&!seen.has(current)){seen.add(current);current=aliases[current];}return current;}
export function applyCategoryRules(state){for(const w of state.works){w.category=resolveCategory(state,w.category);if(!state.categories.includes(w.category))state.categories.push(w.category);}}
export function changeCategory(state,m){const action=m.action,name=categoryName(m.name);if(action==='add'){if(!state.categories.includes(name))state.categories.push(name);if(state.settings.categoryAliases)delete state.settings.categoryAliases[name];return;}
 if(action==='assign'){for(const w of state.works)if(m.ids?.includes(w.id)){w.category=name;w.updatedAt=Date.now();}if(!state.categories.includes(name))state.categories.push(name);return;}
 if(!['rename','delete'].includes(action))throw new Error('分类操作无效');if(name==='未分类')throw new Error('请保留“未分类”作为默认分类');
 const next=action==='delete'?'未分类':categoryName(m.newName);if(next===name)return;
 for(const w of state.works)if(w.category===name)w.category=next;
 state.categories=state.categories.filter(c=>c!==name);if(!state.categories.includes(next))state.categories.push(next);
 const aliases=state.settings.categoryAliases||{};for(const key of Object.keys(aliases))if(aliases[key]===name)aliases[key]=next;aliases[name]=next;state.settings.categoryAliases=aliases;
}
