import {PLATFORMS,httpUrl,platformOf,isDetail,workKey} from './core.js';

export const VISUAL_ENGINES={
 bing:{name:'Bing 视觉搜索',home:'https://www.bing.com/images',origins:['https://*.bing.com/*']},
 google:{name:'Google Lens',home:'https://www.google.com/imghp?hl=zh-CN',origins:['https://www.google.com/*','https://lens.google.com/*']}
};
export const VISUAL_SITES={pinterest:'site:pinterest.com',xhs:'(site:xiaohongshu.com OR site:xhslink.com)',douyin:'site:douyin.com',taobao:'(site:taobao.com OR site:tb.cn)',tmall:'site:tmall.com',pdd:'(site:yangkeduo.com OR site:pinduoduo.com)',vip:'site:vip.com'};
export function engineHost(raw,engine){try{const u=new URL(raw);return u.protocol==='https:'&&(engine==='bing'?(u.hostname==='bing.com'||u.hostname.endsWith('.bing.com')):engine==='google'&&['www.google.com','lens.google.com'].includes(u.hostname));}catch{return false;}}
export function visualContext(raw,engine){if(!engineHost(raw,engine))return '';const u=new URL(raw);if(/\/sorry|challenge|captcha/i.test(u.pathname))return '';const has=engine==='bing'?!!u.searchParams.get('bcid')||u.searchParams.get('iss')==='sbi'&&!!u.searchParams.get('imageBin'):!!u.searchParams.get('vsrid')||u.hostname==='lens.google.com'&&!!u.searchParams.get('p');return has?u.href:'';}
export function selectedPlatforms(raw,mode='multi'){
 if(!Array.isArray(raw))throw new Error('请先选择搜索平台');const allowed=new Set(PLATFORMS.map(p=>p.id));const platforms=[...new Set(raw.filter(p=>allowed.has(p)))];if(!platforms.length)throw new Error('请至少选择一个平台');if(mode==='single'&&platforms.length!==1)throw new Error('指定平台模式只能选择一个平台');return platforms;
}
export function scopedVisualUrl(raw,engine,platform,keyword=''){
 const base=visualContext(raw,engine);if(!base)throw new Error('搜索页面没有图像上下文，不能替换成普通关键词搜索');if(!VISUAL_SITES[platform]&&platform!=='web')throw new Error('搜索平台无效');const u=new URL(base),prior=u.searchParams.get('q')||'';
 const clean=String(keyword||prior).replace(/\(?site:[\w.]+(?:\s+OR\s+site:[\w.]+)*\)?/gi,'').replace(/["“”\r\n\t]/g,' ').replace(/\s+/g,' ').trim().slice(0,100);
 u.searchParams.set('q',[VISUAL_SITES[platform]||'',clean?'"'+clean+'"':''].filter(Boolean).join(' '));if(engine==='bing')u.searchParams.set('vsa','2');return u.href;
}
export function validateReference(reference,frameIds){if(!Array.isArray(frameIds))throw new Error('请选择参考画面');if(!reference||typeof reference.id!=='string'||!reference.id||!Array.isArray(reference.frames))throw new Error('请先上传参考图片或视频');const chosen=reference.frames.filter(f=>frameIds?.includes(f.id));if(!chosen.length||chosen.length>3)throw new Error('请选择 1–3 个参考画面');let bytes=0;const frames=chosen.map(f=>{if(typeof f.dataUrl!=='string'||!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(f.dataUrl)||f.dataUrl.length>1400000)throw new Error('参考画面无效或过大，请重新选择文件');bytes+=f.dataUrl.length;return {id:String(f.id).slice(0,100),dataUrl:f.dataUrl,time:Math.max(0,Number(f.time)||0),width:Math.max(1,Number(f.width)||1),height:Math.max(1,Number(f.height)||1)};});if(bytes>3500000)throw new Error('参考画面总量过大，请减少画面');return {id:reference.id.slice(0,100),name:String(reference.name||'参考素材').slice(0,180),type:reference.type==='video'?'video':'image',frames};}
export function frameTimes(duration,count=5){if(!Number.isFinite(duration)||duration<=0)throw new Error('无法读取视频时长，请更换浏览器可播放的文件');const size=Math.max(1,Math.min(8,Number(count)||5));return Array.from({length:size},(_,i)=>Math.max(0,Math.min(Math.max(0,duration-.001),duration*(i+1)/(size+1))));}
function previewDataUrl(url){return typeof url==='string'&&url.length<250000&&/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(url)?url:'';}
export function candidateKey(x){return workKey(x.url);}
export function mergeVisualCandidates(old,incoming,frameId,platforms){
 const out=old.map(x=>({...x,frameIds:[...x.frameIds]}));let previewBytes=out.reduce((n,x)=>n+(x.thumbnail?.startsWith('data:')?x.thumbnail.length:0),0);
 for(const x of incoming.slice(0,150)){const url=httpUrl(x.url);if(!url)continue;const platform=platformOf(url);if(!platforms.includes(platform)||platform!=='web'&&!isDetail(url))continue;const key=candidateKey({url}),prior=out.find(a=>a.key===key);if(prior){if(!prior.frameIds.includes(frameId))prior.frameIds.push(frameId);if(!prior.imageUrl)prior.imageUrl=httpUrl(x.imageUrl);if(!prior.thumbnail)prior.thumbnail=httpUrl(x.thumbnail)||httpUrl(x.imageUrl);continue;}
 let thumbnail=httpUrl(x.thumbnail)||previewDataUrl(x.thumbnail)||httpUrl(x.imageUrl);if(thumbnail.startsWith('data:')){if(previewBytes+thumbnail.length>512000)thumbnail=httpUrl(x.imageUrl);else previewBytes+=thumbnail.length;}
 out.push({id:key,key,url,platform,title:String(x.title||'未命名候选').slice(0,300),user:'',imageUrl:httpUrl(x.imageUrl),thumbnail,frameIds:[frameId],method:'visual',rank:out.length});if(out.length>=400)break;
 }return out.slice(0,400);
}
export function candidateWork(candidate,category='灵感参考'){const preview=httpUrl(candidate.thumbnail)||httpUrl(candidate.imageUrl);return {url:candidate.url,title:candidate.title,user:'',category,source:'visual-search',media:preview?[{url:preview,kind:'cover'}]:[]};}
