#!/usr/bin/env python3
"""Inspect the actual installation ZIP; this is not an antivirus verdict."""
import hashlib, json, re, sys, zipfile
from html.parser import HTMLParser
from pathlib import PurePosixPath, Path

class PageAudit(HTMLParser):
    def __init__(self):
        super().__init__(); self.in_script = False; self.sources = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in {'iframe', 'embed', 'object', 'base'}: raise ValueError('Active embedded content: '+tag)
        if any(k.lower().startswith('on') for k in attrs): raise ValueError('Inline event handler')
        if tag == 'script':
            src = attrs.get('src', '')
            if not src or ':' in src or src.startswith('/'): raise ValueError('Non-local script')
            self.sources.append(src); self.in_script = True
    def handle_endtag(self, tag):
        if tag == 'script': self.in_script = False
    def handle_data(self, data):
        if self.in_script and data.strip(): raise ValueError('Inline script')

def audit(path):
    data=path.read_bytes()
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        names=z.namelist()
        for n in names:
            p=PurePosixPath(n)
            if p.is_absolute() or '..' in p.parts or '\\' in n: raise ValueError('Unsafe archive path')
            if p.suffix.lower() not in {'.js','.json','.html','.css','.png','.txt'}: raise ValueError('Unexpected file type: '+n)
        root='xhs-note-desk/'
        m=json.loads(z.read(root+'manifest.json'))
        assert m['manifest_version']==3
        assert set(m['permissions'])=={'activeTab','scripting','storage','clipboardWrite','downloads'}
        assert 'https://*.instagram.com/*' in m['host_permissions']
        assert not m.get('externally_connectable') and not m.get('sandbox')
        policy={parts[0]:parts[1:] for rule in m['content_security_policy']['extension_pages'].split(';') if (parts:=rule.strip().split())}
        assert policy['script-src']==["'self'"]
        for key in ['connect-src','object-src','frame-src','base-uri','form-action']: assert policy[key]==["'none'"]
        scripts=[]; pages=[]
        for n in names:
            if n.endswith('.js'):
                source=z.read(n).decode('utf-8')
                if re.search(r'\b(?:eval|Function)\s*\(|\bimport\s*\(|\.acceptDanger\s*\(',source): raise ValueError('Dynamic code or unsafe download acceptance: '+n)
                for ref in re.findall(r'\bfrom\s+[\'\"]([^\'\"]+)[\'\"]',source):
                    if not ref.startswith('./') or root+ref[2:] not in names: raise ValueError('Non-local module import: '+ref)
                scripts.append(n)
            elif n.endswith('.html'):
                page=PageAudit();page.feed(z.read(n).decode('utf-8'))
                for src in page.sources: assert root+src in names
                pages.append(n)
    return {'package':path.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'version':m['version'],'files':len(names),'local_scripts':len(scripts),'pages':len(pages),'static_package_audit':'passed','antivirus_result':'not established by this static audit'}

if __name__=='__main__':
    print(json.dumps(audit(Path(sys.argv[1])),ensure_ascii=False,indent=2))
