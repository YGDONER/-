import test from "node:test";
import assert from "node:assert/strict";
let storage = {},
  nextId = 1,
  items = new Map(),
  listeners = [];
const copy = (x) => structuredClone(x);
globalThis.chrome = {
  storage: {
    local: {
      get: async () => copy(storage),
      set: async (x) => Object.assign(storage, copy(x)),
    },
  },
  downloads: {
    download: async (o) => {
      const id = nextId++;
      items.set(id, {
        id,
        ...o,
        state: "in_progress",
        bytesReceived: 0,
        totalBytes: 1000,
        mime: "image/jpeg",
        paused: false,
      });
      return id;
    },
    search: async ({ id }) => (items.has(id) ? [copy(items.get(id))] : []),
    pause: async (id) => {
      items.get(id).paused = true;
    },
    resume: async (id) => {
      items.get(id).paused = false;
    },
    cancel: async (id) => {
      items.get(id).state = "interrupted";
      items.get(id).error = "USER_CANCELED";
    },
    onChanged: { addListener: (f) => listeners.push(f) },
    onErased: { addListener() {} },
  },
};
const { transact, latestState } = await import("../extension/database.js");
const { normalizeWork } = await import("../extension/core.js");
const { enqueueWorks, pump, updateDownload, controlDownloads } = await import(
  "../extension/downloads.js"
);
const wait = async () => {
  for (let i = 0; i < 10; i++) await new Promise((r) => setImmediate(r));
};
await test("migration preserves old accountName", async () => {
  storage = {
    notes: [
      {
        url: "https://www.xiaohongshu.com/explore/abc",
        title: "旧作品",
        accountName: "老博主",
      },
    ],
  };
  const s = await latestState();
  assert.equal(s.works[0].user, "老博主");
  await transact(() => {});
  assert.equal(storage.catalogV2.version, 2);
});
await test("concurrent transactions retain all changes", async () => {
  await Promise.all(
    Array.from({ length: 10 }, (_, i) =>
      transact((s) => {
        s.categories.push("test" + i);
      }),
    ),
  );
  assert.equal(
    (await latestState()).categories.filter((c) => c.startsWith("test")).length,
    10,
  );
});
await test("queue concurrency, deduplication, actual completion, pause and cancellation", async () => {
  const w = normalizeWork({
    url: "https://www.pinterest.com/pin/123/",
    media: [0, 1, 2, 3].map((i) => ({
      url: `https://i.test/${i}.jpg`,
      kind: "image",
    })),
  });
  await transact((s) => {
    s.works = [w];
    s.downloads = [];
    s.settings = { concurrency: 2, includeCovers: false };
  });
  let r = await enqueueWorks([w.id], false);
  assert.equal(r.queued, 4);
  await wait();
  let s = await latestState();
  assert.equal(s.downloads.filter((j) => j.state === "in_progress").length, 2);
  assert.equal(s.downloads.filter((j) => j.state === "completed").length, 0);
  assert.ok(s.downloads[0].downloadId > 0);
  r = await enqueueWorks([w.id], false);
  assert.equal(r.queued, 0);
  assert.equal(r.skipped, 4);
  await wait();
  await controlDownloads("pause");
  await wait();
  s = await latestState();
  assert.equal(s.settings.paused, true);
  assert.equal(s.downloads.filter((j) => j.state === "paused").length, 2);
  await controlDownloads("resume");
  await wait();
  s = await latestState();
  const first = s.downloads[0];
  items.get(first.downloadId).state = "complete";
  items.get(first.downloadId).bytesReceived = 1000;
  await updateDownload(first.downloadId);
  await pump();
  s = await latestState();
  assert.equal(s.downloads[0].state, "completed");
  assert.equal(s.downloads.filter((j) => j.state === "in_progress").length, 2);
  const active = s.downloads.find((j) => j.state === "in_progress");
  await controlDownloads("cancel", [active.id]);
  assert.equal(
    (await latestState()).downloads.find((j) => j.id === active.id).state,
    "cancelled",
  );
});
await test("HTML response is failure; retry updates expired URL from re-parsed asset", async () => {
  let s = await latestState(),
    j = s.downloads.find((j) => j.state === "in_progress");
  items.get(j.downloadId).state = "complete";
  items.get(j.downloadId).mime = "text/html";
  await updateDownload(j.downloadId);
  s = await latestState();
  assert.equal(s.downloads.find((x) => x.id === j.id).state, "failed");
  await controlDownloads("pause");
  await transact((s) => {
    const index = Number(j.assetKey.split(":").at(-1));
    s.works[0].media[index].url = "https://i.test/new.jpg?token=fresh";
  });
  await controlDownloads("retry", [j.id]);
  s = await latestState();
  const fresh = s.downloads.find((x) => x.id === j.id);
  assert.equal(fresh.state, "pending");
  assert.equal(fresh.url, "https://i.test/new.jpg?token=fresh");
  assert.equal(fresh.downloadId, null);
});
await test("missing browser record becomes failed rather than stuck", async () => {
  await transact((s) => {
    s.downloads.push({ id: "missing", downloadId: 999, state: "in_progress" });
  });
  await updateDownload(999);
  assert.equal(
    (await latestState()).downloads.find((x) => x.id === "missing").state,
    "failed",
  );
});
