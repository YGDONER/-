import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import {
  collectVisualPage,
  submitReferenceImage,
} from "../extension/visual-page.js";
const cardAnchor = (url, src = "https://i.test/photo.jpg") => ({
  href: url,
  textContent: "笔记",
  getAttribute: () => "",
  closest: () => null,
  querySelector: () => ({ src, alt: "参考图" }),
});
function collect({
  url = "https://www.xiaohongshu.com/search_result?image_id=SYNTHETIC",
  body = "",
  anchors = [],
  imageMarker = false,
} = {}) {
  const document = {
    title: "原生图片搜索",
    readyState: "complete",
    body: { innerText: body },
    querySelector: (s) =>
      imageMarker && s.includes("visual-search-results") ? {} : null,
    querySelectorAll: () => anchors,
  };
  return vm.runInNewContext(
    `(${collectVisualPage.toString()})({platform:'xhs'})`,
    { document, location: new URL(url), URL },
  );
}
test("native result collector returns same-platform source links and actual thumbnails", () => {
  const r = collect({
    anchors: [
      cardAnchor("https://www.xiaohongshu.com/explore/abc"),
      cardAnchor("https://www.pinterest.com/pin/123/"),
    ],
  });
  assert.equal(r.imageContext, true);
  assert.equal(r.candidates.length, 1);
  assert.equal(r.candidates[0].url, "https://www.xiaohongshu.com/explore/abc");
  assert.equal(r.candidates[0].imageUrl, "https://i.test/photo.jpg");
});
test("a homepage with attractive recommendations is never treated as image search", () => {
  const r = collect({
    url: "https://www.xiaohongshu.com/explore",
    anchors: [cardAnchor("https://www.xiaohongshu.com/explore/abc")],
  });
  assert.equal(r.imageContext, false);
  assert.equal(r.candidates.length, 0);
});
test("ordinary keyword search is never substituted for reference image search", () => {
  const r = collect({
    url: "https://www.xiaohongshu.com/search_result?keyword=cat",
    anchors: [cardAnchor("https://www.xiaohongshu.com/explore/abc")],
  });
  assert.equal(r.imageContext, false);
  assert.equal(r.candidates.length, 0);
});
test("a native image-result marker is accepted without requiring undocumented URL parameters", () => {
  const r = collect({
    url: "https://www.xiaohongshu.com/search_result",
    imageMarker: true,
    anchors: [cardAnchor("https://www.xiaohongshu.com/explore/abc")],
  });
  assert.equal(r.imageContext, true);
  assert.equal(r.candidates.length, 1);
});
test("challenge pages and cross-platform redirects never yield candidate links", () => {
  assert.equal(
    collect({
      body: "安全验证",
      anchors: [cardAnchor("https://www.xiaohongshu.com/explore/abc")],
    }).blocked,
    true,
  );
  for (const url of [
    "https://www.google.com/search?image_id=x",
    "https://www.bing.com/images?image_id=x",
    "https://www.xiaohongshu.com.evil.test/search?image_id=x",
  ]) {
    const r = collect({ url });
    assert.equal(r.blocked, true);
    assert.equal(r.candidates.length, 0);
  }
});
test("empty image fields never turn the search page into a thumbnail URL", () => {
  const r = collect({
    anchors: [cardAnchor("https://www.xiaohongshu.com/explore/abc", "")],
  });
  assert.equal(r.candidates[0].imageUrl, "");
});

function uploaderContext({
  native = true,
  composer = false,
  login = false,
  url = "https://www.xiaohongshu.com/explore",
} = {}) {
  let dispatched = 0;
  const scope = {
    textContent: "以图搜图",
    tagName: "FORM",
    getAttribute: () => "",
  };
  const input = {
    disabled: false,
    textContent: "",
    getAttribute: (k) => (k === "accept" ? "image/jpeg,image/png" : ""),
    closest: (s) =>
      s.includes("contenteditable")
        ? composer
          ? {}
          : null
        : native
          ? scope
          : null,
    dispatchEvent: (e) => {
      assert.ok(["input", "change"].includes(e.type));
      dispatched++;
    },
  };
  const ctx = {
    location: new URL(url),
    document: {
      title: "平台",
      body: { innerText: "" },
      querySelector: () => (login ? {} : null),
      querySelectorAll: (s) => (s === 'input[type="file"]' ? [input] : []),
    },
    URL,
    atob,
    Uint8Array,
    File,
    Event,
    DataTransfer: class {
      files = [];
      items = { add: (file) => this.files.push(file) };
    },
    setTimeout,
  };
  return { ctx, input, dispatched: () => dispatched };
}
async function upload(fixture, platform = "xhs") {
  return vm.runInNewContext(
    `(${submitReferenceImage.toString()})(${JSON.stringify({ platform, dataUrl: "data:image/jpeg;base64,AAAA" })})`,
    fixture.ctx,
  );
}
test("image is sent only to a recognized native image-search upload input", async () => {
  const f = uploaderContext();
  const r = await upload(f);
  assert.equal(r.submitted, true);
  assert.equal(f.dispatched(), 2);
  assert.equal(f.input.files[0].type, "image/jpeg");
  assert.equal(f.input.files[0].name, "reference.jpg");
});
test("unrelated media upload and post composers do not receive reference images", async () => {
  for (const opts of [{ native: false }, { composer: true }]) {
    const f = uploaderContext(opts);
    const r = await upload(f);
    assert.equal(r.submitted, false);
    assert.equal(f.dispatched(), 0);
    assert.equal(f.input.files, undefined);
  }
});
test("login walls block reference transmission without authentication workarounds", async () => {
  const f = uploaderContext({ login: true });
  const r = await upload(f);
  assert.equal(r.submitted, false);
  assert.match(r.message, /登录/);
  assert.equal(f.dispatched(), 0);
});
test("Instagram reports its unverified entry without inspecting or sending to any upload field", async () => {
  const f = uploaderContext({ url: "https://www.instagram.com/explore/" });
  const r = await upload(f, "instagram");
  assert.equal(r.unsupported, true);
  assert.equal(r.submitted, false);
  assert.equal(f.dispatched(), 0);
});
test("uploader rejects external engines and deceptive hosts before reading image bytes", async () => {
  for (const url of [
    "https://www.google.com",
    "https://www.bing.com",
    "https://www.xiaohongshu.com.evil.test",
    "http://www.xiaohongshu.com",
  ])
    await assert.rejects(upload(uploaderContext({ url })), /停止传送/);
});
