import test from "node:test";
import assert from "node:assert/strict";
import { mediaUrlProblem, assessDownload } from "../extension/media-policy.js";
import { normalizeWork, downloadCandidates } from "../extension/core.js";

test("imported backups cannot enqueue programs, scripts, encoded documents, or archives", () => {
  const files = [
    "run.exe",
    "run.ps1",
    "run.js",
    "x.htm",
    "x.svg",
    "x.%2565xe",
    "photo.jpg.exe",
    "x.bat;.jpg",
  ];
  const w = normalizeWork({
    url: "https://www.instagram.com/p/Case_01/",
    user: "发布者",
    media: files.map((name) => ({
      url: "https://media.test/" + name,
      kind: "image",
    })),
  });
  assert.equal(w.media.length, files.length);
  assert.ok(w.media.every((m) => m.blockedReason));
  assert.equal(downloadCandidates([w]).length, 0);
  assert.ok(mediaUrlProblem("https://media.test/photos.zip", "archive"));
  assert.ok(mediaUrlProblem("javascript:alert(1)", "image"));
  assert.ok(mediaUrlProblem("https://user:password@media.test/a.jpg", "image"));
});
test("Instagram CDN images, signed video URLs and extensionless media stay available", () => {
  for (const [url, kind] of [
    ["https://scontent.cdninstagram.com/v/a.jpg?stp=dst-jpg&_nc=1", "image"],
    ["https://video.cdninstagram.com/a.mp4?token=temporary", "video"],
    ["https://media.test/content?id=123", "image"],
  ]) {
    assert.equal(mediaUrlProblem(url, kind), "");
  }
});
test("redirects, active response MIME and browser risk always prevent completion", () => {
  const base = {
    url: "https://media.test/a.jpg",
    state: "complete",
    mime: "image/jpeg",
    danger: "safe",
  };
  for (const danger of [
    "content",
    "url",
    "file",
    "uncommon",
    "accepted",
    "allowlistedByPolicy",
    "newUnknownRisk",
  ])
    assert.equal(assessDownload({ ...base, danger }, "image").level, "blocked");
  assert.equal(
    assessDownload({ ...base, finalUrl: "https://media.test/run.exe" }, "image")
      .level,
    "blocked",
  );
  assert.equal(
    assessDownload({ ...base, mime: "application/javascript" }, "image").level,
    "blocked",
  );
  assert.equal(
    assessDownload({ ...base, mime: "image/svg+xml" }, "image").level,
    "blocked",
  );
  assert.equal(
    assessDownload(
      { ...base, error: "FILE_VIRUS_INFECTED", state: "interrupted" },
      "image",
    ).level,
    "blocked",
  );
  assert.equal(
    assessDownload({ ...base, mime: "text/html" }, "image").level,
    "invalid",
  );
});
test("browser scanning remains pending until its actual verdict arrives", () => {
  const item = {
    url: "https://media.test/a.jpg",
    state: "in_progress",
    mime: "image/jpeg",
    danger: "asyncScanning",
  };
  assert.equal(assessDownload(item, "image").level, "checking");
  assert.equal(
    assessDownload(
      { ...item, danger: "deepScannedSafe", state: "complete" },
      "image",
    ).level,
    "allowed",
  );
  assert.equal(
    assessDownload(
      { ...item, state: "interrupted", error: "USER_CANCELED" },
      "image",
    ).level,
    "allowed",
  );
});
