import test from "node:test";
import assert from "node:assert/strict";
import {
  clipboardImageFile,
  installReferencePaste,
} from "../extension/reference-paste.js";
const picture = new File(["png-test"], "截图.png", { type: "image/png" });
test("Ctrl+V image paste passes the actual clipboard image into the reference loader", () => {
  let handler,
    received,
    prevented = 0;
  const target = {
    addEventListener: (type, f) => {
      assert.equal(type, "paste");
      handler = f;
    },
    removeEventListener() {},
  };
  installReferencePaste({
    target,
    isEnabled: () => true,
    onImage: (file) => (received = file),
  });
  handler({
    clipboardData: {
      items: [{ kind: "file", type: "image/png", getAsFile: () => picture }],
    },
    preventDefault: () => prevented++,
  });
  assert.equal(received, picture);
  assert.equal(prevented, 1);
});
test("plain text paste remains available to original import and editing fields", () => {
  let handler,
    prevented = 0,
    received = 0;
  installReferencePaste({
    target: { addEventListener: (t, f) => (handler = f) },
    isEnabled: () => true,
    onImage: () => received++,
  });
  handler({
    clipboardData: {
      items: [{ kind: "string", type: "text/plain" }],
      files: [],
    },
    preventDefault: () => prevented++,
  });
  assert.equal(received, 0);
  assert.equal(prevented, 0);
});
test("clipboard files fallback works and inactive reference view never consumes a screenshot", () => {
  assert.equal(clipboardImageFile({ files: [picture] }), picture);
  let handler,
    prevented = 0,
    received = 0;
  installReferencePaste({
    target: { addEventListener: (t, f) => (handler = f) },
    isEnabled: () => false,
    onImage: () => received++,
  });
  handler({
    clipboardData: { files: [picture] },
    preventDefault: () => prevented++,
  });
  assert.equal(received, 0);
  assert.equal(prevented, 0);
});
