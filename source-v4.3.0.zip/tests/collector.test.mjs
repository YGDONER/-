import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import { collectPage } from "../extension/collector.js";
import { normalizeWork, downloadCandidates } from "../extension/core.js";
async function collect(
  {
    url,
    state = {},
    meta = {},
    selectors = {},
    anchors = [],
    title = "作品页面",
    videos = [],
    images = [],
  },
  opts = { mode: "detail" },
) {
  const doc = {
    title,
    body: { innerText: "" },
    querySelector(s) {
      if (s.startsWith("meta[")) {
        const name = s.match(/\[property="([^"]+)/)?.[1];
        return meta[name] ? { content: meta[name] } : null;
      }
      return selectors[s] || null;
    },
    querySelectorAll(s) {
      if (s === "a[href]") return anchors;
      if (s === "video") return videos;
      if (s === "img") return images;
      return [];
    },
  };
  const win = {
    ...state,
    scrollX: 0,
    scrollY: 0,
    scrollBy() {},
    scrollTo() {},
    innerHeight: 800,
  };
  const context = {
    URL,
    document: doc,
    window: win,
    location: new URL(url),
    setTimeout,
  };
  return vm.runInNewContext(
    `(${collectPage.toString()})(${JSON.stringify({ settle: false, ...opts })})`,
    context,
  );
}
test("XHS chooses current note author rather than unrelated account", async () => {
  const r = await collect({
    url: "https://www.xiaohongshu.com/explore/abc",
    state: {
      __INITIAL_STATE__: {
        user: { nickname: "登录者" },
        note: {
          noteDetailMap: {
            abc: {
              note: {
                title: "当前作品",
                user: { nickname: "发布者Fafa" },
                imageList: [{ urlDefault: "https://i.test/x.jpg" }],
              },
            },
            other: { note: { user: { nickname: "其他人" } } },
          },
        },
      },
    },
  });
  assert.equal(r.works[0].user, "发布者Fafa");
  assert.equal(r.works[0].media.length, 1);
  assert.equal(r.works[0].media[0].url, "https://i.test/x.jpg");
});
test("Douyin keeps the matched work and highest bitrate direct video", async () => {
  const r = await collect({
    url: "https://www.douyin.com/video/123",
    state: {
      _ROUTER_DATA: {
        a: {
          aweme_id: "123",
          desc: "美食短片",
          author: { nickname: "小厨" },
          video: {
            bit_rate: [
              {
                bit_rate: 1,
                play_addr: { url_list: ["https://v.test/small.mp4"] },
              },
              {
                bit_rate: 2,
                play_addr: { url_list: ["https://v.test/large.mp4"] },
              },
            ],
          },
        },
        b: { aweme_id: "456", author: { nickname: "错误账号" }, video: {} },
      },
    },
  });
  assert.equal(r.works[0].user, "小厨");
  assert.equal(r.works[0].media[0].url, "https://v.test/large.mp4");
});
test("Pinterest selects MP4 over HLS and treats video preview as cover", async () => {
  const r = await collect({
    url: "https://www.pinterest.com/pin/123/",
    state: {
      __PWS_DATA__: {
        pin: {
          id: "123",
          title: "Pin标题",
          pinner: { full_name: "发布者" },
          images: { orig: { url: "https://i.test/p.jpg" } },
          videos: {
            video_list: {
              hls: { width: 2000, height: 2000, url: "https://v.test/p.m3u8" },
              mp4: { width: 1000, height: 1000, url: "https://v.test/p.mp4" },
            },
          },
        },
      },
    },
  });
  const w = normalizeWork(r.works[0]);
  assert.equal(w.user, "发布者");
  assert.equal(w.type, "video");
  assert.equal(w.media[0].kind, "cover");
  assert.equal(downloadCandidates([w]).length, 1);
  assert.equal(downloadCandidates([w])[0].asset.url, "https://v.test/p.mp4");
});
test("Pinterest creator download restriction is respected", async () => {
  const r = await collect({
    url: "https://www.pinterest.com/pin/123/",
    state: {
      __PWS_DATA__: {
        id: "123",
        is_downloadable: false,
        videos: { video_list: { a: { url: "https://v.test/a.mp4" } } },
      },
    },
  });
  assert.equal(downloadCandidates([normalizeWork(r.works[0])]).length, 0);
  assert.match(r.works[0].media[0].blockedReason, /未开放/);
});
for (const platform of ["taobao", "tmall"])
  test(platform + " shop name and gallery extraction", async () => {
    const gallery = {
      querySelectorAll: () => [
        { currentSrc: "https://img.test/product.jpg", naturalWidth: 800 },
      ],
    };
    const r = await collect({
      url: `https://${platform === "tmall" ? "detail.tmall.com" : "item.taobao.com"}/item.htm?id=123`,
      selectors: {
        '#J_Title h3,[class*="ItemTitle"],[class*="itemTitle"],h1': {
          textContent: "商品名",
        },
        '[class*="ShopHeader"] [class*="name"],[class*="shopName"],.tb-shop-name a,.shop-name-link':
          { textContent: "商店名字" },
        '[class*="PicGallery"],[class*="mainPic"],[class*="picGallery"],#J_DivItemDesc,.tb-gallery':
          gallery,
      },
    });
    assert.equal(r.works[0].user, "商店名字");
    assert.equal(r.works[0].media[0].url, "https://img.test/product.jpg");
  });
test("empty page never fabricates /undefined or current-page media URL", async () => {
  const r = await collect({ url: "https://example.test/article" });
  assert.equal(r.works[0].media.length, 0);
  assert.equal(r.works[0].user, "");
});
test("Blob source gets a useful attention reason", async () => {
  const r = await collect({
    url: "https://example.test/article",
    videos: [
      { currentSrc: "blob:https://example.test/a", querySelector: () => null },
    ],
  });
  assert.equal(r.works[0].media.length, 0);
  assert.match(r.works[0].error, /Blob/);
});
test("verification page stops without generating fake work", async () => {
  const r = await collect({
    url: "https://www.douyin.com/video/123",
    title: "安全验证",
  });
  assert.equal(r.works.length, 0);
  assert.equal(r.blocked, true);
});
test("search results carry thumbnail as cover, never as full-resolution gallery", async () => {
  const img = { src: "https://img.test/thumbnail.jpg", alt: "标题" },
    card = {
      querySelector: (s) =>
        s === "img"
          ? img
          : s.includes("title")
            ? { textContent: "检索作品" }
            : { textContent: "博主" },
    },
    a = {
      href: "https://www.xiaohongshu.com/explore/abc",
      getAttribute: () => "",
      closest: () => card,
      querySelector: () => img,
      textContent: "",
    };
  const r = await collect(
    {
      url: "https://www.xiaohongshu.com/search_result?keyword=x",
      anchors: [a, a],
    },
    { mode: "list", rounds: 0 },
  );
  assert.equal(r.works.length, 1);
  assert.equal(r.works[0].media[0].kind, "cover");
  assert.equal(downloadCandidates([normalizeWork(r.works[0])]).length, 0);
});
test("XHS document title fallback retains exact publisher nickname", async () => {
  const r = await collect({
    url: "https://www.xiaohongshu.com/explore/abc",
    title:
      "叫我什么 姐姐？ - 卿颂Fafa📷（厦门陪拍） | 小红书 - 你的生活兴趣社区",
  });
  assert.equal(r.works[0].user, "卿颂Fafa📷（厦门陪拍）");
  assert.equal(r.works[0].title, "叫我什么 姐姐？");
});
test("automatic capture waits for matching XHS note rather than saving previous DOM identity", async () => {
  const r = await collect(
    {
      url: "https://www.xiaohongshu.com/explore/newnote",
      title: "旧标题 - 旧博主 | 小红书",
      state: {
        __INITIAL_STATE__: {
          note: {
            noteDetailMap: {
              oldnote: {
                note: { title: "旧标题", user: { nickname: "旧博主" } },
              },
            },
          },
        },
      },
    },
    { mode: "detail", identityOnly: true },
  );
  assert.equal(r.works.length, 0);
  assert.match(r.message, /等待/);
});
test("explicit whole-page image grab filters small icons, avatars, unsafe sources and duplicates", async () => {
  const { collectPageImages } = await import("../extension/collector.js");
  const im = (url, w = 500, excluded = false) => ({
    currentSrc: url,
    naturalWidth: w,
    naturalHeight: w,
    getAttribute: () => "",
    closest: () => (excluded ? {} : null),
  });
  const doc = {
    title: "图片页",
    querySelector: () => null,
    querySelectorAll: () => [
      im("https://i.test/a.png"),
      im("https://i.test/a.png"),
      im("https://i.test/icon.png", 30),
      im("https://i.test/avatar.png", 500, true),
      im("javascript:alert(1)"),
      im(""),
    ],
  };
  const result = vm.runInNewContext(
    `(${collectPageImages.toString()})({wholePage:true,minWidth:200})`,
    { document: doc, location: new URL("https://example.test/article"), URL },
  );
  assert.equal(result.works.length, 1);
  assert.equal(result.works[0].media.length, 1);
  assert.equal(result.works[0].media[0].url, "https://i.test/a.png");
  assert.equal(result.works[0].user, "");
});
test("Pinduoduo reads the current product gallery and its matching shop rather than another product", async () => {
  const r = await collect({
    url: "https://mobile.yangkeduo.com/goods.html?goods_id=123",
    state: {
      rawData: {
        login: { nickname: "登录者" },
        goods: {
          goods_id: "123",
          goods_name: "陶瓷早餐杯",
          mall_id: "88",
          gallery: [
            { url: "https://i.test/pdd-1.jpg" },
            { url: "https://i.test/pdd-2.jpg" },
            null,
          ],
        },
        mall: { mall_id: "88", mall_name: "晨光器物店" },
        related: {
          goods_id: "999",
          goods_name: "推荐商品",
          mall_name: "其他店铺",
          gallery: [{ url: "https://i.test/wrong.jpg" }],
        },
      },
    },
  });
  assert.equal(r.works[0].platform, "pdd");
  assert.equal(r.works[0].user, "晨光器物店");
  assert.equal(r.works[0].media.length, 2);
  assert.equal(r.works[0].title, "陶瓷早餐杯");
});
test("Vipshop reads the matched product and keeps its merchant account name", async () => {
  const r = await collect({
    url: "https://detail.vip.com/detail-0-456.html",
    state: {
      __INITIAL_STATE__: {
        product: {
          productId: "456",
          productName: "春日帆布鞋",
          shopName: "春日鞋履旗舰店",
          productImages: [
            "https://i.test/vip-1.jpg",
            "https://i.test/vip-2.jpg",
          ],
        },
        login: { nickname: "当前登录者" },
      },
    },
  });
  assert.equal(r.works[0].platform, "vip");
  assert.equal(r.works[0].user, "春日鞋履旗舰店");
  assert.equal(r.works[0].media.length, 2);
});
test("unidentified Vipshop merchant is left empty instead of substituting a brand or logged-in user", async () => {
  const r = await collect({
    url: "https://detail.vip.com/detail-0-457.html",
    state: {
      __INITIAL_STATE__: {
        product: {
          productId: "457",
          productName: "女装",
          brandName: "商品品牌",
          productImages: ["https://i.test/vip.jpg"],
        },
        login: { nickname: "登录者" },
      },
    },
  });
  assert.equal(r.works[0].user, "");
});

test("Instagram mixed carousel chooses matched publisher and all loaded structured children", async () => {
  const post = {
    shortcode: "AbC",
    owner: { full_name: "花间摄影📷", username: "fafa.photo" },
    edge_media_to_caption: { edges: [{ node: { text: "窗边的人像" } }] },
    edge_sidecar_to_children: {
      edges: [
        {
          node: {
            display_url: "https://i.test/1-small.jpg",
            display_resources: [
              {
                src: "https://i.test/1-large.jpg",
                config_width: 1080,
                config_height: 1350,
              },
            ],
          },
        },
        { node: { display_url: "https://i.test/2.jpg" } },
        {
          node: {
            is_video: true,
            display_url: "https://i.test/cover.jpg",
            video_url: "https://v.test/clip.mp4",
          },
        },
      ],
    },
  };
  const r = await collect({
    url: "https://www.instagram.com/p/AbC/",
    state: {
      _sharedData: {
        viewer: { full_name: "当前登录者" },
        post,
        related: {
          shortcode: "Wrong",
          owner: { full_name: "推荐账号" },
          display_url: "https://i.test/wrong.jpg",
        },
      },
    },
  });
  const w = normalizeWork(r.works[0]);
  assert.equal(w.platform, "instagram");
  assert.equal(w.user, "花间摄影📷");
  assert.equal(w.title, "窗边的人像");
  assert.equal(w.type, "mixed");
  assert.deepEqual(
    Array.from(w.media, (m) => m.kind),
    ["image", "image", "cover", "video"],
  );
  assert.equal(w.media[0].url, "https://i.test/1-large.jpg");
});

test("Instagram Reels read the publishing account and highest resolution direct video", async () => {
  const r = await collect({
    url: "https://www.instagram.com/creator/reel/Reel_1/",
    state: {
      __INITIAL_STATE__: {
        post: {
          code: "Reel_1",
          user: { username: "creator" },
          caption: { text: "Reels 标题" },
          media_type: 2,
          image_versions2: {
            candidates: [
              { url: "https://i.test/cover.jpg", width: 1080, height: 1920 },
            ],
          },
          video_versions: [
            { url: "https://v.test/small.mp4", width: 360, height: 640 },
            { url: "https://v.test/large.mp4", width: 1080, height: 1920 },
          ],
        },
      },
    },
  });
  const w = normalizeWork(r.works[0]);
  assert.equal(w.user, "creator");
  assert.equal(w.type, "video");
  assert.deepEqual(
    downloadCandidates([w]).map((x) => x.asset.url),
    ["https://v.test/large.mp4"],
  );
});

test("Instagram SPA navigation never saves the previous post or global feed media", async () => {
  const r = await collect(
    {
      url: "https://www.instagram.com/p/NewCode/",
      state: {
        _sharedData: {
          post: {
            shortcode: "OldCode",
            owner: { full_name: "上一位作者" },
            display_url: "https://i.test/old.jpg",
          },
        },
      },
      images: [
        { currentSrc: "https://i.test/recommend.jpg", naturalWidth: 800 },
      ],
    },
    { mode: "detail", identityOnly: true },
  );
  assert.equal(r.works.length, 0);
  assert.match(r.message, /等待当前 Instagram/);
});

test("Instagram metadata fallback uses current post name and keeps preview as a cover", async () => {
  const r = await collect({
    url: "https://www.instagram.com/p/Meta_1/",
    meta: {
      "og:url": "https://www.instagram.com/p/Meta_1/",
      "og:title": '原帖作者 on Instagram: "春天的风"',
      "og:image": "https://i.test/preview.jpg",
      author: "登录者",
    },
  });
  assert.equal(r.works[0].user, "原帖作者");
  assert.equal(r.works[0].title, "春天的风");
  assert.equal(r.works[0].media[0].kind, "cover");
});

test("Instagram metadata pointing to a previous post is rejected", async () => {
  const r = await collect({
    url: "https://www.instagram.com/p/New_1/",
    meta: {
      "og:url": "https://www.instagram.com/p/Old_1/",
      "og:title": '旧作者 on Instagram: "旧作品"',
    },
  });
  assert.equal(r.works.length, 0);
});
