import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import { changeCategory, applyCategoryRules } from "../extension/categories.js";
import { normalizeWork } from "../extension/core.js";
let data = {},
  tab = { id: 1, active: true, url: "https://www.xiaohongshu.com/explore/abc" };
let downloads = 0,
  reloads = 0,
  checks = 0,
  installType = "development";
const copy = (x) => structuredClone(x),
  event = () => ({
    listeners: [],
    addListener(f) {
      this.listeners.push(f);
    },
  });
globalThis.chrome = {
  storage: {
    local: {
      get: async () => copy(data),
      set: async (x) => Object.assign(data, copy(x)),
    },
  },
  tabs: { get: async () => copy(tab) },
  action: {
    setBadgeText: async () => {},
    setBadgeBackgroundColor: async () => {},
  },
  management: { getSelf: async () => ({ installType }) },
  runtime: {
    getManifest: () => ({ version: "4.1.0" }),
    requestUpdateCheck: async () => {
      checks++;
      return { status: "update_available", version: "4.1.1" };
    },
    reload: () => reloads++,
    onUpdateAvailable: event(),
    onInstalled: event(),
  },
};
const { autoCapture } = await import("../extension/auto-capture.js");
const { transact, latestState } = await import("../extension/database.js");
const { checkUpdate, applyUpdate, updateInfo, registerUpdateEvents } =
  await import("../extension/updates.js");
const current = () => ({
  works: [
    {
      url: tab.url,
      title: "叫我什么 姐姐？",
      user: "卿颂Fafa📷（厦门陪拍）",
      media: [{ url: "https://i.test/a.jpg", kind: "image" }],
    },
  ],
});
await test("opening a supported work automatically fills exact account without clipboard or download", async () => {
  const r = await autoCapture(1, async () => current());
  assert.equal(r.captured, true);
  assert.equal(r.user, "卿颂Fafa📷（厦门陪拍）");
  const s = await latestState();
  assert.equal(s.works.length, 1);
  assert.equal(s.works[0].source, "automatic");
  assert.equal(s.autoLast.workId, s.works[0].id);
  assert.equal(s.downloads.length, 0);
  assert.equal(downloads, 0);
});
await test("repeat events deduplicate; inactive tabs and search pages are not silently imported", async () => {
  let calls = 0;
  const capture = async () => {
    calls++;
    return current();
  };
  let r = await autoCapture(1, capture);
  assert.equal(r.captured, false);
  assert.equal((await latestState()).works.length, 1);
  tab.active = false;
  r = await autoCapture(1, capture);
  assert.equal(r.reason, "inactive");
  tab.active = true;
  tab.url = "https://www.xiaohongshu.com/search_result?keyword=a";
  r = await autoCapture(1, capture);
  assert.equal(r.reason, "list");
  assert.equal(calls, 0);
});
await test("automatic collection switch and per-site authorization are respected", async () => {
  tab.url = "https://www.pinterest.com/pin/123/";
  await transact((s) => {
    s.settings.autoCapture = false;
  });
  assert.equal(
    (await autoCapture(1, async () => current())).reason,
    "disabled",
  );
  await transact((s) => {
    s.settings.autoCapture = true;
  });
  tab.url = "https://example.test/article/abc";
  assert.equal(
    (await autoCapture(1, async () => current())).reason,
    "unauthorized",
  );
  await transact((s) => {
    s.settings.autoSites = ["https://example.test"];
  });
  assert.equal((await autoCapture(1, async () => current())).captured, true);
});
await test("verification and navigation races never save the wrong work", async () => {
  tab.url = "https://www.pinterest.com/pin/456/";
  let r = await autoCapture(2, async () => ({
    blocked: true,
    works: [],
    message: "验证",
  }));
  assert.equal(r.captured, false);
  r = await autoCapture(2, async () => ({
    works: [{ url: "https://www.pinterest.com/pin/789/", title: "其他作品" }],
  }));
  assert.equal(r.reason, "navigation");
  assert.ok(!(await latestState()).works.some((w) => w.url.includes("/789/")));
});
await test("category rename updates existing works and future automatic classifications", async () => {
  await transact((s) => {
    s.works.push(
      normalizeWork({
        url: "https://www.pinterest.com/pin/10/",
        title: "摄影运镜",
        category: "摄影/镜头",
      }),
    );
    changeCategory(s, {
      action: "rename",
      name: "摄影/镜头",
      newName: "拍摄参考",
    });
    s.works.push(
      normalizeWork({
        url: "https://www.pinterest.com/pin/11/",
        title: "摄影运镜",
      }),
    );
    applyCategoryRules(s);
  });
  let s = await latestState();
  assert.equal(
    s.works.find((w) => w.url.includes("/10/")).category,
    "拍摄参考",
  );
  assert.equal(
    s.works.find((w) => w.url.includes("/11/")).category,
    "拍摄参考",
  );
  await transact((s) =>
    changeCategory(s, { action: "delete", name: "拍摄参考" }),
  );
  s = await latestState();
  assert.equal(s.works.find((w) => w.url.includes("/10/")).category, "未分类");
  assert.equal(s.works.length, 4);
  assert.throws(() => changeCategory(s, { action: "delete", name: "未分类" }));
});
await test("development installations never claim remote updates or call update server", async () => {
  const r = await checkUpdate();
  assert.equal(r.status, "development");
  assert.equal(checks, 0);
  assert.match(r.message, /不会|不会从|本地目录/);
  await assert.rejects(applyUpdate(), /尚无/);
});
await test("normal installations check official browser update and block reload during active parsing", async () => {
  installType = "normal";
  const r = await checkUpdate();
  assert.equal(r.available, "4.1.1");
  assert.equal(checks, 1);
  await transact((s) => {
    s.jobs.push({ id: "parse-job", state: "processing" });
  });
  await assert.rejects(applyUpdate(), /等待/);
  await transact((s) => {
    s.jobs = [];
  });
  assert.equal((await applyUpdate()).ready, true);
  assert.equal(reloads, 0);
  registerUpdateEvents();
  await chrome.runtime.onUpdateAvailable.listeners[0]({ version: "4.1.2" });
  await new Promise((r) => setImmediate(r));
  assert.equal((await updateInfo()).available, "4.1.2");
});
function watcher() {
  let now = 0,
    next = 1,
    timers = new Map(),
    intervals = new Map(),
    sent = [];
  const doc = {
    visibilityState: "visible",
    title: "作品 A",
    documentElement: {},
    querySelector: () => null,
    addEventListener() {},
    removeEventListener() {},
  };
  const win = { addEventListener() {}, removeEventListener() {} };
  const loc = { href: "https://www.xiaohongshu.com/explore/aaa" };
  const context = {
    window: win,
    document: doc,
    location: loc,
    URL,
    chrome: {
      runtime: {
        id: "test",
        sendMessage: async (m) => {
          sent.push({ type: m.type, url: loc.href });
          return { ok: true, captured: false };
        },
      },
    },
    MutationObserver: class {
      observe() {}
      disconnect() {}
    },
    setTimeout: (fn, ms) => {
      const id = next++;
      timers.set(id, { fn, at: now + ms });
      return id;
    },
    clearTimeout: (id) => timers.delete(id),
    setInterval: (fn) => {
      const id = next++;
      intervals.set(id, fn);
      return id;
    },
    clearInterval: (id) => intervals.delete(id),
  };
  vm.runInNewContext(
    fs.readFileSync(
      new URL("../extension/auto-watch.js", import.meta.url),
      "utf8",
    ),
    context,
  );
  return {
    doc,
    loc,
    sent,
    async advance(ms) {
      now += ms;
      const due = [...timers].filter(([, t]) => t.at <= now);
      for (const [id, t] of due) {
        timers.delete(id);
        t.fn();
        await Promise.resolve();
        await Promise.resolve();
      }
    },
    tick() {
      for (const fn of intervals.values()) fn();
    },
  };
}
await test("watcher detects SPA URL changes and title changes without copy-paste", async () => {
  const w = watcher();
  await w.advance(800);
  assert.equal(w.sent.length, 1);
  w.loc.href = "https://www.xiaohongshu.com/explore/bbb";
  w.tick();
  await w.advance(800);
  assert.equal(w.sent.at(-1).url, w.loc.href);
  const before = w.sent.length;
  w.doc.title = "作品 B 已加载";
  w.tick();
  await w.advance(800);
  assert.ok(w.sent.length > before);
});
await test("watcher does not collect hidden tabs or list pages", async () => {
  const w = watcher();
  w.doc.visibilityState = "hidden";
  await w.advance(800);
  assert.equal(w.sent.length, 0);
  w.doc.visibilityState = "visible";
  w.loc.href = "https://www.xiaohongshu.com/search_result?keyword=a";
  w.tick();
  await w.advance(7000);
  assert.equal(w.sent.length, 0);
});

await test("active image reference search blocks extension reload", async () => {
  await transact((s) => {
    s.visualSearch = { state: "running" };
  });
  await assert.rejects(applyUpdate(), /相似检索/);
  await transact((s) => {
    s.visualSearch = null;
  });
});

await test("Instagram posts auto-collect their exact publisher while profiles stay out of the library", async () => {
  tab.url = "https://www.instagram.com/p/InsAuto_1/";
  const r = await autoCapture(41, async () => ({
    works: [
      {
        url: tab.url,
        title: "ins 图集",
        user: "花间摄影📷",
        media: [{ url: "https://i.test/ins.jpg", kind: "image" }],
      },
    ],
  }));
  assert.equal(r.captured, true);
  const w = (await latestState()).works.find((w) =>
    w.url.includes("InsAuto_1"),
  );
  assert.equal(w.platform, "instagram");
  assert.equal(w.user, "花间摄影📷");
  tab.url = "https://www.instagram.com/creator/";
  assert.equal((await autoCapture(42, async () => current())).reason, "list");
});
await test("Instagram watcher captures a Reels SPA navigation and ignores its profile page", async () => {
  const w = watcher();
  w.loc.href = "https://www.instagram.com/reel/InsWatch_1/";
  w.tick();
  await w.advance(800);
  assert.ok(w.sent.some((m) => m.url === w.loc.href));
  const before = w.sent.length;
  w.loc.href = "https://www.instagram.com/creator/";
  w.tick();
  await w.advance(7000);
  assert.equal(w.sent.length, before);
});
