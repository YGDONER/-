import test from "node:test";
import assert from "node:assert/strict";
let storage = {},
  permission = true,
  blocked = false,
  missingEntry = false,
  redirect = "",
  hold = null,
  counter = 0,
  uploads = 0;
const tabs = new Map();
const copy = (x) => structuredClone(x),
  candidates = [
    {
      url: "https://www.xiaohongshu.com/explore/abc",
      title: "参考笔记",
      thumbnail: "https://i.test/x.jpg",
    },
    {
      url: "https://www.pinterest.com/pin/123/",
      title: "参考图片",
      thumbnail: "https://i.test/p.jpg",
    },
    { url: "https://www.instagram.com/p/AbC/", title: "ins帖子" },
  ];
globalThis.chrome = {
  storage: {
    local: {
      get: async () => copy(storage),
      set: async (x) => Object.assign(storage, copy(x)),
      remove: async (key) => delete storage[key],
    },
  },
  permissions: { contains: async () => permission },
  tabs: {
    create: async (o) => {
      const t = { id: ++counter, ...o, status: "complete" };
      if (redirect) t.url = redirect;
      tabs.set(t.id, t);
      return copy(t);
    },
    get: async (id) => {
      if (!tabs.has(id)) throw new Error("closed");
      return copy(tabs.get(id));
    },
  },
  scripting: {
    executeScript: async ({ target, func, args }) => {
      const tab = tabs.get(target.tabId);
      if (hold) await hold;
      if (func.name === "submitReferenceImage") {
        if (missingEntry)
          return [
            { result: { submitted: false, message: "未找到原生搜图上传入口" } },
          ];
        uploads++;
        tab.submitted = true;
        return [{ result: { submitted: true } }];
      }
      return [
        {
          result: blocked
            ? { blocked: true, message: "需要登录或验证", candidates: [] }
            : {
                candidates: tab.submitted ? candidates : [],
                imageContext: !!tab.submitted,
                ready: true,
                platform: args[0].platform,
              },
        },
      ];
    },
  },
};
const { handleVisualMessage } = await import("../extension/visual-service.js");
const { latestState, transact } = await import("../extension/database.js");
const reference = () => ({
  id: "reference-" + counter,
  name: "测试.mp4",
  type: "video",
  frames: [0, 1, 2].map((i) => ({
    id: "frame-" + i,
    dataUrl: "data:image/jpeg;base64,AAAA",
    time: i * 2,
    width: 600,
    height: 400,
  })),
});
async function until(check) {
  for (let i = 0; i < 300; i++) {
    const s = await latestState();
    if (check(s.visualSearch, s)) {
      await new Promise((r) => setImmediate(r));
      return s;
    }
    await new Promise((r) => setImmediate(r));
  }
  throw new Error("visual task did not settle");
}
const start = (platforms = ["xhs"], frames = ["frame-0"]) =>
  handleVisualMessage({
    type: "VISUAL_START",
    reference: reference(),
    frameIds: frames,
    platforms,
    mode: platforms.length === 1 ? "single" : "multi",
  });

await test("disabled external engines never create tabs, transmit or cache references", async () => {
  for (const engine of ["bing", "google"])
    await assert.rejects(
      handleVisualMessage({
        type: "VISUAL_START",
        engine,
        reference: reference(),
        frameIds: ["frame-0"],
        platforms: ["xhs"],
      }),
      /已禁用/,
    );
  assert.equal(tabs.size, 0);
  assert.equal(uploads, 0);
  assert.equal(storage.visualReferenceV4, undefined);
});
await test("selected-platform permission denial never transmits or caches reference images", async () => {
  permission = false;
  await assert.rejects(start(), /允许访问/);
  assert.equal(uploads, 0);
  assert.equal(storage.visualReferenceV4, undefined);
  permission = true;
});
await test("each selected frame searches only the chosen native platform and discards unrelated candidates", async () => {
  const r = await start(["xhs"], ["frame-0", "frame-2"]);
  const s = await until((v) => v?.id === r.visualId && v.state === "completed");
  const v = s.visualSearch;
  assert.equal(v.scopeVersion, 3);
  assert.equal(v.nativeOnly, true);
  assert.equal(v.tasks.length, 2);
  assert.ok(v.tasks.every((t) => t.platform === "xhs"));
  assert.equal(v.results.length, 1);
  assert.deepEqual(v.results[0].frameIds, ["frame-0", "frame-2"]);
  assert.ok(
    [...tabs.values()].every(
      (t) => new URL(t.url).hostname === "www.xiaohongshu.com",
    ),
  );
  assert.equal(s.works.length, 0);
  assert.equal(s.downloads.length, 0);
});
await test("multi-platform tasks open native pages and activate the first platform for the user", async () => {
  const r = await start(["xhs", "pinterest"]);
  const v = (
    await until((v) => v?.id === r.visualId && v.state === "completed")
  ).visualSearch;
  assert.equal(v.results.length, 2);
  assert.equal(v.tasks.length, 2);
  assert.equal(tabs.get(v.tasks[0].tabId).active, true);
  assert.equal(
    new URL(tabs.get(v.tasks[1].tabId).url).hostname,
    "www.pinterest.com",
  );
});
await test("native candidates remain previews until explicitly imported and never invent publisher names", async () => {
  const v = (await latestState()).visualSearch;
  const r = await handleVisualMessage({
    type: "VISUAL_IMPORT",
    visualId: v.id,
    ids: [v.results[0].id],
    category: "相似灵感",
  });
  assert.equal(r.added, 1);
  const w = (await latestState()).works[0];
  assert.equal(w.user, "");
  assert.equal(w.media[0].kind, "cover");
  await assert.rejects(
    handleVisualMessage({
      type: "VISUAL_IMPORT",
      visualId: "stale",
      ids: [v.results[0].id],
    }),
    /变化/,
  );
});
await test("Instagram opens only its own page, sends no reference and reports unverified capability", async () => {
  const before = uploads;
  const r = await start(["instagram"], ["frame-0", "frame-1", "frame-2"]);
  const v = (
    await until((v) => v?.id === r.visualId && v.state === "attention")
  ).visualSearch;
  assert.equal(v.tasks.length, 1);
  assert.equal(v.tasks[0].state, "unsupported");
  assert.equal(
    new URL(tabs.get(v.tasks[0].tabId).url).hostname,
    "www.instagram.com",
  );
  assert.equal(uploads, before);
  assert.equal(v.results.length, 0);
  assert.match(v.tasks[0].error, /没有发送参考图/);
});
await test("missing native upload never degrades to keywords, homepage recommendations or another engine", async () => {
  missingEntry = true;
  const before = uploads;
  const r = await start();
  const v = (
    await until((v) => v?.id === r.visualId && v.state === "attention")
  ).visualSearch;
  assert.equal(uploads, before);
  assert.equal(v.results.length, 0);
  assert.match(v.tasks[0].error, /原生搜图上传入口/);
  assert.equal(new URL(tabs.get(v.tasks[0].tabId).url).search, "");
  missingEntry = false;
});
await test("manual native search can continue on its original platform tab without another upload", async () => {
  const old = (await latestState()).visualSearch,
    tabId = old.tasks[0].tabId,
    before = uploads;
  tabs.get(tabId).submitted = true;
  await handleVisualMessage({ type: "VISUAL_CONTINUE" });
  const v = (await until((v) => v.state === "completed")).visualSearch;
  assert.equal(v.tasks[0].tabId, tabId);
  assert.equal(uploads, before);
  assert.equal(v.results.length, 1);
});
await test("a login challenge sends no image and can resume in the same native tab", async () => {
  blocked = true;
  const before = uploads,
    r = await start();
  const v = (
    await until((v) => v?.id === r.visualId && v.state === "attention")
  ).visualSearch;
  assert.equal(uploads, before);
  assert.equal(v.results.length, 0);
  const tabId = v.tasks[0].tabId;
  blocked = false;
  await handleVisualMessage({ type: "VISUAL_CONTINUE" });
  const done = (await until((v) => v.state === "completed")).visualSearch;
  assert.equal(done.tasks[0].tabId, tabId);
  assert.equal(done.results.length, 1);
});
await test("redirecting away from the selected platform blocks upload and candidate collection", async () => {
  redirect = "https://evil.test/";
  const before = uploads,
    r = await start();
  const v = (
    await until((v) => v?.id === r.visualId && v.state === "attention")
  ).visualSearch;
  assert.equal(uploads, before);
  assert.equal(v.results.length, 0);
  assert.match(v.tasks[0].error, /离开所选平台/);
  redirect = "";
});
await test("cancellation prevents late results and stops an image from being uploaded after pending checks", async () => {
  let release;
  hold = new Promise((r) => (release = r));
  const before = uploads,
    r = await start();
  await until(
    (v) =>
      v?.id === r.visualId &&
      v.tasks[0].state === "processing" &&
      v.tasks[0].tabId,
  );
  await handleVisualMessage({ type: "VISUAL_CANCEL" });
  release();
  hold = null;
  const v = (await until((v) => v.state === "cancelled")).visualSearch;
  assert.equal(v.results.length, 0);
  assert.equal(uploads, before);
});
await test("clear removes reference copies while preserving already imported notes", async () => {
  const count = (await latestState()).works.length;
  await handleVisualMessage({ type: "VISUAL_CLEAR" });
  const s = await latestState();
  assert.equal(s.visualSearch, null);
  assert.equal(storage.visualReferenceV4, undefined);
  assert.equal(s.works.length, count);
});
await test("restoring legacy external-engine jobs disables them without reopening external pages", async () => {
  await transact((s) => {
    s.visualSearch = {
      id: "old",
      scopeVersion: 2,
      engine: "bing",
      state: "running",
      platforms: ["xhs"],
      tasks: [{ id: "old-task", state: "pending" }],
      results: [{ url: "https://www.xiaohongshu.com/explore/abc" }],
    };
  });
  const before = tabs.size;
  const { restoreVisualJobs } = await import(
    "../extension/visual-service.js?legacy"
  );
  await restoreVisualJobs();
  const v = (await latestState()).visualSearch;
  assert.equal(v.state, "cancelled");
  assert.deepEqual(v.tasks, []);
  assert.deepEqual(v.results, []);
  assert.equal(tabs.size, before);
});
await test("restoring native jobs asks to continue without transmitting references", async () => {
  await transact((s) => {
    s.visualSearch = {
      id: "interrupted",
      scopeVersion: 3,
      nativeOnly: true,
      platforms: ["xhs"],
      state: "running",
      tasks: [{ id: "native-task", state: "processing" }],
      results: [],
    };
  });
  const before = uploads;
  const { restoreVisualJobs } = await import(
    "../extension/visual-service.js?recovery"
  );
  await restoreVisualJobs();
  const v = (await latestState()).visualSearch;
  assert.equal(v.state, "attention");
  assert.equal(v.tasks[0].state, "attention");
  assert.equal(uploads, before);
});
