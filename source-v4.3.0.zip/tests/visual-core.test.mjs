import test from "node:test";
import assert from "node:assert/strict";
import {
  NATIVE_SEARCH,
  nativeHost,
  validateReference,
  frameTimes,
  mergeVisualCandidates,
  candidateWork,
  selectedPlatforms,
} from "../extension/visual-core.js";
const ref = {
  id: "r1",
  type: "video",
  name: "test.mp4",
  frames: Array.from({ length: 5 }, (_, i) => ({
    id: "f" + i,
    dataUrl: "data:image/jpeg;base64,AAAA",
    time: i,
    width: 640,
    height: 480,
  })),
};
test("only the chosen video frames are passed to the search service", () => {
  const out = validateReference(ref, ["f1", "f3"]);
  assert.deepEqual(
    out.frames.map((f) => f.id),
    ["f1", "f3"],
  );
  assert.equal(out.frames.length, 2);
  assert.ok(!("file" in out));
  assert.throws(() => validateReference(ref, []), /1–3/);
  assert.throws(() => validateReference(ref, ["f0", "f1", "f2", "f3"]), /1–3/);
});
test("unsafe image payloads and oversized reference frames are rejected", () => {
  for (const dataUrl of [
    "data:image/svg+xml;base64,AAAA",
    "https://example.test/ref.jpg",
    "data:image/jpeg;base64," + "A".repeat(1400001),
  ])
    assert.throws(
      () =>
        validateReference({ ...ref, frames: [{ ...ref.frames[0], dataUrl }] }, [
          "f0",
        ]),
      /无效|过大/,
    );
});
test("video samples spread over the clip and remain before its end", () => {
  assert.deepEqual(frameTimes(60), [10, 20, 30, 40, 50]);
  assert.ok(frameTimes(0.1).every((t) => t >= 0 && t < 0.1));
  assert.throws(() => frameTimes(Infinity), /时长/);
  assert.throws(() => frameTimes(0), /时长/);
});
test("cross-frame visual candidates deduplicate by note and accumulate frame hits", () => {
  const a = {
    url: "https://www.xiaohongshu.com/explore/abc?xsec_token=SYNTHETIC",
    title: "图集",
    thumbnail: "https://i.test/t.jpg",
  };
  let results = mergeVisualCandidates([], [a, a], "f1", ["xhs"]);
  results = mergeVisualCandidates(
    results,
    [{ ...a, url: "https://www.xiaohongshu.com/discovery/item/abc" }],
    "f2",
    ["xhs"],
  );
  assert.equal(results.length, 1);
  assert.deepEqual(results[0].frameIds, ["f1", "f2"]);
  assert.equal(results[0].user, "");
});
test("platform filters reject search lists, profiles, unsafe links and unselected sources", () => {
  const rows = [
    "https://www.pinterest.com/pin/123/",
    "https://www.pinterest.com/user/",
    "https://www.xiaohongshu.com/explore/abc",
    "javascript:alert(1)",
  ].map((url) => ({ url, thumbnail: "https://i.test/a.jpg" }));
  const out = mergeVisualCandidates([], rows, "f0", ["pinterest"]);
  assert.equal(out.length, 1);
  assert.equal(out[0].platform, "pinterest");
});
test("imported visual results keep account empty and previews as covers", () => {
  const out = candidateWork(
    {
      url: "https://www.pinterest.com/pin/123/",
      title: "参考",
      thumbnail: "https://i.test/thumb.jpg",
      imageUrl: "https://i.test/full.jpg",
    },
    "角色参考",
  );
  assert.equal(out.user, "");
  assert.equal(out.category, "角色参考");
  assert.equal(out.media[0].kind, "cover");
});

test("inline search preview storage stays bounded without losing source links", () => {
  const rows = Array.from({ length: 20 }, (_, i) => ({
    url: "https://www.pinterest.com/pin/" + (900 + i) + "/",
    thumbnail: "data:image/jpeg;base64," + "A".repeat(60000),
  }));
  const out = mergeVisualCandidates([], rows, "f0", ["pinterest"]);
  assert.equal(out.length, 20);
  assert.ok(
    out.reduce(
      (n, x) => n + (x.thumbnail.startsWith("data:") ? x.thumbnail.length : 0),
      0,
    ) <= 512000,
  );
});
test("single platform mode rejects multiple platforms rather than silently searching all", () => {
  assert.deepEqual(selectedPlatforms(["xhs"], "single"), ["xhs"]);
  assert.throws(
    () => selectedPlatforms(["xhs", "douyin"], "single"),
    /一个平台/,
  );
  assert.throws(() => selectedPlatforms([], "single"), /至少/);
  assert.deepEqual(selectedPlatforms(["pdd", "vip"], "multi"), ["pdd", "vip"]);
});

test("native search destinations stay on the selected platform and reject external engines", () => {
  for (const [platform, config] of Object.entries(NATIVE_SEARCH)) {
    assert.ok(nativeHost(config.home, platform));
    assert.ok(!/bing\.com|google\.com/.test(config.home));
  }
  for (const raw of [
    "https://www.bing.com/images",
    "https://www.google.com/search",
    "https://www.xiaohongshu.com.evil.test/explore",
    "http://www.xiaohongshu.com/explore",
    "https://user:pass@www.xiaohongshu.com/explore",
  ])
    assert.equal(nativeHost(raw, "xhs"), false);
  assert.equal(
    nativeHost("https://www.instagram.com/explore/", "instagram"),
    true,
  );
  assert.equal(nativeHost("https://www.douyin.com/", "xhs"), false);
  assert.equal(NATIVE_SEARCH.instagram.status, "unverified");
  assert.throws(() => selectedPlatforms(["web"]), /至少/);
});
test("Instagram candidates are deduplicated by shortcode and exclude profile or non-selected posts", () => {
  const rows = [
    { url: "https://www.instagram.com/p/AbC/" },
    { url: "https://www.instagram.com/creator/reel/AbC/" },
    { url: "https://www.instagram.com/creator/" },
    { url: "https://www.xiaohongshu.com/explore/abc" },
  ];
  const r = mergeVisualCandidates([], rows, "f0", ["instagram"]);
  assert.equal(r.length, 1);
  assert.equal(r[0].platform, "instagram");
});
