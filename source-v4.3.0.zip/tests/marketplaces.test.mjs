import test from "node:test";
import assert from "node:assert/strict";
import {
  platformOf,
  workKey,
  isDetail,
  searchUrl,
  normalizeWork,
  fileName,
  PLATFORMS,
} from "../extension/core.js";
test("Pinduoduo and Vipshop hosts, detail identity and marketplace classification remain distinct", () => {
  const pdd =
      "https://mobile.yangkeduo.com/goods.html?goods_id=123&share_id=SYNTHETIC",
    vip = "https://detail.vip.com/detail-0-456.html";
  assert.equal(platformOf(pdd), "pdd");
  assert.equal(platformOf(vip), "vip");
  assert.ok(isDetail(pdd));
  assert.ok(isDetail(vip));
  assert.equal(
    workKey(pdd),
    workKey("https://mobile.yangkeduo.com/goods1.html?goods_id=123"),
  );
  assert.equal(workKey(vip), workKey("https://m.vip.com/product-0-456.html"));
  for (const url of [
    "https://vip.com.evil.test/detail-0-456.html",
    "https://yangkeduo.com.evil.test/goods.html?goods_id=123",
  ])
    assert.equal(platformOf(url), "web");
  assert.equal(
    isDetail("https://mobile.yangkeduo.com/search_result.html?search_key=123"),
    false,
  );
  assert.equal(isDetail("https://www.vip.com/"), false);
  assert.equal(normalizeWork({ url: pdd }).category, "商品");
  assert.equal(normalizeWork({ url: vip }).category, "商品");
  assert.equal(PLATFORMS.filter((p) => p.id === "tmall").length, 1);
});
test("new marketplaces retain separate search and download destinations", () => {
  assert.equal(
    new URL(searchUrl("pdd", "春日 鞋")).hostname,
    "mobile.yangkeduo.com",
  );
  assert.equal(
    new URL(searchUrl("vip", "春日 鞋")).hostname,
    "category.vip.com",
  );
  const pdd = normalizeWork({
      url: "https://mobile.yangkeduo.com/goods.html?goods_id=123",
      title: "杯子",
      user: "店铺",
    }),
    vip = normalizeWork({
      url: "https://detail.vip.com/detail-0-456.html",
      title: "鞋子",
      user: "商家",
    });
  assert.match(
    fileName(pdd, { kind: "image", url: "https://i.test/a.jpg" }, 0),
    /抓到你啦\/拼多多\/商品\/店铺/,
  );
  assert.match(
    fileName(vip, { kind: "image", url: "https://i.test/a.jpg" }, 0),
    /抓到你啦\/唯品会\/商品\/商家/,
  );
});
test("old generic marketplace records gain platform identity while preserving ids, names and custom categories", async () => {
  let stored = {
    catalogV2: {
      version: 2,
      works: [
        {
          id: "old-pdd",
          platform: "web",
          url: "https://mobile.yangkeduo.com/goods.html?goods_id=123",
          title: "旧标题",
          user: "原店铺",
          category: "我的收藏",
          media: [],
        },
        {
          id: "old-vip",
          platform: "web",
          url: "https://detail.vip.com/detail-0-456.html",
          title: "原鞋子",
          user: "原商家",
          category: "未分类",
          media: [],
        },
      ],
      settings: {},
      categories: ["我的收藏"],
      jobs: [],
      downloads: [],
    },
  };
  globalThis.chrome = {
    storage: {
      local: {
        get: async () => structuredClone(stored),
        set: async (x) => Object.assign(stored, structuredClone(x)),
      },
    },
  };
  const { readState } = await import("../extension/database.js");
  const s = await readState();
  assert.equal(s.works[0].id, "old-pdd");
  assert.equal(s.works[0].platform, "pdd");
  assert.equal(s.works[0].user, "原店铺");
  assert.equal(s.works[0].category, "我的收藏");
  assert.equal(s.works[1].platform, "vip");
  assert.equal(s.works[1].category, "商品");
});
