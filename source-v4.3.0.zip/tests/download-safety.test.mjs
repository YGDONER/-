import test from "node:test";
import assert from "node:assert/strict";
let storage = {},
  counter = 0;
const items = new Map();
const started = [];
globalThis.chrome = {
  storage: {
    local: {
      get: async () => structuredClone(storage),
      set: async (value) => Object.assign(storage, structuredClone(value)),
    },
  },
  downloads: {
    download: async (options) => {
      const id = ++counter;
      started.push(options);
      items.set(id, {
        id,
        ...options,
        state: "in_progress",
        danger: "safe",
        mime: "image/jpeg",
        bytesReceived: 0,
        totalBytes: 100,
      });
      return id;
    },
    search: async ({ id }) =>
      items.has(id) ? [structuredClone(items.get(id))] : [],
    cancel: async (id) => {
      items.get(id).state = "interrupted";
      items.get(id).error = "USER_CANCELED";
    },
    resume: async () => {
      throw new Error("blocked tasks must not be resumed");
    },
    onChanged: { addListener() {} },
    onErased: { addListener() {} },
  },
};
const { transact, latestState, newJob } = await import(
  "../extension/database.js"
);
const { normalizeWork } = await import("../extension/core.js");
const { enqueueWorks, pump, updateDownload, controlDownloads } = await import(
  "../extension/downloads.js"
);
const settle = async () => {
  for (let i = 0; i < 12; i++) await new Promise(setImmediate);
};
async function fixture(id) {
  const work = normalizeWork({
    url: `https://www.instagram.com/p/Case_${id}/`,
    title: "ins轮播",
    user: "发布者",
    media: [
      { url: `https://scontent.cdninstagram.com/${id}.jpg`, kind: "image" },
    ],
  });
  await transact((s) => {
    s.works = [work];
    s.downloads = [];
    s.settings = { paused: false, concurrency: 1 };
  });
  await enqueueWorks([work.id], false);
  await settle();
  return (await latestState()).downloads[0];
}
await test("browser malware verdict cancels the file and survives retry/resume and later events", async () => {
  const job = await fixture(1);
  const before = started.length;
  items.get(job.downloadId).danger = "content";
  await updateDownload(job.downloadId);
  assert.equal(items.get(job.downloadId).state, "interrupted");
  await controlDownloads("retry", [job.id]);
  await controlDownloads("resume", [job.id]);
  items.get(job.downloadId).danger = "accepted";
  items.get(job.downloadId).state = "complete";
  await updateDownload(job.downloadId);
  await settle();
  const current = (await latestState()).downloads[0];
  assert.equal(current.state, "blocked");
  assert.equal(current.safetyBlocked, true);
  assert.equal(started.length, before);
});
await test("asynchronous browser scan does not become a completed media download prematurely", async () => {
  const job = await fixture(2);
  Object.assign(items.get(job.downloadId), {
    state: "complete",
    danger: "asyncScanning",
  });
  await updateDownload(job.downloadId);
  assert.equal((await latestState()).downloads[0].state, "checking");
  items.get(job.downloadId).danger = "deepScannedSafe";
  await updateDownload(job.downloadId);
  assert.equal((await latestState()).downloads[0].state, "completed");
});
await test("upgrading never launches an executable URL already stored in the legacy queue", async () => {
  const before = started.length;
  await transact((s) => {
    s.downloads = [
      newJob({
        url: "https://cdn.test/start.ps1",
        assetKind: "image",
        filename: "old.jpg",
        downloadId: null,
      }),
    ];
  });
  await pump();
  await settle();
  assert.equal(started.length, before);
  assert.equal((await latestState()).downloads[0].state, "blocked");
});
await test("a media redirect to a program is stopped even when the first URL and MIME look like a photo", async () => {
  const job = await fixture(3);
  items.get(job.downloadId).finalUrl = "https://cdn.test/program.exe";
  await updateDownload(job.downloadId);
  assert.equal((await latestState()).downloads[0].state, "blocked");
  assert.equal(items.get(job.downloadId).state, "interrupted");
});
