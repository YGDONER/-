import test from "node:test";
import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
const root = new URL("../extension/", import.meta.url);
test("extension permissions and CSP restrict active code to the installed package", async () => {
  const manifest = JSON.parse(
    await readFile(new URL("manifest.json", root), "utf8"),
  );
  for (const permission of [
    "cookies",
    "nativeMessaging",
    "debugger",
    "webRequestBlocking",
    "clipboardRead",
  ])
    assert.ok(!manifest.permissions.includes(permission));
  assert.ok(manifest.host_permissions.includes("https://*.instagram.com/*"));
  assert.equal(manifest.externally_connectable, undefined);
  const policy = Object.fromEntries(
    manifest.content_security_policy.extension_pages
      .split(";")
      .filter(Boolean)
      .map((rule) => {
        const [name, ...values] = rule.trim().split(/\s+/);
        return [name, values];
      }),
  );
  assert.deepEqual(policy["script-src"], ["'self'"]);
  for (const name of [
    "connect-src",
    "object-src",
    "frame-src",
    "base-uri",
    "form-action",
  ])
    assert.deepEqual(policy[name], ["'none'"]);
});
test("packaged pages have no remote or inline scripts and no active embeds", async () => {
  for (const file of await readdir(root)) {
    if (!file.endsWith(".html")) continue;
    const html = await readFile(new URL(file, root), "utf8");
    assert.doesNotMatch(html, /<(?:iframe|object|embed|base)\b/i);
    assert.doesNotMatch(html, /\son[a-z]+\s*=/i);
    for (const match of html.matchAll(
      /<script\b([^>]*)>([\s\S]*?)<\/script>/gi,
    )) {
      assert.equal(match[2].trim(), "");
      const src = match[1].match(/\bsrc=["']([^"']+)["']/i)?.[1];
      assert.ok(
        src &&
          !src.includes(":") &&
          !src.startsWith("//") &&
          !src.startsWith("/"),
      );
      assert.ok((await readFile(new URL(src, root))).length > 0);
    }
  }
});
