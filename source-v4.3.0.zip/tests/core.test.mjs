import test from "node:test";
import assert from "node:assert/strict";
import {
  platformOf,
  parseInputs,
  normalizeWork,
  mergeWorks,
  workKey,
  searchUrl,
  downloadCandidates,
  safeSegment,
  fileName,
  tableText,
  csvText,
  cleanMedia,
} from "../extension/core.js";
test("P站 means Pinterest; strict platform host classification", () => {
  for (const [url, p] of [
    ["https://www.pinterest.com/pin/123/", "pinterest"],
    ["https://pin.it/abc", "pinterest"],
    ["https://www.pinterest.co.uk/pin/123/", "pinterest"],
    ["https://www.xiaohongshu.com/explore/abc", "xhs"],
    ["https://v.douyin.com/a/", "douyin"],
    ["https://item.taobao.com/item.htm?id=7", "taobao"],
    ["https://detail.tmall.com/item.htm?id=7", "tmall"],
    ["https://www.pixiv.net/artworks/1", "web"],
    ["https://pinterest.com.evil.test/pin/1/", "web"],
  ])
    assert.equal(platformOf(url), p);
});
test("user is publishing nickname from approved share, including emoji and parentheses", () => {
  const rows = parseInputs(
    "83 【叫我什么 姐姐？ - 卿颂Fafa📷（厦门陪拍） | 小红书 - 你的生活兴趣社区】 😆 abc 😆 https\\://www\\.xiaohongshu.com/discovery/item/6a913d5700000000250265a8?xsec_token=SYNTHETIC_TOKEN",
  );
  assert.equal(rows.length, 1);
  assert.equal(rows[0].title, "叫我什么 姐姐？");
  assert.equal(rows[0].user, "卿颂Fafa📷（厦门陪拍）");
  assert.ok(rows[0].url.endsWith("SYNTHETIC_TOKEN"));
});
test("mixed batch keeps platforms and leaves bare URL author empty", () => {
  const rows = parseInputs(
    "【拍照 - 小张 | 小红书】 https://www.xiaohongshu.com/explore/abcdef\nhttps://www.pinterest.com/pin/123/\nhttps://www.douyin.com/video/456\nhttps://item.taobao.com/item.htm?id=7\nhttps://detail.tmall.com/item.htm?id=8",
  );
  assert.equal(rows.length, 5);
  assert.deepEqual(rows.map((w) => w.platform).sort(), [
    "douyin",
    "pinterest",
    "taobao",
    "tmall",
    "xhs",
  ]);
  assert.equal(rows.find((w) => w.platform === "pinterest").title, "");
  assert.equal(rows.find((w) => w.platform === "douyin").user, "");
});
test("old backup nickname migration and canonical URL dedup preserve tokens", () => {
  const [w] = parseInputs(
    JSON.stringify([
      {
        url: "https://www.xiaohongshu.com/explore/abc?xsec_token=one",
        title: "题目",
        accountName: "博主",
      },
    ]),
  );
  assert.equal(w.user, "博主");
  const r = mergeWorks(
    [w],
    [
      {
        url: "https://www.xiaohongshu.com/discovery/item/abc?xsec_token=two",
        title: "新题目",
      },
    ],
  );
  assert.equal(r.works.length, 1);
  assert.equal(r.works[0].id, w.id);
  assert.equal(r.works[0].user, "博主");
  assert.ok(r.works[0].url.endsWith("two"));
});
test("platform keyword searches use encoded keywords", () => {
  for (const p of ["pinterest", "xhs", "douyin", "taobao", "tmall"])
    assert.ok(
      searchUrl(p, "美食 & 镜头").includes(encodeURIComponent("美食 & 镜头")),
    );
  assert.throws(() => searchUrl("pinterest", " "));
});
test("unsafe media and manifests are filtered, covers are opt-in", () => {
  const w = normalizeWork({
    url: "https://www.pinterest.com/pin/123/",
    media: [
      { url: "javascript:alert(1)", kind: "image" },
      { url: "blob:https://a.test/a", kind: "video" },
      { url: "https://i.test/a.jpg", kind: "cover" },
      { url: "https://v.test/a.m3u8?x=1", kind: "video" },
      { url: "https://v.test/a.mp4", kind: "video" },
      { url: "https://v.test/a.mp4", kind: "video" },
    ],
  });
  assert.equal(w.media.length, 3);
  assert.equal(downloadCandidates([w]).length, 1);
  assert.equal(downloadCandidates([w], true).length, 2);
  assert.match(
    w.media.find((m) => m.url.includes("m3u8")).blockedReason,
    /不合并/,
  );
});
test("download paths stay relative with Windows-safe segments", () => {
  const w = normalizeWork({
    url: "https://www.douyin.com/video/123",
    title: "../../秘密:题目",
    user: "CON",
    category: "../../a",
  });
  const name = fileName(
    w,
    { url: "https://media.test/stream?token=abc", kind: "video" },
    0,
  );
  assert.ok(name.startsWith("抓到你啦/抖音/"));
  assert.ok(name.endsWith("/001_素材.mp4"));
  assert.ok(!name.includes(".."));
  assert.ok(!/[\\:]/.test(name));
  assert.equal(safeSegment("CON"), "_CON");
});
test("three columns exact mapping and CSV formula escaping", () => {
  const w = normalizeWork({
    url: "https://www.pinterest.com/pin/1/",
    title: '=HYPERLINK("evil")\n题目',
    user: "@账号",
  });
  const cells = tableText([w]).split("\t");
  assert.equal(cells.length, 3);
  assert.equal(cells[0], w.url);
  assert.ok(cells[1].startsWith("'="));
  assert.ok(cells[2].startsWith("'@"));
  assert.ok(csvText([w]).startsWith("\uFEFF"));
  assert.equal(
    workKey("https://item.taobao.com/item.htm?id=2&foo=3"),
    "taobao:2",
  );
});
test("later search thumbnails never replace parsed gallery or custom category", () => {
  const old = normalizeWork({
    url: "https://www.pinterest.com/pin/1/",
    title: "标题",
    category: "我的拍摄参考",
    media: [{ url: "https://i.test/original.jpg", kind: "image" }],
  });
  const incoming = normalizeWork({
    url: old.url,
    source: "search-list",
    media: [{ url: "https://i.test/small.jpg", kind: "cover" }],
  });
  const w = mergeWorks([old], [incoming]).works[0];
  assert.equal(w.media[0].url, "https://i.test/original.jpg");
  assert.equal(w.category, "我的拍摄参考");
  assert.equal(w.type, "image");
  assert.deepEqual(cleanMedia(null), []);
});
test("typed download plan skips known image-only works for video-only downloads", async () => {
  const { buildDownloadPlan } = await import("../extension/core.js");
  const image = normalizeWork({
      url: "https://www.pinterest.com/pin/51/",
      media: [{ url: "https://i.test/a.jpg", kind: "image" }],
    }),
    video = normalizeWork({
      url: "https://www.douyin.com/video/52",
      media: [
        { url: "https://v.test/v.mp4", kind: "video" },
        { url: "https://i.test/cover.jpg", kind: "cover" },
      ],
    }),
    pending = normalizeWork({
      url: "https://www.xiaohongshu.com/explore/53",
      media: [],
    });
  const plan = buildDownloadPlan([image, video, pending], {
    mediaKinds: ["video"],
  });
  assert.deepEqual(
    plan.ready.map((w) => w.id),
    [video.id],
  );
  assert.deepEqual(
    plan.pending.map((w) => w.id),
    [pending.id],
  );
  assert.deepEqual(
    plan.skipped.map((w) => w.id),
    [image.id],
  );
  assert.equal(plan.assets.length, 1);
});
