import { setupVisualUI } from "./visual-ui.js";
import { setupNoteGallery } from "./note-gallery.js";
import { setupTools } from "./workspace-tools.js";
import {
  PLATFORMS,
  CATEGORIES,
  downloadCandidates,
  tableText,
  csvText,
  parseInputs,
} from "./core.js";
const $ = (id) => document.getElementById(id),
  full = new URLSearchParams(location.search).get("view") === "full";
document.body.classList.toggle("full", full);
document.body.classList.toggle("popup", !full);
$("open-full").hidden = full;
let state = {
    works: [],
    jobs: [],
    downloads: [],
    categories: [...CATEGORIES],
    settings: {},
  },
  selected = new Set(),
  view = "library",
  detailId = "",
  tabs = [],
  toastTimer,
  polling = false;
let tools, noteGallery, visualUI;
const names = Object.fromEntries(PLATFORMS.map((p) => [p.id, p.name]));
const statuses = {
  pending: "等待中",
  starting: "正在启动",
  in_progress: "下载中",
  paused: "已暂停",
  completed: "已完成",
  failed: "失败",
  blocked: "已拦截",
  checking: "安全检查中",
  cancelled: "已取消",
  processing: "解析中",
  loading: "加载页面",
  collecting: "采集中",
  attention: "待处理",
};
function node(tag, cls, text) {
  const el = document.createElement(tag);
  if (cls) el.className = cls;
  if (text !== undefined) el.textContent = text;
  return el;
}
function button(text, action, cls = "text-button") {
  const b = node("button", cls, text);
  b.addEventListener("click", () => run(() => action(b), b));
  return b;
}
function toast(message) {
  $("toast").textContent = message;
  $("toast").hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($("toast").hidden = true), 5000);
}
async function run(fn, b) {
  if (b) b.disabled = true;
  try {
    return await fn();
  } catch (e) {
    toast(e.message || "操作失败，请重试");
  } finally {
    if (b) b.disabled = false;
  }
}
async function send(type, data = {}) {
  const result = await chrome.runtime.sendMessage({ type, ...data });
  if (!result?.ok)
    throw new Error(result?.message || "后台没有响应，请重新打开插件");
  if (result.state) applyState(result.state);
  return result;
}
function options(select, items, first) {
  const old = select.value;
  select.replaceChildren();
  if (first) select.add(new Option(first[1], first[0]));
  for (const x of items) select.add(new Option(x.name || x, x.id || x));
  if ([...select.options].some((o) => o.value === old)) select.value = old;
}
function applyState(s) {
  state = s;
  selected = new Set(
    [...selected].filter((id) => s.works.some((w) => w.id === id)),
  );
  render();
}
function categories() {
  return [
    ...new Set([...state.categories, ...state.works.map((w) => w.category)]),
  ].filter(Boolean);
}
function filtered() {
  const q = $("filter-text").value.toLowerCase(),
    p = $("filter-platform").value,
    c = $("filter-category").value,
    t = $("filter-type").value;
  return state.works
    .filter(
      (w) =>
        (p === "all" || w.platform === p) &&
        (c === "all" || w.category === c) &&
        (t === "all" || w.type === t) &&
        (!q ||
          [w.title, w.user, ...w.tags, w.url]
            .join(" ")
            .toLowerCase()
            .includes(q)),
    )
    .sort((a, b) => b.updatedAt - a.updatedAt);
}
function targets() {
  return selected.size
    ? state.works.filter((w) => selected.has(w.id))
    : filtered();
}
function setView(name) {
  if (name === "visual" && !full) {
    void chrome.tabs.create({
      url: chrome.runtime.getURL("app.html?view=full&tool=visual"),
    });
    return;
  }
  view = name;
  for (const key of [
    "library",
    "categories",
    "images",
    "download",
    "search",
    "queue",
    "updates",
    "visual",
  ])
    $(key + "-view").hidden = key !== name;
  for (const b of document.querySelectorAll("[data-view]"))
    b.classList.toggle("active", b.dataset.view === name);
  $("breadcrumb").textContent = {
    library: "自动收录",
    categories: "分类管理",
    images: "图片批量抓取",
    download: "一键下载",
    search: "跨平台检索",
    queue: "下载队列",
    updates: "版本与更新",
    visual: "以图／视频找相似",
  }[name];
  render();
  if (name === "images") void run(refreshTabs);
  if (name === "updates") void tools.refreshUpdate();
}
function render() {
  options($("filter-category"), categories(), ["all", "全部分类"]);
  options($("bulk-category"), categories());
  $("nav-count").textContent = state.works.length;
  $("nav-downloads").textContent = state.downloads.filter((j) =>
    ["pending", "starting", "in_progress", "paused", "checking"].includes(
      j.state,
    ),
  ).length;
  $("stat-works").textContent = state.works.length;
  $("stat-assets").textContent = state.works.reduce(
    (n, w) => n + w.media.filter((a) => a.kind !== "cover").length,
    0,
  );
  $("stat-done").textContent = state.downloads.filter(
    (j) => j.state === "completed",
  ).length;
  $("stat-pending").textContent = state.works.filter(
    (w) => !downloadCandidates([w]).length,
  ).length;
  $("include-covers").checked = !!state.settings.includeCovers;
  $("concurrency").value = String(state.settings.concurrency || 2);
  renderLibrary();
  if (view === "search") renderJobs();
  if (view === "queue") renderDownloads();
  tools?.render();
  noteGallery?.render();
  if ($("detail").open)
    renderOtherMedia(state.works.find((w) => w.id === detailId));
  visualUI?.render();
}
function renderLibrary() {
  const works = filtered();
  $("total").textContent = works.length;
  $("selected-count").textContent = `${selected.size} 条已选`;
  $("select-all").checked =
    works.length > 0 && works.every((w) => selected.has(w.id));
  $("select-all").indeterminate =
    works.some((w) => selected.has(w.id)) && !$("select-all").checked;
  $("cards").replaceChildren();
  $("empty").hidden = !!works.length;
  $("library-status").textContent = selected.size
    ? `操作范围：已选 ${selected.size} 条作品`
    : `操作范围：当前筛选 ${works.length} 条作品 · 本机自动保存`;
  for (const id of ["copy", "export", "parse", "download"])
    $(id).disabled = !targets().length;
  for (const id of ["remove", "apply-category"])
    $(id).disabled = !selected.size;
  for (const w of works) {
    const card = node("article", "material-card"),
      visual = node("button", "card-visual");
    visual.setAttribute("aria-label", "查看素材详情：" + (w.title || "未命名"));
    visual.addEventListener("click", () => openDetail(w.id));
    const cover = w.media.find((a) => a.kind === "image" || a.kind === "cover");
    if (cover) {
      const im = node("img");
      im.src = cover.url;
      im.alt = "";
      im.loading = "lazy";
      im.referrerPolicy = "no-referrer";
      im.addEventListener(
        "error",
        () => {
          im.remove();
          visual.classList.add("no-preview");
        },
        { once: true },
      );
      visual.append(im);
    } else {
      visual.classList.add("no-preview");
      visual.append(
        node("span", "placeholder-glyph", w.type === "video" ? "▷" : "▧"),
        node("small", "", w.media.length ? "查看资源" : "待解析预览"),
      );
    }
    const pill = node("span", "platform-pill", names[w.platform] || "网页");
    pill.style.setProperty(
      "--platform",
      PLATFORMS.find((p) => p.id === w.platform)?.color || "#718096",
    );
    visual.append(pill);
    if (w.media.some((a) => a.kind === "video"))
      visual.append(node("span", "video-pill", "▶ 视频"));
    card.append(visual);
    const check = node("input");
    check.type = "checkbox";
    check.checked = selected.has(w.id);
    check.setAttribute("aria-label", "选择：" + (w.title || w.url));
    check.addEventListener("change", () => {
      check.checked ? selected.add(w.id) : selected.delete(w.id);
      renderLibrary();
    });
    const checkWrap = node("label", "card-select");
    checkWrap.append(check);
    card.append(checkWrap);
    const info = node("div", "card-info"),
      title = node("button", "card-title", w.title || "未命名作品");
    title.addEventListener("click", () => openDetail(w.id));
    info.append(
      title,
      node("p", "account-name", "＠ " + (w.user || "发布账号待补全")),
    );
    const bottom = node("div", "card-bottom");
    bottom.append(
      node("span", "category-tag", w.category),
      node(
        "span",
        "asset-count",
        `${w.media.filter((m) => m.kind === "image").length} 图 · ${w.media.filter((m) => m.kind === "video").length} 视频`,
      ),
    );
    info.append(
      bottom,
      button("挑图下载", () => openDetail(w.id), "card-pick-images"),
    );
    if (w.error) info.append(node("p", "card-warning", w.error));
    card.append(info);
    $("cards").append(card);
  }
}
function openDetail(id) {
  const w = state.works.find((w) => w.id === id);
  if (!w) return;
  const reset = detailId !== id || !$("detail").open;
  detailId = id;
  $("edit-title").value = w.title;
  $("edit-user").value = w.user;
  options($("edit-category"), categories());
  $("edit-category").value = w.category;
  $("new-category").value = "";
  $("source-link").href = w.url;
  $("detail-error").textContent =
    w.error ||
    (!w.media.length ? "还未解析到资源，可在素材库选中后批量解析。" : "");
  renderOtherMedia(w);
  if (!$("detail").open) $("detail").showModal();
  noteGallery.open(id, { reset });
}
let detailMediaSignature = "";
function renderOtherMedia(w) {
  const sig = JSON.stringify([w?.id, w?.media]);
  if (sig === detailMediaSignature) return;
  detailMediaSignature = sig;
  if (!w) {
    $("media-list").replaceChildren();
    $("other-media-heading").hidden = true;
    return;
  }
  $("media-list").replaceChildren();
  w.media.forEach((a, i) => {
    if (a.kind === "image") return;
    const row = node("div", "media-row");
    const media = node("div", "media-thumb");
    if (a.kind === "image" || a.kind === "cover") {
      const im = node("img");
      im.src = a.url;
      im.alt = "";
      im.loading = "lazy";
      im.referrerPolicy = "no-referrer";
      media.append(im);
    } else media.append(node("span", "", a.kind === "video" ? "▷" : "▧"));
    const info = node("div", "media-info");
    info.append(
      node(
        "strong",
        "",
        `${String(i + 1).padStart(2, "0")} · ${{ image: "图片", video: "视频", cover: "封面", archive: "压缩包" }[a.kind]}`,
      ),
    );
    const link = node("a", "media-url", new URL(a.url).hostname);
    link.href = a.url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    info.append(link);
    if (a.blockedReason) info.append(node("small", "danger", a.blockedReason));
    const b = button("↓ 保存", async () => {
      const r = await send("DOWNLOAD_ASSET", { workId: w.id, index: i });
      toast(r.queued ? "已加入下载队列" : "该资源已在队列中");
    });
    b.disabled = !!a.blockedReason;
    row.append(media, info, b);
    $("media-list").append(row);
  });
  $("other-media-heading").hidden = !w.media.some((a) => a.kind !== "image");
}
function jobTitle(j) {
  if (j.mediaKinds?.length === 1 && j.mediaKinds[0] === "image")
    return "图集抓取 · " + (j.title || j.url);
  return j.kind === "search"
    ? `${names[j.platform]} · ${j.keyword}`
    : `解析 · ${j.title || j.url}`;
}
function renderJobs() {
  $("jobs").replaceChildren();
  if (!state.jobs.length) {
    $("jobs").append(
      node("div", "empty compact", "检索与解析任务会显示在这里。"),
    );
    return;
  }
  for (const j of [...state.jobs].reverse()) {
    const row = node("article", "job-row"),
      icon = node("div", "job-icon", j.kind === "search" ? "⌕" : "↻"),
      info = node("div", "job-info");
    info.append(
      node("strong", "", jobTitle(j)),
      node("p", "", j.error || `${j.count || 0} 项结果`),
    );
    const side = node("div", "job-actions");
    side.append(
      node("span", "status " + j.state, statuses[j.state] || j.state),
      button("打开页面 ↗", () => send("JOB_OPEN", { id: j.id })),
    );
    if (["attention", "failed", "completed"].includes(j.state))
      side.append(button("重新采集", () => send("JOB_RETRY", { id: j.id })));
    row.append(icon, info, side);
    $("jobs").append(row);
  }
}
const bytes = (n) =>
  n >= 1073741824
    ? (n / 1073741824).toFixed(1) + " GB"
    : n >= 1048576
      ? (n / 1048576).toFixed(1) + " MB"
      : n >= 1024
        ? (n / 1024).toFixed(0) + " KB"
        : (n || 0) + " B";
function renderDownloads() {
  const jobs = state.downloads,
    done = jobs.filter((j) => j.state === "completed").length,
    active = jobs.filter((j) =>
      ["starting", "in_progress"].includes(j.state),
    ).length,
    failed = jobs.filter((j) => j.state === "failed").length,
    blocked = jobs.filter((j) => j.state === "blocked").length,
    checking = jobs.filter((j) => j.state === "checking").length;
  $("queue-summary").textContent =
    `${jobs.length} 个文件 · ${done} 完成 · ${active} 下载中 · ${checking} 安全检查中 · ${blocked} 已拦截 · ${failed} 失败${state.settings.paused ? " · 队列已暂停" : ""}`;
  $("download-list").replaceChildren();
  if (!jobs.length) {
    $("download-list").append(
      node("div", "empty compact", "选中素材，点击「一键下载」开始保存。"),
    );
    return;
  }
  for (const j of [...jobs].reverse()) {
    const row = node("article", "download-row"),
      icon = node("div", "job-icon", j.assetKind === "video" ? "▷" : "▧"),
      info = node("div", "download-info");
    info.append(
      node("strong", "", j.title || "未命名作品"),
      node("small", "file-path", j.filename),
    );
    const progress = node("progress");
    progress.max = j.totalBytes || 100;
    progress.value =
      j.state === "completed"
        ? progress.max
        : j.totalBytes
          ? j.bytesReceived
          : 0;
    progress.setAttribute("aria-label", "下载进度");
    info.append(
      progress,
      node(
        "p",
        j.error ? "danger" : "muted",
        j.error ||
          `${bytes(j.bytesReceived)}${j.totalBytes ? " / " + bytes(j.totalBytes) : " · 等待服务器提供总大小"}`,
      ),
    );
    const actions = node("div", "download-actions");
    actions.append(
      node("span", "status " + j.state, statuses[j.state] || j.state),
    );
    const control = (title, action) =>
      button(title, () => send("DOWNLOAD_CONTROL", { action, ids: [j.id] }));
    if (j.state === "in_progress") actions.append(control("暂停", "pause"));
    if (j.state === "paused") actions.append(control("继续", "resume"));
    if (["failed", "cancelled"].includes(j.state))
      actions.append(control("重试", "retry"));
    if (["pending", "in_progress", "paused", "checking"].includes(j.state))
      actions.append(control("取消", "cancel"));
    if (j.state === "completed")
      actions.append(
        button("打开文件夹", () => send("SHOW_FILE", { id: j.id })),
      );
    row.append(icon, info, actions);
    $("download-list").append(row);
  }
}
async function refreshTabs() {
  const r = await send("TABS");
  tabs = r.tabs;
  for (const id of ["source-tab", "image-tab"]) {
    const select = $(id),
      old = select.value;
    select.replaceChildren();
    for (const t of tabs)
      select.add(new Option(`${names[t.platform]} · ${t.title}`, String(t.id)));
    if (tabs.some((t) => String(t.id) === old)) select.value = old;
    else {
      const active = tabs.find((t) => t.active);
      if (active) select.value = String(active.id);
    }
  }
  if (!tabs.length)
    $("capture-hint").textContent =
      "请先打开作品或搜索结果网页，再刷新标签页。";
  return tabs;
}
function blobDownload(content, name, type) {
  const url = URL.createObjectURL(new Blob([content], { type })),
    a = node("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
for (const b of document.querySelectorAll("[data-view]"))
  b.addEventListener("click", () => setView(b.dataset.view));
options($("filter-platform"), PLATFORMS, ["all", "全部平台"]);
for (const p of PLATFORMS) {
  const b = button(
    p.name,
    () => {
      setView("library");
      $("filter-platform").value = p.id;
      renderLibrary();
    },
    "platform-nav-button",
  );
  const dot = node("span", "platform-dot");
  dot.style.background = p.color;
  b.prepend(dot);
  $("platform-nav").append(b);
  if (p.id !== "web") {
    const label = node("label", "platform-choice"),
      input = node("input");
    input.type = "checkbox";
    input.value = p.id;
    input.checked = true;
    label.append(
      input,
      node("span", "platform-dot"),
      document.createTextNode(p.name),
    );
    label.querySelector("span").style.background = p.color;
    $("search-platforms").append(label);
  }
}
for (const id of [
  "filter-text",
  "filter-platform",
  "filter-category",
  "filter-type",
])
  $(id).addEventListener(
    id === "filter-text" ? "input" : "change",
    renderLibrary,
  );
$("select-all").addEventListener("change", () => {
  for (const w of filtered())
    $("select-all").checked ? selected.add(w.id) : selected.delete(w.id);
  renderLibrary();
});
$("toggle-capture").addEventListener("click", () =>
  run(async () => {
    $("capture-panel").hidden = !$("capture-panel").hidden;
    if (!$("capture-panel").hidden) await refreshTabs();
  }),
);
$("refresh-tabs").addEventListener("click", () =>
  run(refreshTabs, $("refresh-tabs")),
);
$("grant-site").addEventListener("click", async () => {
  const tab = tabs.find((t) => String(t.id) === $("source-tab").value);
  if (!tab) return toast("请先选择网页");
  try {
    const granted = await chrome.permissions.request({
      origins: [new URL(tab.url).origin + "/*"],
    });
    if (granted) await send("AUTO_SITE", { tabId: tab.id });
    toast(granted ? "该网站已授权并启用自动收录" : "未授予网站访问权限");
  } catch (e) {
    toast(e.message);
  }
});
$("capture").addEventListener("click", () =>
  run(async () => {
    if (!$("source-tab").value) throw new Error("请先选择需要采集的标签页");
    const r = await send("CAPTURE", {
      tabId: Number($("source-tab").value),
      mode: $("capture-mode").value,
      rounds: Number($("capture-rounds").value),
    });
    toast(
      `${r.message || "采集完成"} · 新增 ${r.added} 条，更新 ${r.merged} 条`,
    );
    setView("library");
  }, $("capture")),
);
$("demo").addEventListener("click", () => {
  $("paste").value =
    "83 【叫我什么 姐姐？ - 卿颂Fafa📷（厦门陪拍） | 小红书 - 你的生活兴趣社区】 https://www.xiaohongshu.com/discovery/item/6a913d5700000000250265a8";
});
$("import-paste").addEventListener("click", () =>
  run(async () => {
    const r = await send("ADD", { text: $("paste").value });
    if (!r.added && !r.merged)
      throw new Error("没有识别到链接，请粘贴完整网址或分享文案");
    $("paste").value = "";
    toast(`已新增 ${r.added} 条，更新 ${r.merged} 条`);
  }, $("import-paste")),
);
$("copy").addEventListener("click", () =>
  run(async () => {
    const text = tableText(targets());
    try {
      await navigator.clipboard.writeText(text);
      toast(`已复制 ${targets().length} 条：素材地址、标题、用户`);
    } catch {
      $("copy-text").value = text;
      $("copy-fallback").showModal();
      $("copy-text").focus();
      $("copy-text").select();
    }
  }),
);
$("close-copy").addEventListener("click", () => $("copy-fallback").close());
$("export").addEventListener("click", () =>
  blobDownload(
    csvText(targets()),
    "抓到你啦_分类清单.csv",
    "text/csv;charset=utf-8",
  ),
);
$("backup").addEventListener("click", () =>
  blobDownload(
    JSON.stringify(
      { type: "link-notes-v2", version: 2, works: state.works },
      null,
      2,
    ),
    "抓到你啦_完整备份.json",
    "application/json",
  ),
);
$("import-backup").addEventListener("click", () => $("backup-file").click());
$("backup-file").addEventListener("change", () =>
  run(async () => {
    const f = $("backup-file").files[0];
    if (!f) return;
    if (f.size > 10000000) throw new Error("请导入小于 10 MB 的清单");
    const works = parseInputs(await f.text());
    if (!works.length) throw new Error("备份中没有可用作品链接");
    let added = 0;
    for (let i = 0; i < works.length; i += 500) {
      const r = await send("ADD", { works: works.slice(i, i + 500) });
      added += r.added;
    }
    $("backup-file").value = "";
    toast(`导入完成，新增 ${added} 条`);
  }),
);
$("parse").addEventListener("click", () =>
  run(async () => {
    const r = await send("PARSE", {
      ids: targets().map((w) => w.id),
      includeCovers: $("include-covers").checked,
    });
    toast(`已提交 ${r.queued} 条解析任务，可在跨平台检索查看进度`);
  }, $("parse")),
);
$("download").addEventListener("click", () => setView("download"));
$("classify-shortcut").addEventListener("click", () => setView("categories"));
$("images-shortcut").addEventListener("click", () => setView("images"));
$("include-covers").addEventListener("change", () =>
  run(() => send("SETTINGS", { includeCovers: $("include-covers").checked })),
);
$("apply-category").addEventListener("click", () =>
  run(async () => {
    const value = $("bulk-category").value;
    await send("CATEGORY", {
      action: "assign",
      name: value,
      ids: [...selected],
    });
    toast("分类已更新");
  }, $("apply-category")),
);
$("remove").addEventListener("click", () => $("confirm").showModal());
$("cancel-remove").addEventListener("click", () => $("confirm").close());
$("confirm-remove").addEventListener("click", () =>
  run(async () => {
    await send("REMOVE", { ids: [...selected] });
    selected.clear();
    $("confirm").close();
    toast("已移除所选记录");
  }),
);
$("close-detail").addEventListener("click", () => $("detail").close());
$("save-detail").addEventListener("click", () =>
  run(async () => {
    const fields = {
      title: $("edit-title").value,
      user: $("edit-user").value,
      category: $("new-category").value.trim() || $("edit-category").value,
    };
    for (const [field, value] of Object.entries(fields))
      await send("UPDATE", { id: detailId, field, value });
    toast("已保存发布账号及分类");
    openDetail(detailId);
  }, $("save-detail")),
);
$("empty-search").addEventListener("click", () => setView("search"));
$("search-start").addEventListener("click", () =>
  run(async () => {
    const platforms = [
      ...document.querySelectorAll("#search-platforms input:checked"),
    ].map((i) => i.value);
    const r = await send("SEARCH", {
      keywords: $("keywords").value,
      platforms,
      limit: Number($("search-limit").value),
      rounds: Number($("search-rounds").value),
    });
    toast(`已创建 ${r.created} 个检索任务`);
  }, $("search-start")),
);
$("clear-jobs").addEventListener("click", () => run(() => send("CLEAR_JOBS")));
$("concurrency").addEventListener("change", () =>
  run(() => send("SETTINGS", { concurrency: Number($("concurrency").value) })),
);
for (const [id, action] of [
  ["pause-all", "pause"],
  ["resume-all", "resume"],
  ["retry-failed", "retry"],
  ["clear-downloads", "clearFinished"],
])
  $(id).addEventListener("click", () =>
    run(() => send("DOWNLOAD_CONTROL", { action }), $(id)),
  );
const help = () =>
  chrome.tabs.create({ url: chrome.runtime.getURL("help.html") });
$("help").addEventListener("click", help);
$("help-side").addEventListener("click", help);
$("open-full").addEventListener("click", () =>
  chrome.tabs.create({ url: chrome.runtime.getURL("app.html?view=full") }),
);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.catalogV2?.newValue)
    applyState(changes.catalogV2.newValue);
});
setInterval(async () => {
  if (polling || document.hidden) return;
  const active =
    state.jobs.some((j) =>
      ["pending", "processing", "loading", "collecting"].includes(j.state),
    ) ||
    state.downloads.some((j) =>
      ["pending", "starting", "in_progress", "paused"].includes(j.state),
    );
  if (!active && view !== "queue") return;
  polling = true;
  try {
    await send("GET");
  } catch {
  } finally {
    polling = false;
  }
}, 2500);
noteGallery = setupNoteGallery({
  getState: () => state,
  send,
  run,
  toast,
  node,
});
tools = setupTools({
  getState: () => state,
  getView: () => view,
  targets,
  categories,
  setView,
  send,
  run,
  toast,
  node,
  button,
  options,
  refreshTabs,
});
visualUI = setupVisualUI({
  getState: () => state,
  getView: () => view,
  send,
  run,
  toast,
  node,
  button,
  options,
  categories,
  openDetail,
});
await run(() => send("GET"));
if (new URLSearchParams(location.search).get("tool") === "visual")
  setView("visual");
