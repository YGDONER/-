import { parseInput as parseXhs } from "./legacy-notes.js";
import { mediaUrlProblem } from "./media-policy.js";
export const PLATFORMS = [
  { id: "pinterest", name: "Pinterest", color: "#bd2137" },
  { id: "instagram", name: "Instagram（ins）", color: "#bd3d86" },
  { id: "xhs", name: "小红书", color: "#e65d6e" },
  { id: "douyin", name: "抖音", color: "#34465c" },
  { id: "taobao", name: "淘宝", color: "#f1994e" },
  { id: "tmall", name: "天猫", color: "#ca4558" },
  { id: "pdd", name: "拼多多", color: "#df4235" },
  { id: "vip", name: "唯品会", color: "#c72a86" },
  { id: "web", name: "通用网页", color: "#7b8ea5" },
];
export const CATEGORIES = [
  "未分类",
  "灵感参考",
  "摄影/镜头",
  "角色/IP",
  "美食",
  "穿搭",
  "商品",
  "教程",
];
export const uid = () =>
  globalThis.crypto?.randomUUID?.() ||
  Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
export function httpUrl(raw, base) {
  try {
    const u = new URL(raw, base);
    return ["http:", "https:"].includes(u.protocol) &&
      !u.username &&
      !u.password
      ? u.href
      : "";
  } catch {
    return "";
  }
}
export function platformOf(raw) {
  try {
    const h = new URL(raw).hostname.toLowerCase();
    const host = (d) => h === d || h.endsWith("." + d);
    if (
      host("pinterest.com") ||
      host("pin.it") ||
      /^([\w-]+\.)?pinterest\.(co\.uk|fr|de|jp|ca|com\.au|es|it)$/.test(h)
    )
      return "pinterest";
    if (host("instagram.com")) return "instagram";
    if (host("xiaohongshu.com") || host("xhslink.com")) return "xhs";
    if (host("douyin.com")) return "douyin";
    if (host("pinduoduo.com") || host("yangkeduo.com")) return "pdd";
    if (host("vip.com")) return "vip";
    if (host("tmall.com")) return "tmall";
    if (host("taobao.com") || host("tb.cn")) return "taobao";
    return "web";
  } catch {
    return "web";
  }
}
export function workKey(raw) {
  try {
    const u = new URL(raw),
      p = platformOf(raw);
    let id;
    if (p === "xhs")
      id = u.pathname.match(
        /\/(?:explore|discovery\/item|search_result)\/([\w-]+)/,
      )?.[1];
    if (p === "instagram")
      id = u.pathname.match(
        /^\/(?:[\w.]+\/)?(?:p|reels?|tv)\/([\w-]+)(?:\/|$)/,
      )?.[1];
    if (p === "douyin")
      id =
        u.pathname.match(/\/(?:video|note)\/(\d+)/)?.[1] ||
        u.searchParams.get("modal_id");
    if (p === "pinterest")
      id = u.pathname.match(/\/pin\/(?:[^/]*--)?(\d+)/)?.[1];
    if (p === "tmall" || p === "taobao") id = u.searchParams.get("id");
    if (p === "pdd") id = u.searchParams.get("goods_id");
    if (p === "vip")
      id =
        u.pathname.match(/\/(?:detail|product)-(?:\d+-)?(\d+)\.html/)?.[1] ||
        u.searchParams.get("product_id") ||
        u.searchParams.get("goods_id");
    if (id) return p + ":" + id;
    u.hash = "";
    return p + ":" + u.hostname + u.pathname + (p === "web" ? u.search : "");
  } catch {
    return raw;
  }
}
export function isDetail(raw) {
  const p = platformOf(raw);
  try {
    const u = new URL(raw);
    if (p === "xhs")
      return /\/(explore|discovery\/item|search_result)\/[\w-]+/.test(
        u.pathname,
      );
    if (p === "instagram")
      return /^\/(?:[\w.]+\/)?(?:p|reels?|tv)\/[\w-]+(?:\/|$)/.test(u.pathname);
    if (p === "douyin")
      return (
        /\/(video|note)\/\d+/.test(u.pathname) ||
        !!u.searchParams.get("modal_id")
      );
    if (p === "pinterest") return /\/pin\/(?:[^/]*--)?\d+/.test(u.pathname);
    if (p === "taobao" || p === "tmall")
      return /item\.htm/.test(u.pathname) && !!u.searchParams.get("id");
    if (p === "pdd")
      return (
        /\/goods[\w-]*\.html/.test(u.pathname) &&
        /^\d+$/.test(u.searchParams.get("goods_id") || "")
      );
    if (p === "vip")
      return (
        /\/(?:detail|product)-(?:\d+-)?\d+\.html/.test(u.pathname) ||
        (/\/(?:product|detail)\.html/.test(u.pathname) &&
          /^\d+$/.test(
            u.searchParams.get("product_id") ||
              u.searchParams.get("goods_id") ||
              "",
          ))
      );
    return false;
  } catch {
    return false;
  }
}
export function searchUrl(p, q) {
  const k = encodeURIComponent(q.trim());
  if (!k) throw new Error("请填写检索关键词");
  return (
    {
      instagram: `https://www.instagram.com/explore/search/keyword/?q=${k}`,
      pinterest: `https://www.pinterest.com/search/pins/?q=${k}`,
      xhs: `https://www.xiaohongshu.com/search_result?keyword=${k}&source=web_search_result_notes`,
      douyin: `https://www.douyin.com/search/${k}?type=general`,
      taobao: `https://s.taobao.com/search?q=${k}`,
      tmall: `https://list.tmall.com/search_product.htm?q=${k}`,
      pdd: `https://mobile.yangkeduo.com/search_result.html?search_key=${k}`,
      vip: `https://category.vip.com/suggest.php?keyword=${k}`,
    }[p] || ""
  );
}
export function autoCategory(w) {
  const s = [w.title, ...(w.tags || [])].join(" ");
  if (["taobao", "tmall", "pdd", "vip"].includes(w.platform)) return "商品";
  if (/教程|教学|步骤|攻略|tutorial/i.test(s)) return "教程";
  if (/摄影|运镜|镜头|构图|陪拍|写真|photo|cinema/i.test(s)) return "摄影/镜头";
  if (/角色|精灵|萌宠|IP设计|character|mascot/i.test(s)) return "角色/IP";
  if (/穿搭|衣服|裙子|ootd|outfit/i.test(s)) return "穿搭";
  if (/美食|甜品|蛋糕|做饭|麻薯|food|cake/i.test(s)) return "美食";
  return "未分类";
}
export function cleanMedia(items = []) {
  if (!Array.isArray(items)) return [];
  const seen = new Set();
  return items
    .filter((m) => m && httpUrl(m.url))
    .map((m) => {
      const url = httpUrl(m.url),
        stream = /\.(m3u8|mpd|m4s)(?:\?|$)/i.test(url);
      return {
        url,
        kind: ["image", "video", "cover", "archive"].includes(m.kind)
          ? m.kind
          : "image",
        width: Number(m.width) || 0,
        height: Number(m.height) || 0,
        blockedReason: stream
          ? "分段流媒体，当前版本不合并"
          : mediaUrlProblem(url, m.kind || "image") ||
            String(m.blockedReason || ""),
      };
    })
    .filter((m) => {
      const k = m.kind + ":" + m.url;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    })
    .slice(0, 500);
}
export function normalizeWork(x) {
  const url = httpUrl(x?.url);
  if (!url) return null;
  const platform = platformOf(url),
    media = cleanMedia(x.media);
  const type = media.some((m) => m.kind === "video")
    ? media.some((m) => m.kind === "image")
      ? "mixed"
      : "video"
    : media.some((m) => m.kind === "image")
      ? "image"
      : x.type || "unknown";
  const w = {
    id: x.id || uid(),
    url,
    platform,
    title: String(x.title || "").slice(0, 500),
    user: String(x.user || x.accountName || "").slice(0, 150),
    category: String(x.category || ""),
    tags: Array.isArray(x.tags) ? x.tags.slice(0, 30) : [],
    media,
    type,
    source: String(x.source || "paste"),
    updatedAt: Date.now(),
    error: String(x.error || ""),
  };
  w.category = w.category || autoCategory(w);
  return w;
}
export function mergeWorks(old, incoming) {
  const out = old.map((w) => ({ ...w }));
  let added = 0,
    merged = 0;
  for (const x of incoming) {
    const w = normalizeWork(x);
    if (!w) continue;
    const prior = out.find((a) => workKey(a.url) === workKey(w.url));
    if (prior) {
      prior.platform = w.platform;
      prior.title = w.title || prior.title;
      prior.user = w.user || prior.user;
      prior.media =
        w.platform === "instagram" && w.error.includes("来自本帖已加载")
          ? cleanMedia([...w.media, ...prior.media])
          : w.media.length &&
              (!w.media.every((a) => a.kind === "cover") ||
                !prior.media.some((a) => a.kind !== "cover"))
            ? w.media
            : prior.media;
      prior.type = w.type !== "unknown" ? w.type : prior.type;
      prior.category =
        x.category && x.category !== "未分类" && x.category !== autoCategory(w)
          ? x.category
          : prior.category && prior.category !== "未分类"
            ? prior.category
            : w.category;
      prior.url = w.url;
      prior.updatedAt = Date.now();
      prior.error = w.error;
      merged++;
    } else {
      out.push(w);
      added++;
    }
  }
  return { works: out, added, merged };
}
export function parseInputs(raw) {
  const text = raw.trim();
  if (!text) return [];
  try {
    const d = JSON.parse(text),
      a = Array.isArray(d) ? d : d.works || d.rows || [d];
    if (Array.isArray(a)) {
      const r = a
        .map((x) =>
          normalizeWork({
            ...x,
            url: x.url || x["素材地址"],
            title: x.title || x["标题"],
            user: x.accountName || x.user || x["用户"],
          }),
        )
        .filter(Boolean);
      if (r.length) return r;
    }
  } catch {}
  const normalized = text.replace(/\\([:/.?=&_#%\-])/g, "$1");
  const xhs = parseXhs(normalized).map(normalizeWork),
    rest = [];
  let end = 0;
  for (const match of normalized.matchAll(
    /https?:\/\/[^\s<>"'，。！；）】]+/g,
  )) {
    const url = match[0].replace(/[)\],;.]+$/, "");
    const prefix = normalized.slice(end, match.index);
    end = match.index + match[0].length;
    if (platformOf(url) === "xhs" || !httpUrl(url)) continue;
    const title = prefix
      .split("\n")
      .map((s) => s.trim())
      .filter((s) => s && !/复制|打开|https?:/i.test(s))
      .slice(-1)
      .join(" ")
      .replace(/^[\d\s]+/, "")
      .replace(/[😆😀].*$/u, "")
      .trim();
    rest.push(normalizeWork({ url, title }));
    end = match.index + match[0].length;
  }
  return mergeWorks([], [...xhs, ...rest].filter(Boolean)).works;
}
export function safeSegment(raw, fallback = "未命名", limit = 65) {
  let s = String(raw || fallback)
    .normalize("NFC")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
    .replace(/\.{2,}/g, "_")
    .replace(/^[.\s]+|[.\s]+$/g, "");
  s = Array.from(s).slice(0, limit).join("");
  if (/^(CON|PRN|AUX|NUL|COM\d|LPT\d)(?:\.|$)/i.test(s)) s = "_" + s;
  return s || fallback;
}
export function fileName(work, asset, index) {
  let ext;
  try {
    ext = new URL(asset.url).pathname
      .match(/\.([a-zA-Z0-9]{2,5})$/)?.[1]
      ?.toLowerCase();
  } catch {}
  const allowed =
    asset.kind === "video"
      ? ["mp4", "webm", "mov"]
      : asset.kind === "archive"
        ? ["zip"]
        : [
            "jpg",
            "jpeg",
            "png",
            "gif",
            "webp",
            "avif",
            "bmp",
            "tif",
            "tiff",
            "heic",
            "heif",
          ];
  if (!allowed.includes(ext))
    ext =
      asset.kind === "video" ? "mp4" : asset.kind === "archive" ? "zip" : "jpg";
  const p = PLATFORMS.find((p) => p.id === work.platform)?.name || "网页";
  return [
    "抓到你啦",
    safeSegment(p),
    safeSegment(work.category, "未分类", 30),
    safeSegment(work.user, "未知账号", 35),
    safeSegment(work.title, "未命名", 55),
    String(index + 1).padStart(3, "0") +
      "_" +
      (asset.kind === "cover" ? "封面" : "素材") +
      "." +
      ext,
  ].join("/");
}
export function downloadCandidates(works, includeCovers = false) {
  return works.flatMap((w) =>
    w.media
      .map((a, i) => ({
        work: w,
        asset: a,
        index: i,
        key: w.id + ":" + a.kind + ":" + i,
      }))
      .filter(
        (x) =>
          !x.asset.blockedReason &&
          !mediaUrlProblem(x.asset.url, x.asset.kind) &&
          (includeCovers || x.asset.kind !== "cover"),
      ),
  );
}
export function tableText(works, header = false) {
  const clean = (s) =>
    String(s || "")
      .replace(/[\r\n\t]+/g, " ")
      .replace(/^[=+@-]/, "'$&");
  const rows = works.map((w) => [w.url, w.title, w.user]);
  if (header) rows.unshift(["素材地址", "标题", "用户"]);
  return rows.map((r) => r.map(clean).join("\t")).join("\n");
}
export function csvText(works) {
  const rows = [
    ["素材地址", "标题", "用户", "平台", "分类", "类型", "资源数"],
    ...works.map((w) => [
      w.url,
      w.title,
      w.user,
      PLATFORMS.find((p) => p.id === w.platform)?.name || "网页",
      w.category,
      w.type,
      w.media.length,
    ]),
  ];
  return (
    "\uFEFF" +
    rows
      .map((r) =>
        r
          .map(
            (x) =>
              '"' +
              String(x)
                .replace(/[\r\n\t]+/g, " ")
                .replace(/^[=+@-]/, "'$&")
                .replace(/"/g, '""') +
              '"',
          )
          .join(","),
      )
      .join("\r\n")
  );
}
export function buildDownloadPlan(
  works,
  { includeCovers = false, mediaKinds = null } = {},
) {
  const kinds = Array.isArray(mediaKinds)
    ? new Set(
        mediaKinds.filter((k) =>
          ["image", "video", "cover", "archive"].includes(k),
        ),
      )
    : null;
  const assets = downloadCandidates(works, includeCovers).filter(
    (x) =>
      !kinds ||
      kinds.has(x.asset.kind) ||
      (includeCovers && x.asset.kind === "cover"),
  );
  const ids = new Set(assets.map((x) => x.work.id)),
    ready = works.filter((w) => ids.has(w.id)),
    pending = works.filter(
      (w) => !ids.has(w.id) && w.media.every((a) => a.kind === "cover"),
    ),
    skipped = works.filter((w) => !ids.has(w.id) && !pending.includes(w));
  return { assets, ready, pending, skipped };
}
