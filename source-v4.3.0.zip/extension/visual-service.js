import {
  NATIVE_SEARCH,
  selectedPlatforms,
  nativeHost,
  validateReference,
  mergeVisualCandidates,
  candidateWork,
} from "./visual-core.js";
import { submitReferenceImage, collectVisualPage } from "./visual-page.js";
import { transact, latestState } from "./database.js";
import { uid, mergeWorks, workKey } from "./core.js";
let initialized = false;
const running = new Set();
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
async function init() {
  if (initialized) return;
  initialized = true;
  await transact((s) => {
    const v = s.visualSearch;
    if (!v) return;
    if (v.scopeVersion !== 3) {
      v.state = "cancelled";
      v.results = [];
      v.tasks = [];
      v.legacyMessage = "旧版站外搜图任务已停用，请重新选择平台开始。";
      return;
    }
    if (v.state === "running") {
      v.state = "attention";
      for (const t of v.tasks)
        if (["pending", "processing"].includes(t.state)) {
          t.state = "attention";
          t.error = "浏览器后台已恢复，请查看平台页面后继续";
        }
    }
  });
}
async function edit(id, fn) {
  return transact((s) => {
    if (s.visualSearch?.id === id) return fn(s.visualSearch, s);
  });
}
async function current(id) {
  const v = (await latestState()).visualSearch;
  if (v?.id !== id || v.state === "cancelled") throw new Error("检索已停止");
  return v;
}
function settle(v) {
  if (v.state === "cancelled") return;
  if (v.tasks.some((t) => ["pending", "processing"].includes(t.state))) {
    v.state = "running";
    return;
  }
  v.state = v.tasks.some((t) => ["attention", "unsupported"].includes(t.state))
    ? "attention"
    : "completed";
}
async function waitTab(tabId, id) {
  for (let i = 0; i < 60; i++) {
    await current(id);
    const t = await chrome.tabs.get(tabId);
    if (t.status === "complete") return t;
    await delay(400);
  }
  throw new Error("搜索页加载超时，可打开搜索页后继续收集");
}
async function readPage(tabId, platform) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId },
    func: collectVisualPage,
    args: [{ platform }],
  });
  if (!r?.result) throw new Error("没有读取到平台搜索页内容");
  return r.result;
}
async function waitResults(id, task) {
  let message = "";
  for (let n = 0; n < 14; n++) {
    await current(id);
    const tab = await chrome.tabs.get(task.tabId);
    if (!nativeHost(tab.url, task.platform))
      throw new Error("搜索标签页已离开所选平台，停止收集");
    const data = await readPage(task.tabId, task.platform);
    if (data.blocked) throw new Error(data.message);
    if (data.imageContext && (data.candidates?.length || data.empty))
      return data;
    message = data.message || "";
    await delay(500);
  }
  throw new Error(
    message ||
      "平台尚未返回图片检索结果，请在平台页确认搜图已完成，再继续收集。",
  );
}
async function processTask(id, task) {
  let tab;
  if (task.tabId) {
    try {
      tab = await chrome.tabs.get(task.tabId);
    } catch {
      throw new Error("平台标签页已关闭，请重新开始检索");
    }
  } else {
    tab = await chrome.tabs.create({
      url: NATIVE_SEARCH[task.platform].home,
      active: task.primary,
    });
    task.tabId = tab.id;
    await edit(id, (x) => {
      const t = x.tasks.find((t) => t.id === task.id);
      if (t) t.tabId = tab.id;
    });
  }
  await waitTab(tab.id, id);
  await current(id);
  tab = await chrome.tabs.get(tab.id);
  if (!nativeHost(tab.url, task.platform))
    throw new Error("标签页已离开所选平台，未传送参考图");
  if (NATIVE_SEARCH[task.platform].status === "unverified") {
    await edit(id, (x) => {
      const t = x.tasks.find((t) => t.id === task.id);
      if (t) {
        t.state = "unsupported";
        t.error = NATIVE_SEARCH[t.platform].hint + "。没有发送参考图。";
      }
      settle(x);
    });
    return;
  }
  if (!task.submitted) {
    const page = await readPage(tab.id, task.platform);
    if (page.blocked) throw new Error(page.message);
    if (!(task.manual && page.imageContext)) {
      const v = await current(id),
        saved = (await chrome.storage.local.get("visualReferenceV4"))
          .visualReferenceV4,
        frame =
          saved?.id === v.referenceId
            ? saved.frames.find((f) => f.id === task.frameId)
            : null;
      if (!frame) throw new Error("本机参考画面已移除，请重新上传");
      await current(id);
      const [r] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: submitReferenceImage,
        args: [{ platform: task.platform, dataUrl: frame.dataUrl }],
      });
      if (!r?.result?.submitted)
        throw new Error(
          r?.result?.message || "平台没有接收参考图，请查看平台页面",
        );
      await current(id);
      await edit(id, (x) => {
        const t = x.tasks.find((t) => t.id === task.id);
        if (t) t.submitted = true;
      });
    }
  }
  const data = await waitResults(id, task);
  await current(id);
  await edit(id, (x) => {
    if (x.state === "cancelled") return;
    const t = x.tasks.find((t) => t.id === task.id);
    if (!t || !x.platforms.includes(task.platform)) return;
    x.results = mergeVisualCandidates(
      x.results,
      data.candidates || [],
      task.frameId,
      [task.platform],
    );
    t.state = "completed";
    t.error = "";
    t.count = mergeVisualCandidates([], data.candidates || [], task.frameId, [
      task.platform,
    ]).length;
    settle(x);
  });
}
async function pump(id) {
  if (running.has(id)) return;
  running.add(id);
  try {
    async function worker() {
      while (true) {
        let task;
        await edit(id, (v) => {
          if (v.state === "cancelled") return;
          const next = v.tasks.find((t) => t.state === "pending");
          if (next) {
            next.state = "processing";
            task = { ...next };
          }
        });
        if (!task) return;
        try {
          await processTask(id, task);
        } catch (e) {
          await edit(id, (v) => {
            if (v.state === "cancelled") return;
            const t = v.tasks.find((x) => x.id === task.id);
            if (t) {
              t.state = "attention";
              t.error = e.message || "图片检索失败";
            }
            settle(v);
          });
        }
      }
    }
    await worker();
    await edit(id, settle);
  } finally {
    running.delete(id);
  }
}

export async function handleVisualMessage(m) {
  await init();
  switch (m.type) {
    case "VISUAL_START": {
      if (m.engine && m.engine !== "native")
        throw new Error("仅支持所选平台原生检索，站外搜图服务已禁用");
      if ((await latestState()).visualSearch?.state === "running")
        throw new Error("已有检索正在运行，请先停止");
      const reference = validateReference(m.reference, m.frameIds),
        platforms = selectedPlatforms(m.platforms, m.mode || "multi");
      for (const p of platforms)
        if (
          !(await chrome.permissions.contains({
            origins: [new URL(NATIVE_SEARCH[p].home).origin + "/*"],
          }))
        )
          throw new Error("请先允许访问所选平台");
      const id = uid(),
        tasks = [];
      for (const platform of platforms)
        for (const frame of NATIVE_SEARCH[platform].status === "unverified"
          ? reference.frames.slice(0, 1)
          : reference.frames)
          tasks.push({
            id: uid(),
            kind: "native",
            platform,
            frameId: frame.id,
            time: frame.time,
            primary: tasks.length === 0,
            state: "pending",
            count: 0,
            error: "",
            submitted: false,
          });
      await chrome.storage.local.set({ visualReferenceV4: reference });
      const result = await transact((s) => {
        s.visualSearch = {
          id,
          referenceId: reference.id,
          name: reference.name,
          type: reference.type,
          platforms,
          scopeVersion: 3,
          nativeOnly: true,
          mode: m.mode === "single" ? "single" : "multi",
          state: "running",
          createdAt: Date.now(),
          results: [],
          tasks,
        };
        return { visualId: id };
      });
      void pump(id);
      return result;
    }
    case "VISUAL_CONTINUE": {
      const v = (await latestState()).visualSearch;
      if (!v) throw new Error("还没有参考检索任务");
      if (running.has(v.id)) throw new Error("检索仍在运行，请稍候");
      if (v.scopeVersion !== 3)
        throw new Error("旧版站外搜图已停用，请重新选择平台开始");
      if (v.state === "cancelled")
        throw new Error("任务已停止，请重新开始检索");
      await edit(v.id, (x) => {
        for (const t of x.tasks)
          if (t.state === "attention") {
            t.state = "pending";
            t.error = "";
            t.manual = true;
          }
        settle(x);
      });
      void pump(v.id);
      return { state: await latestState() };
    }
    case "VISUAL_CANCEL":
      return transact((s) => {
        const v = s.visualSearch;
        if (v) {
          v.state = "cancelled";
          for (const t of v.tasks)
            if (["pending", "processing"].includes(t.state))
              t.state = "cancelled";
        }
      });
    case "VISUAL_CLEAR": {
      await chrome.storage.local.remove("visualReferenceV4");
      return transact((s) => {
        s.visualSearch = null;
      });
    }
    case "VISUAL_IMPORT":
      return transact((s) => {
        const v = s.visualSearch;
        if (!v || v.scopeVersion !== 3 || m.visualId !== v.id)
          throw new Error("检索结果已变化，请重新选择");
        const candidates = v.results.filter((x) => m.ids?.includes(x.id));
        if (!candidates.length) throw new Error("请先勾选需要收录的候选");
        const category =
          String(m.category || "灵感参考")
            .trim()
            .slice(0, 32) || "灵感参考";
        const merged = mergeWorks(
          s.works,
          candidates.map((x) => candidateWork(x, category)),
        );
        s.works = merged.works;
        if (!s.categories.includes(category)) s.categories.push(category);
        return {
          added: merged.added,
          merged: merged.merged,
          workIds: candidates.map(
            (c) => s.works.find((w) => workKey(w.url) === workKey(c.url)).id,
          ),
        };
      });
    default:
      throw new Error("相似检索操作无效");
  }
}
export async function restoreVisualJobs() {
  await init();
}
