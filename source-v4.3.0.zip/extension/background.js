import { handleVisualMessage, restoreVisualJobs } from "./visual-service.js";
import {
  PLATFORMS,
  normalizeWork,
  mergeWorks,
  parseInputs,
  workKey,
  httpUrl,
  platformOf,
  searchUrl,
  downloadCandidates,
  isDetail,
  buildDownloadPlan,
} from "./core.js";
import { transact, latestState, newJob } from "./database.js";
import { collectPage, collectPageImages } from "./collector.js";
import { changeCategory, applyCategoryRules } from "./categories.js";
import {
  autoCapture,
  enableAutoSite,
  syncAutoSites,
  injectOpenPages,
} from "./auto-capture.js";
import {
  updateInfo,
  checkUpdate,
  applyUpdate,
  registerUpdateEvents,
} from "./updates.js";
import {
  enqueueWorks,
  reconcile,
  controlDownloads,
  registerDownloadEvents,
} from "./downloads.js";
let initialized,
  parsing = false;
const searches = new Set();
async function init() {
  if (!initialized)
    initialized = transact((s) => {
      for (const j of s.jobs)
        if (j.kind === "parse" && j.state === "processing") {
          j.state = "pending";
          j.error = "后台恢复后继续解析";
        }
      for (const d of s.downloads)
        if (d.state === "starting" && d.downloadId === null) {
          d.state = "failed";
          d.error = "下载启动被中断，请点击重试。";
        }
    }).then(async () => {
      await reconcile();
      await restoreVisualJobs();
      await syncAutoSites().catch(() => {});
      const s = await latestState();
      for (const j of s.jobs.filter(
        (j) =>
          j.kind === "search" && ["loading", "collecting"].includes(j.state),
      ))
        void processSearch(j.id);
      void processParses();
    });
  return initialized;
}
async function tabReady(id) {
  const current = await chrome.tabs.get(id);
  if (current.status === "complete") return;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => finish(new Error("页面加载超时，可打开该页面后手动采集。")),
      20000,
    );
    const listener = (tabId, change) => {
      if (tabId === id && change.status === "complete") finish();
    };
    function finish(error) {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      error ? reject(error) : resolve();
    }
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs
      .get(id)
      .then((t) => {
        if (t.status === "complete") finish();
      })
      .catch(finish);
  });
}
async function capture(id, options = {}) {
  const tab = await chrome.tabs.get(id);
  if (!httpUrl(tab.url)) throw new Error("请打开 HTTP／HTTPS 作品页面。");
  const allowed = await chrome.permissions.contains({
    origins: [new URL(tab.url).origin + "/*"],
  });
  if (!allowed && platformOf(tab.url) === "web")
    throw new Error("请在插件中点击「授权当前网站」，再采集该页面。");
  const [r] = await chrome.scripting.executeScript({
    target: { tabId: Number(id) },
    world: "MAIN",
    func: collectPage,
    args: [options],
  });
  if (!r?.result) throw new Error("页面暂时不能采集，请刷新后重试。");
  return r.result;
}
async function saveCaptured(data, category) {
  return transact((s) => {
    const incoming = (data.works || []).map((w) =>
      category ? { ...w, category } : w,
    );
    const result = mergeWorks(s.works, incoming);
    s.works = result.works;
    applyCategoryRules(s);
    return {
      added: result.added,
      merged: result.merged,
      message: data.message || "",
      blocked: !!data.blocked,
    };
  });
}
async function processSearch(jobId) {
  if (searches.has(jobId)) return;
  searches.add(jobId);
  try {
    const job = (await latestState()).jobs.find((j) => j.id === jobId);
    if (!job || !["loading", "collecting"].includes(job.state)) return;
    await tabReady(job.tabId);
    await transact((s) => {
      const j = s.jobs.find((j) => j.id === jobId);
      if (j) j.state = "collecting";
    });
    const result = await capture(job.tabId, {
      mode: "list",
      rounds: job.rounds,
      limit: job.limit,
    });
    await saveCaptured(result, job.category);
    await transact((s) => {
      const j = s.jobs.find((j) => j.id === jobId);
      if (j) {
        j.state = result.works?.length ? "completed" : "attention";
        j.count = result.works?.length || 0;
        j.error = result.message || "";
      }
    });
  } catch (e) {
    await transact((s) => {
      const j = s.jobs.find((j) => j.id === jobId);
      if (j) {
        j.state = "attention";
        j.error = e.message || "检索采集失败";
      }
    });
  } finally {
    searches.delete(jobId);
  }
}
async function processParses() {
  if (parsing) return;
  parsing = true;
  async function worker() {
    while (true) {
      let job;
      await transact((s) => {
        const j = s.jobs.find(
          (j) => j.kind === "parse" && j.state === "pending",
        );
        if (j) {
          j.state = "processing";
          job = { ...j };
        }
      });
      if (!job) break;
      let tabId;
      try {
        const state = await latestState(),
          work = state.works.find((w) => w.id === job.workId);
        if (!work) throw new Error("作品已移除");
        if (
          platformOf(work.url) === "web" &&
          !(await chrome.permissions.contains({
            origins: [new URL(work.url).origin + "/*"],
          }))
        )
          throw new Error("请先授权这个网站，再批量解析。");
        const tab = await chrome.tabs.create({ url: work.url, active: false });
        tabId = tab.id;
        await transact((s) => {
          const j = s.jobs.find((j) => j.id === job.id);
          if (j) j.tabId = tabId;
        });
        await tabReady(tabId);
        const result = await capture(tabId, { mode: "detail" });
        if (!result.works?.length)
          throw new Error(result.message || "页面没有可读取的作品");
        await transact((s) => {
          const same = s.works.find((w) => w.id === work.id);
          if (same && result.works[0]?.url) {
            same.url = result.works[0].url;
            same.platform = platformOf(same.url);
          }
        });
        await saveCaptured(result, work.category);
        const current =
          (await latestState()).works.find(
            (w) => workKey(w.url) === workKey(result.works[0].url),
          ) || work;
        const latestJob =
          (await latestState()).jobs.find((j) => j.id === job.id) || job;
        const assets = chosenAssets(
          [current],
          latestJob.includeCovers,
          latestJob.mediaKinds,
        );
        await transact((s) => {
          const j = s.jobs.find((j) => j.id === job.id);
          if (j) {
            j.state = assets.length ? "completed" : "attention";
            j.count = assets.length;
            j.error = assets.length
              ? ""
              : current.error ||
                "未识别到可下载直链，可打开页面播放视频或加载大图后重新采集。";
          }
        });
        if (latestJob.downloadAfter && assets.length)
          await enqueueWorks(
            [current.id],
            latestJob.includeCovers,
            assets.map((x) => x.key),
          );
      } catch (e) {
        await transact((s) => {
          const j = s.jobs.find((j) => j.id === job.id);
          if (j) {
            j.state = "attention";
            j.error = e.message || "解析失败";
          }
        });
      } finally {
        if (tabId)
          try {
            await chrome.tabs.remove(tabId);
          } catch {}
      }
    }
  }
  try {
    await Promise.all([worker(), worker()]);
  } finally {
    parsing = false;
    if (
      (await latestState()).jobs.some(
        (j) => j.kind === "parse" && j.state === "pending",
      )
    )
      void processParses();
  }
}
async function queueParses(
  ids,
  downloadAfter = false,
  includeCovers = false,
  mediaKinds = null,
) {
  const result = await transact((s) => {
    let queued = 0;
    for (const w of s.works.filter((w) => ids.includes(w.id))) {
      const old = s.jobs.find(
        (j) =>
          j.kind === "parse" &&
          j.workId === w.id &&
          ["pending", "processing"].includes(j.state),
      );
      if (old) {
        if (downloadAfter) {
          old.mediaKinds = old.downloadAfter
            ? old.mediaKinds && mediaKinds
              ? [...new Set([...old.mediaKinds, ...mediaKinds])]
              : null
            : mediaKinds;
        }
        old.downloadAfter = old.downloadAfter || downloadAfter;
        old.includeCovers = old.includeCovers || includeCovers;
        continue;
      }
      s.jobs.push(
        newJob({
          kind: "parse",
          workId: w.id,
          url: w.url,
          title: w.title,
          platform: w.platform,
          downloadAfter,
          includeCovers,
          mediaKinds,
        }),
      );
      queued++;
    }
    return { queued };
  });
  void processParses();
  return result;
}
export async function handleMessage(m) {
  await init();
  switch (m?.type) {
    case "VISUAL_START":
    case "VISUAL_CONTINUE":
    case "VISUAL_CANCEL":
    case "VISUAL_CLEAR":
    case "VISUAL_IMPORT":
      return handleVisualMessage(m);
    case "GET":
      await reconcile();
      return { state: await latestState() };
    case "TABS": {
      const tabs = await chrome.tabs.query({ currentWindow: true });
      return {
        tabs: tabs
          .filter((t) => httpUrl(t.url))
          .map((t) => ({
            id: t.id,
            url: t.url,
            title: t.title || t.url,
            platform: platformOf(t.url),
            active: !!t.active,
          })),
      };
    }
    case "ADD": {
      const works = Array.isArray(m.works)
        ? m.works
        : parseInputs(String(m.text || ""));
      if (works.length > 500) throw new Error("单次最多导入 500 条");
      return transact((s) => {
        const r = mergeWorks(
          s.works,
          works.map((w) => (m.category ? { ...w, category: m.category } : w)),
        );
        s.works = r.works;
        applyCategoryRules(s);
        return { added: r.added, merged: r.merged };
      });
    }
    case "UPDATE":
      return transact((s) => {
        const w = s.works.find((w) => w.id === m.id);
        if (!w) return;
        if (
          !["title", "user", "category", "url"].includes(m.field) ||
          typeof m.value !== "string"
        )
          throw new Error("修改无效");
        if (m.field === "url" && !httpUrl(m.value)) throw new Error("链接无效");
        w[m.field] = m.value.trim();
        if (
          m.field === "category" &&
          m.value &&
          !s.categories.includes(m.value)
        )
          s.categories.push(m.value);
      });
    case "REMOVE":
      return transact((s) => {
        s.works = s.works.filter((w) => !m.ids.includes(w.id));
      });
    case "CAPTURE": {
      const data = await capture(Number(m.tabId), {
        mode: m.mode || "auto",
        rounds: m.rounds || 0,
        limit: m.limit || 80,
      });
      return saveCaptured(data, m.category);
    }
    case "CATEGORY":
      return transact((s) => changeCategory(s, m));
    case "AUTO_SITE":
      return enableAutoSite(Number(m.tabId));
    case "UPDATE_INFO":
      return { update: await updateInfo() };
    case "UPDATE_CHECK":
      return { update: await checkUpdate() };
    case "UPDATE_APPLY": {
      const r = await applyUpdate();
      setTimeout(() => chrome.runtime.reload(), 300);
      return r;
    }
    case "GRAB_IMAGES":
      return grabImages(Number(m.tabId), m);
    case "DOWNLOAD_IMAGES": {
      if (!m.workId || !Array.isArray(m.urls) || !m.urls.length)
        throw new Error("请先勾选需要下载的图片");
      if (m.urls.some((u) => typeof u !== "string") || m.urls.length > 500)
        throw new Error("图片选择无效");
      const selected = [...new Set(m.urls)].map((url) => ({
        workId: m.workId,
        kind: "image",
        url,
      }));
      return enqueueWorks([m.workId], false, null, selected);
    }
    case "DOWNLOAD_ASSETS": {
      const keys = (m.keys || []).filter((k) => typeof k === "string"),
        state = await latestState();
      const works = state.works.filter((w) =>
        w.media.some((a, i) => keys.includes(w.id + ":" + a.kind + ":" + i)),
      );
      return enqueueWorks(
        works.map((w) => w.id),
        true,
        keys,
      );
    }
    case "PARSE":
      if ((m.ids || []).length > 100)
        throw new Error("每次最多解析 100 条作品，请分批选择");
      return queueParses(
        m.ids || [],
        false,
        !!m.includeCovers,
        m.mediaKinds || null,
      );
    case "DOWNLOAD": {
      const state = await latestState(),
        works = state.works.filter((w) => m.ids?.includes(w.id));
      const include = m.includeCovers ?? state.settings.includeCovers;
      const plan = buildDownloadPlan(works, {
        includeCovers: include,
        mediaKinds: m.mediaKinds,
      });
      if (Array.isArray(m.mediaKinds) && !m.mediaKinds.length && !include)
        throw new Error("请至少选择一种下载类型");
      const result = await enqueueWorks(
        plan.ready.map((w) => w.id),
        include,
        plan.assets.map((x) => x.key),
      );
      if (plan.pending.length)
        await queueParses(
          plan.pending.map((w) => w.id),
          true,
          include,
          m.mediaKinds || null,
        );
      return {
        ...result,
        parsing: plan.pending.length,
        unsupported: plan.skipped.length,
      };
    }
    case "DOWNLOAD_ASSET": {
      const s = await latestState(),
        w = s.works.find((w) => w.id === m.workId),
        a = w?.media?.[m.index];
      if (!a || a.blockedReason)
        throw new Error(a?.blockedReason || "资源不存在");
      return enqueueSingle(w, a, m.index);
    }
    case "DOWNLOAD_CONTROL":
      return controlDownloads(m.action, m.ids || []);
    case "SHOW_FILE": {
      const s = await latestState(),
        j = s.downloads.find((j) => j.id === m.id);
      if (j && j.downloadId !== null) chrome.downloads.show(j.downloadId);
      return {};
    }
    case "SETTINGS":
      return transact((s) => {
        if (m.concurrency)
          s.settings.concurrency = Math.max(
            1,
            Math.min(5, Number(m.concurrency) || 2),
          );
        if (typeof m.includeCovers === "boolean")
          s.settings.includeCovers = m.includeCovers;
        for (const key of ["autoCapture", "autoNotice"])
          if (typeof m[key] === "boolean") s.settings[key] = m[key];
      });
    case "SEARCH": {
      const keywords = String(m.keywords || "")
          .split(/\n/)
          .map((x) => x.trim())
          .filter(Boolean),
        platforms = (m.platforms || []).filter((p) =>
          PLATFORMS.some((x) => x.id === p && p !== "web"),
        );
      if (!keywords.length || !platforms.length)
        throw new Error("请选择平台并填写关键词");
      if (keywords.length * platforms.length > 20)
        throw new Error("每次最多打开 20 个检索任务，请分批处理");
      const created = [];
      for (const keyword of keywords)
        for (const platform of platforms) {
          const url = searchUrl(platform, keyword);
          const tab = await chrome.tabs.create({ url, active: false });
          const job = newJob({
            kind: "search",
            keyword,
            platform,
            url,
            tabId: tab.id,
            state: "loading",
            limit: Math.min(150, Number(m.limit) || 50),
            rounds: Math.max(0, Math.min(5, Number(m.rounds ?? 2) || 0)),
            category: m.category || "",
          });
          await transact((s) => {
            s.jobs.push(job);
          });
          created.push(job);
          void processSearch(job.id);
        }
      return { created: created.length, state: await latestState() };
    }
    case "JOB_RETRY": {
      const s = await latestState(),
        j = s.jobs.find((j) => j.id === m.id);
      if (!j) return {};
      if (j.kind === "search") {
        let tabId = j.tabId;
        try {
          await chrome.tabs.get(tabId);
        } catch {
          tabId = (await chrome.tabs.create({ url: j.url, active: false })).id;
        }
        await transact((s) => {
          const x = s.jobs.find((x) => x.id === m.id);
          x.tabId = tabId;
          x.state = "loading";
          x.error = "";
        });
        void processSearch(j.id);
        return { state: await latestState() };
      }
      return queueParses(
        [j.workId],
        j.downloadAfter,
        j.includeCovers,
        j.mediaKinds,
      );
    }
    case "JOB_OPEN": {
      const s = await latestState(),
        j = s.jobs.find((j) => j.id === m.id);
      if (j)
        try {
          await chrome.tabs.update(j.tabId, { active: true });
        } catch {
          const tab = await chrome.tabs.create({ url: j.url });
          await transact((s) => {
            const x = s.jobs.find((x) => x.id === j.id);
            if (x) x.tabId = tab.id;
          });
        }
      return {};
    }
    case "CLEAR_JOBS":
      return transact((s) => {
        s.jobs = s.jobs.filter((j) =>
          ["pending", "processing", "loading", "collecting"].includes(j.state),
        );
      });
    default:
      throw new Error("未知操作");
  }
}
function chosenAssets(works, includeCovers, kinds) {
  const allowed = Array.isArray(kinds)
    ? kinds.filter((k) => ["image", "video", "archive", "cover"].includes(k))
    : null;
  return downloadCandidates(works, includeCovers).filter(
    (x) =>
      !allowed ||
      allowed.includes(x.asset.kind) ||
      (includeCovers && x.asset.kind === "cover"),
  );
}
async function grabImages(tabId, m) {
  const tab = await chrome.tabs.get(tabId);
  if (!httpUrl(tab.url)) throw new Error("请选择普通网页");
  if (
    !(await chrome.permissions.contains({
      origins: [new URL(tab.url).origin + "/*"],
    }))
  )
    throw new Error("请先在页面采集面板授权这个网站");
  let data;
  if (m.scope === "page") {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: collectPageImages,
      args: [{ wholePage: true, minWidth: m.minWidth || 200, limit: 300 }],
    });
    data = r?.result;
  } else {
    if (platformOf(tab.url) !== "web" && !isDetail(tab.url))
      throw new Error(
        "请先打开具体作品，再抓取作品图集；列表页可使用“整页已加载图片”",
      );
    data = await capture(tabId, { mode: "detail" });
  }
  if (!data?.works?.length) throw new Error(data?.message || "没有识别到图片");
  const ids = [];
  const result = await transact((s) => {
    const incoming = data.works
      .map((w) => {
        const old = s.works.find((x) => workKey(x.url) === workKey(w.url));
        return {
          ...w,
          user: w.user || old?.user || "",
          media: [
            ...(w.media || []).filter((a) => a.kind === "image"),
            ...(old?.media || []).filter((a) => a.kind !== "image"),
          ],
        };
      })
      .filter((w) => w.media.some((a) => a.kind === "image"));
    if (!incoming.length)
      throw new Error("当前作品没有可读取的图集，视频封面不计入图集");
    const r = mergeWorks(s.works, incoming);
    s.works = r.works;
    applyCategoryRules(s);
    for (const w of incoming)
      ids.push(s.works.find((x) => workKey(x.url) === workKey(w.url)).id);
    s.imageLast = { workIds: ids, at: Date.now() };
    return {
      grabbedWorkIds: ids,
      grabbed: incoming.reduce(
        (n, w) => n + w.media.filter((a) => a.kind === "image").length,
        0,
      ),
      message: data.message,
    };
  });
  return result;
}
async function enqueueSingle(work, asset, index) {
  return enqueueWorks([work.id], true, [
    work.id + ":" + asset.kind + ":" + index,
  ]);
}

export async function handleAutoMessage(m, sender) {
  if (sender.frameId !== 0 || !sender.tab?.id)
    throw new Error("仅支持当前页面顶层采集");
  await init();
  if (m.type === "AUTO_CAPTURE") return autoCapture(sender.tab.id, capture);
  if (m.type === "AUTO_OPEN") {
    await chrome.tabs.create({
      url: chrome.runtime.getURL("app.html?view=full"),
    });
    return {};
  }
  throw new Error("页面消息不允许此操作");
}
export function dispatchMessage(m, sender) {
  if (
    !m ||
    typeof m !== "object" ||
    Array.isArray(m) ||
    sender.id !== chrome.runtime.id
  )
    return Promise.reject(new Error("消息来源无效"));
  const ownPage =
    typeof sender.url === "string" &&
    ["app.html", "help.html", "privacy.html"].some((page) => {
      try {
        const actual = new URL(sender.url);
        const expected = new URL(chrome.runtime.getURL(page));
        return (
          actual.protocol === expected.protocol &&
          actual.host === expected.host &&
          actual.pathname === expected.pathname
        );
      } catch {
        return false;
      }
    });
  if (ownPage) return handleMessage(m);
  if (sender.tab) return handleAutoMessage(m, sender);
  return Promise.reject(new Error("仅允许扩展工作台执行此操作"));
}
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (sender.id !== chrome.runtime.id) return false;
  const request = dispatchMessage(m, sender);
  request
    .then((r) => reply({ ok: true, ...r }))
    .catch((e) => reply({ ok: false, message: e.message || "操作失败" }));
  return true;
});
registerDownloadEvents();
chrome.runtime.onStartup.addListener(() => {
  void init();
});
chrome.runtime.onInstalled.addListener(() => {
  void init()
    .then(injectOpenPages)
    .catch(() => {});
});
chrome.permissions.onRemoved?.addListener(() => {
  void syncAutoSites().catch(() => {});
});
registerUpdateEvents();

void init().catch(() => {});
