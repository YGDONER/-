function decode(s) { return s.replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n))).replace(/&#x([\da-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16))).replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim(); }
function meta(html, name) { for (const tag of html.match(/<meta\b[^>]*>/gi) || []) {
    const attrs = {};
    for (const m of tag.matchAll(/([\w:-]+)\s*=\s*["']([^"']*)["']/g))
        attrs[m[1].toLowerCase()] = decode(m[2]);
    if ((attrs.property || attrs.name)?.toLowerCase() === name)
        return attrs.content || '';
} return ''; }
function stateJson(html) { const at = html.indexOf('window.__INITIAL_STATE__'); if (at < 0)
    return null; const start = html.indexOf('{', at); if (start < 0)
    return null; let depth = 0, quoted = false, escape = false, end = -1; for (let i = start; i < html.length; i++) {
    const c = html[i];
    if (quoted) {
        if (escape)
            escape = false;
        else if (c === '\\')
            escape = true;
        else if (c === '"')
            quoted = false;
    }
    else if (c === '"')
        quoted = true;
    else if (c === '{')
        depth++;
    else if (c === '}' && --depth === 0) {
        end = i + 1;
        break;
    }
} if (end < 0)
    return null; const raw = html.slice(start, end); let json = '', q = false, e = false; for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (q) {
        json += c;
        if (e)
            e = false;
        else if (c === '\\')
            e = true;
        else if (c === '"')
            q = false;
    }
    else if (c === '"') {
        q = true;
        json += c;
    }
    else if (raw.slice(i, i + 9) === 'undefined') {
        json += 'null';
        i += 8;
    }
    else
        json += c;
} try {
    return JSON.parse(json);
}
catch {
    return null;
} }
export function extractPage(html, noteId) { let title = '', user = ''; const state = stateJson(html), map = state?.note?.noteDetailMap; if (map) {
    const entry = map[noteId] || Object.values(map).find((v) => v?.note?.noteId === noteId || v?.noteId === noteId), n = entry?.note || entry;
    if (n) {
        title = typeof n.title === 'string' ? n.title : '';
        user = n.user?.nickname || n.user?.nickName || '';
    }
} if (!title)
    title = meta(html, 'og:title') || decode(html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1] || ''); if (!user) {
    const author = meta(html, 'author') || meta(html, 'article:author');
    if (author && !/^https?:\/\//i.test(author) && !/^\d+$/.test(author))
        user = author;
} title = title.replace(/\s*[-|｜]\s*小红书.*$/, '').trim(); if (/^(小红书|登录|验证码|安全验证|页面不存在|404)|访问频次|访问受限|网站防火墙|安全校验|请求异常/.test(title))
    title = ''; return { title, user: typeof user === 'string' ? user.trim() : '' }; }
