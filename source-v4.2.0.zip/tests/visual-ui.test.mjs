import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {setupVisualUI} from '../extension/visual-ui.js';
class Element{
 constructor(tag='div',className='',text=''){this.tagName=tag;this.className=className;this.textContent=text;this.children=[];this.handlers={};this.dataset={};this.value='';this.checked=false;this.hidden=false;this.classList={toggle(){},add(){},remove(){}};}
 append(...x){this.children.push(...x);}replaceChildren(...x){this.children=x;}setAttribute(key,value){this[key]=value;}addEventListener(name,fn){this.handlers[name]=fn;}querySelectorAll(){return [];}
 async fire(name){return this.handlers[name]?.({target:this});}
}
const html=fs.readFileSync(new URL('../extension/app.html',import.meta.url),'utf8');
function fixture(session=null){
 const elements=new Map([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element()])),mode=['single','multi'].map(value=>Object.assign(new Element('input'),{value,checked:value==='single'})),requests=[];
 const document={getElementById:id=>elements.get(id)||null,querySelectorAll:selector=>selector==='input[name="visual-platform-mode"]'?mode:[],querySelector:()=>null,addEventListener(){}};
 globalThis.document=document;globalThis.chrome={storage:{local:{get:async()=>({visualReferenceV4:{id:'r',name:'参考图.png',type:'image',frames:[{id:'f',dataUrl:'data:image/png;base64,AAAA'}]}})}},tabs:{create:async value=>requests.push(value),update:async()=>{}}};
 const node=(...args)=>new Element(...args),button=(title,fn)=>{const b=node('button','',title);b.addEventListener('click',fn);return b;};
 const ui=setupVisualUI({getState:()=>({visualSearch:session}),getView:()=> 'visual',send:async(type,payload)=>requests.push({type,...payload}),run:fn=>fn(),toast(){},node,button,options(el,items,first){if(first)el.value=first[0];else if(!el.value)el.value=items[0];},categories:()=>['未分类','灵感参考'],openDetail(){}});
 return {elements,requests,ui};
}
await test('reference search offers Instagram and discloses its unverified image-search capability',async()=>{
 const f=fixture();await new Promise(r=>setImmediate(r));const platform=f.elements.get('visual-platforms').children.find(label=>label.children[0].value==='instagram');assert.ok(platform);await platform.children[0].fire('change');assert.match(f.elements.get('visual-capability').textContent,/尚未确认 ins 网页端/);assert.match(f.elements.get('visual-start').textContent,/Instagram/);assert.equal(f.elements.has('visual-engine'),false);f.ui.render();assert.equal(f.elements.get('visual-start').disabled,false);
 await f.elements.get('visual-start').fire('click');assert.deepEqual(f.requests[0].platforms,['instagram']);assert.equal(f.requests[0].engine,undefined);
});
await test('unsupported native search status renders without assuming an external search engine exists',async()=>{
 const f=fixture({id:'v',scopeVersion:3,platforms:['instagram'],name:'参考图',type:'image',state:'attention',results:[],tasks:[{id:'t',platform:'instagram',state:'unsupported',error:'尚未确认 ins 原生入口；没有发送参考图。'}]});await new Promise(r=>setImmediate(r));f.ui.render();assert.match(f.elements.get('visual-session-status').textContent,/需要查看平台入口/);assert.equal(f.elements.get('visual-continue').hidden,true);assert.match(f.elements.get('visual-provider-info').textContent,/平台原生网页/);assert.equal(f.elements.get('visual-results').children.length,0);
});
