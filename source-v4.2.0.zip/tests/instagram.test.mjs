import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PLATFORMS,platformOf,isDetail,workKey,searchUrl,normalizeWork,mergeWorks,fileName,downloadCandidates} from '../extension/core.js';

test('Instagram posts, Reels and account-prefixed share URLs retain one shortcode identity',()=>{
 const urls=['https://www.instagram.com/p/AbC_123-x/?igsh=SYNTHETIC','https://instagram.com/reel/AbC_123-x/','https://www.instagram.com/reels/AbC_123-x/','https://www.instagram.com/tv/AbC_123-x/','https://www.instagram.com/creator.name/p/AbC_123-x/'];
 for(const url of urls){assert.equal(platformOf(url),'instagram');assert.ok(isDetail(url));assert.equal(workKey(url),'instagram:AbC_123-x');}
 assert.notEqual(workKey(urls[0]),workKey('https://www.instagram.com/p/abc_123-x/'));
 for(const url of ['https://www.instagram.com/creator/','https://www.instagram.com/explore/','https://www.instagram.com/reels/','https://www.instagram.com/accounts/login/'])assert.equal(isDetail(url),false);
 assert.equal(platformOf('https://www.instagram.com.evil.test/p/AbC/'),'web');
 assert.equal(PLATFORMS.filter(p=>p.id==='instagram').length,1);
});

test('ins keyword search opens only Instagram and encodes user text',()=>{
 const u=new URL(searchUrl('instagram','猫 #治愈 & food'));assert.equal(u.origin,'https://www.instagram.com');assert.equal(u.searchParams.get('q'),'猫 #治愈 & food');
});

test('Instagram partial carousel captures accumulate without discarding previously chosen images',()=>{
 let r=mergeWorks([],[{url:'https://www.instagram.com/p/AbC/',title:'图集',user:'发布者',category:'自建分类',media:[{url:'https://i.test/1.jpg',kind:'image'}]}]);
 const id=r.works[0].id;
 r=mergeWorks(r.works,[{url:'https://www.instagram.com/creator/p/AbC/?igsh=SYNTHETIC',error:'当前图集来自本帖已加载的媒体；可切换轮播后重新识别补充图片',media:[{url:'https://i.test/2.jpg',kind:'image'}]}]);
 assert.equal(r.works.length,1);assert.equal(r.works[0].id,id);assert.equal(r.works[0].category,'自建分类');assert.equal(r.works[0].user,'发布者');assert.equal(r.works[0].media.length,2);
 assert.match(fileName(r.works[0],r.works[0].media[0],0),/Instagram（ins）\/自建分类\/发布者/);
});

test('ins mixed gallery offers image files and direct video separately, excluding cover by default',()=>{
 const w=normalizeWork({url:'https://www.instagram.com/reel/AbC/',media:[{url:'https://i.test/1.jpg',kind:'image'},{url:'https://i.test/cover.jpg',kind:'cover'},{url:'https://v.test/clip.mp4',kind:'video'}]});assert.equal(w.type,'mixed');assert.deepEqual(downloadCandidates([w]).map(x=>x.asset.kind),['image','video']);
});

test('manifest enables Instagram auto-capture without adding credential or clipboard-read access',async()=>{
 const m=JSON.parse(await readFile(new URL('../extension/manifest.json',import.meta.url),'utf8'));
 assert.ok(m.host_permissions.includes('https://*.instagram.com/*'));assert.ok(m.content_scripts[0].matches.includes('https://*.instagram.com/*'));
 assert.equal(m.permissions.includes('cookies'),false);assert.equal(m.permissions.includes('clipboardRead'),false);
});

test('old generic Instagram items migrate without changing ids, author names or categories',async()=>{
 const data={catalogV2:{version:2,works:[{id:'old-ins',url:'https://www.instagram.com/p/AbC/',platform:'web',title:'旧标题',user:'原发布者',category:'灵感参考',media:[]}],settings:{},categories:[],jobs:[],downloads:[]}};
 globalThis.chrome={storage:{local:{get:async()=>structuredClone(data),set:async x=>Object.assign(data,structuredClone(x))}}};
 const {readState}=await import('../extension/database.js');const s=await readState();assert.equal(s.works[0].id,'old-ins');assert.equal(s.works[0].platform,'instagram');assert.equal(s.works[0].user,'原发布者');assert.equal(s.works[0].category,'灵感参考');
});
