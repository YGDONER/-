import test from "node:test";
import assert from "node:assert/strict";
let storage = {},
  counter = 0,
  gate = null;
const items = new Map(),
  started = [];
const copy = (x) => structuredClone(x);
globalThis.chrome = {
  storage: {
    local: {
      get: async () => copy(storage),
      set: async (x) => Object.assign(storage, copy(x)),
    },
  },
  downloads: {
    download: async (options) => {
      const id = ++counter;
      started.push(id);
      items.set(id, {
        id,
        ...options,
        state: "in_progress",
        danger: "safe",
        mime: "image/jpeg",
        paused: false,
      });
      if (gate) await gate;
      return id;
    },
    search: async ({ id }) => (items.has(id) ? [copy(items.get(id))] : []),
    pause: async (id) => {
      items.get(id).paused = true;
    },
    resume: async (id) => {
      items.get(id).paused = false;
    },
    cancel: async (id) => {
      Object.assign(items.get(id), {
        state: "interrupted",
        error: "USER_CANCELED",
      });
    },
    onChanged: { addListener() {} },
    onErased: { addListener() {} },
  },
};
const { transact, latestState } = await import("../extension/database.js");
const { normalizeWork } = await import("../extension/core.js");
const { enqueueWorks, controlDownloads, updateDownload, pump, reconcile } =
  await import("../extension/downloads.js");
const tick = async () => {
  for (let i = 0; i < 20; i++) await new Promise(setImmediate);
};
async function fixture() {
  const work = normalizeWork({
    url: "https://www.instagram.com/p/Queue/",
    title: "一条多图笔记",
    media: [0, 1, 2].map((i) => ({
      url: `https://cdn.test/${i}.jpg`,
      kind: "image",
    })),
  });
  await transact((s) => {
    s.works = [work];
    s.jobs = [];
    s.downloads = [];
    s.settings = { concurrency: 1, paused: false, downloadEpoch: 0 };
  });
  return work;
}
await test("pause during an unresolved browser launch pauses the late file and starts no next file", async () => {
  const work = await fixture();
  let release;
  gate = new Promise((r) => (release = r));
  const before = started.length;
  await enqueueWorks([work.id], false);
  await tick();
  assert.equal(started.length, before + 1);
  await controlDownloads("pause");
  release();
  gate = null;
  await tick();
  const s = await latestState();
  assert.equal(s.settings.paused, true);
  assert.equal(s.downloads[0].state, "paused");
  assert.equal(items.get(s.downloads[0].downloadId).paused, true);
  assert.equal(started.length, before + 1);
  await controlDownloads("stop");
  await tick();
});
await test("stop during a launch cancels the late file, queued files and automatic parse downloads", async () => {
  const work = await fixture();
  let release;
  gate = new Promise((r) => (release = r));
  const before = started.length;
  await transact((s) =>
    s.jobs.push({
      id: "parsing",
      kind: "parse",
      state: "processing",
      downloadAfter: true,
    }),
  );
  await enqueueWorks([work.id], false);
  await tick();
  await controlDownloads("stop");
  let s = await latestState();
  assert.equal(s.settings.downloadEpoch, 1);
  assert.equal(s.jobs[0].state, "cancelled");
  assert.equal(s.jobs[0].downloadAfter, false);
  release();
  gate = null;
  await tick();
  s = await latestState();
  assert.ok(s.downloads.every((j) => j.state === "cancelled"));
  assert.equal(items.get(s.downloads[0].downloadId).state, "interrupted");
  const rejected = await enqueueWorks([work.id], false, null, null, 0);
  assert.equal(rejected.stopped, true);
  await reconcile();
  await tick();
  await controlDownloads("resume");
  await tick();
  assert.equal(started.length, before + 1);
  assert.equal((await latestState()).works.length, 1);
});
await test("late browser events do not resurrect cancelled downloads; completed files are preserved", async () => {
  const work = await fixture();
  await enqueueWorks([work.id], false);
  await tick();
  const first = (await latestState()).downloads[0];
  items.get(first.downloadId).state = "complete";
  await updateDownload(first.downloadId);
  await pump();
  await tick();
  await controlDownloads("stop");
  const stopped = (await latestState()).downloads.find(
    (j) => j.cancelRequested && j.downloadId !== null,
  );
  assert.ok(stopped);
  items.get(stopped.downloadId).state = "in_progress";
  await updateDownload(stopped.downloadId);
  await tick();
  const s = await latestState();
  assert.equal(s.downloads.find((j) => j.id === first.id).state, "completed");
  assert.equal(s.downloads.find((j) => j.id === stopped.id).state, "cancelled");
  assert.equal(items.get(stopped.downloadId).state, "interrupted");
});
await test("new explicitly queued files stay paused after stop until the user continues", async () => {
  const work = await fixture();
  await controlDownloads("stop");
  const before = started.length;
  const r = await enqueueWorks([work.id], false);
  assert.equal(r.queued, 3);
  await tick();
  assert.equal(started.length, before);
  await controlDownloads("resume");
  await tick();
  assert.equal(started.length, before + 1);
  await controlDownloads("stop");
  await tick();
});
