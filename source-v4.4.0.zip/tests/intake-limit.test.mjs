import test from "node:test";
import assert from "node:assert/strict";
import { mergeWorks, normalizeWork, titleTooLong } from "../extension/core.js";

test("exactly 200 Unicode characters are retained; 201 are skipped before normalization", () => {
  for (const char of ["字", "a", "📷"]) {
    assert.equal(titleTooLong(char.repeat(200)), false);
    assert.equal(titleTooLong(char.repeat(201)), true);
  }
  const result = mergeWorks(
    [],
    [
      { url: "https://www.instagram.com/p/Keep/", title: "📷".repeat(200) },
      { url: "https://www.instagram.com/p/Skip/", title: "字".repeat(201) },
      { url: "https://www.instagram.com/p/VeryLong/", title: "a".repeat(1000) },
    ],
  );
  assert.equal(result.added, 1);
  assert.equal(result.skipped, 2);
  assert.equal(result.works[0].url, "https://www.instagram.com/p/Keep/");
});
test("a long recapture does not overwrite an existing title, publisher, media or category", () => {
  const old = normalizeWork({
    url: "https://www.instagram.com/p/Keep/",
    title: "原来的作品",
    user: "发布账号",
    category: "我的分类",
    media: [{ url: "https://cdn.test/original.jpg", kind: "image" }],
  });
  const result = mergeWorks(
    [old],
    [{ url: old.url, title: "长".repeat(201), user: "错误账号", media: [] }],
  );
  assert.equal(result.skipped, 1);
  assert.deepEqual(result.works, [old]);
  assert.equal(result.merged, 0);
});
