import test from "node:test";
import assert from "node:assert/strict";
const event = () => ({
  listeners: [],
  addListener(f) {
    this.listeners.push(f);
  },
  removeListener(f) {
    this.listeners = this.listeners.filter((x) => x !== f);
  },
});
let data = {},
  tabId = 0,
  downId = 0,
  hold = null,
  captureTitle = "作品标题";
const tabs = new Map(),
  downloads = new Map();
const copy = (x) => structuredClone(x);
globalThis.chrome = {
  runtime: {
    id: "test",
    getURL: (p) => "chrome-extension://test/" + p,
    onMessage: event(),
    onStartup: event(),
    onInstalled: event(),
  },
  storage: {
    local: {
      get: async () => copy(data),
      set: async (v) => Object.assign(data, copy(v)),
    },
  },
  permissions: { contains: async () => true },
  tabs: {
    onUpdated: event(),
    get: async (id) => {
      if (!tabs.has(id)) throw new Error("closed");
      return copy(tabs.get(id));
    },
    query: async () => [...tabs.values()],
    create: async (o) => {
      const t = { id: ++tabId, status: "complete", ...o };
      if (t.url.includes("pin.it/short"))
        t.url = "https://www.pinterest.com/pin/999/";
      tabs.set(t.id, t);
      return copy(t);
    },
    update: async (id, o) => {
      if (!tabs.has(id)) throw new Error("closed");
      Object.assign(tabs.get(id), o);
      return copy(tabs.get(id));
    },
    remove: async (id) => tabs.delete(id),
  },
  scripting: {
    executeScript: async ({ target, args }) => {
      if (hold) await hold;
      const tab = tabs.get(target.tabId);
      if (tab.url.includes("blocked"))
        return [{ result: { works: [], blocked: true, message: "请先登录" } }];
      return [
        {
          result: {
            works: [
              {
                url:
                  args[0].mode === "list"
                    ? "https://www.pinterest.com/pin/444/"
                    : tab.url,
                title: captureTitle,
                user: "发布账号",
                media: [
                  { url: "https://i.test/1.jpg", kind: "image" },
                  { url: "https://i.test/2.jpg", kind: "image" },
                ],
              },
            ],
            message: "采集完成",
          },
        },
      ];
    },
  },
  downloads: {
    onChanged: event(),
    onErased: event(),
    download: async (o) => {
      const id = ++downId;
      downloads.set(id, {
        id,
        state: "in_progress",
        bytesReceived: 0,
        totalBytes: 100,
        ...o,
      });
      return id;
    },
    search: async ({ id }) =>
      downloads.has(id) ? [copy(downloads.get(id))] : [],
    show() {},
    pause: async () => {},
    resume: async () => {},
    cancel: async () => {},
  },
};
const { handleMessage } = await import("../extension/background.js");
const { latestState } = await import("../extension/database.js");
async function until(check) {
  for (let i = 0; i < 150; i++) {
    const s = await latestState();
    if (check(s)) return s;
    await new Promise((r) => setImmediate(r));
  }
  throw new Error("async task did not settle");
}
await test("background messages ignore other extensions", async () => {
  assert.equal(
    chrome.runtime.onMessage.listeners[0](
      { type: "GET" },
      { id: "other" },
      () => {},
    ),
    false,
  );
});
await test("download request during running parse is retained and executed after capture", async () => {
  await handleMessage({
    type: "ADD",
    text: "https://www.xiaohongshu.com/explore/abc",
  });
  const id = (await latestState()).works[0].id;
  let release;
  hold = new Promise((r) => (release = r));
  await handleMessage({ type: "PARSE", ids: [id] });
  await until((s) => s.jobs.some((j) => j.state === "processing"));
  await handleMessage({ type: "DOWNLOAD", ids: [id] });
  release();
  hold = null;
  const s = await until(
    (s) =>
      s.downloads.length === 2 && s.jobs.some((j) => j.state === "completed"),
  );
  assert.equal(s.works[0].user, "发布账号");
  assert.equal(s.jobs.filter((j) => j.kind === "parse").length, 1);
  assert.equal(s.works[0].media.length, 2);
});
await test("single asset download leaves full work gallery intact", async () => {
  await handleMessage({
    type: "ADD",
    works: [
      {
        url: "https://www.pinterest.com/pin/555/",
        media: [
          { url: "https://i.test/a.jpg", kind: "image" },
          { url: "https://i.test/b.jpg", kind: "image" },
        ],
      },
    ],
  });
  const w = (await latestState()).works.find((w) => w.url.includes("/555/"));
  const r = await handleMessage({
    type: "DOWNLOAD_ASSET",
    workId: w.id,
    index: 1,
  });
  assert.equal(r.queued, 1);
  const s = await latestState();
  assert.equal(s.works.find((x) => x.id === w.id).media.length, 2);
  assert.equal(s.downloads.filter((x) => x.workId === w.id).length, 1);
});
await test("short link redirect keeps original work id and replaces canonical URL", async () => {
  await handleMessage({ type: "ADD", text: "https://pin.it/short" });
  const w = (await latestState()).works.find((w) => w.url.includes("pin.it"));
  await handleMessage({ type: "PARSE", ids: [w.id] });
  const s = await until((s) =>
    s.jobs.some((j) => j.workId === w.id && j.state === "completed"),
  );
  assert.equal(
    s.works.find((x) => x.id === w.id).url,
    "https://www.pinterest.com/pin/999/",
  );
  assert.equal(s.works.filter((x) => x.url.includes("/999/")).length, 1);
});
await test("search honors zero scrolling and can retry after closed tab", async () => {
  await handleMessage({
    type: "SEARCH",
    keywords: "美食",
    platforms: ["pinterest"],
    rounds: 0,
  });
  let s = await until((s) =>
    s.jobs.some((j) => j.kind === "search" && j.state === "completed"),
  );
  const j = s.jobs.find((j) => j.kind === "search");
  assert.equal(j.rounds, 0);
  tabs.delete(j.tabId);
  await handleMessage({ type: "JOB_RETRY", id: j.id });
  s = await until(
    (s) => s.jobs.find((x) => x.id === j.id).state === "completed",
  );
  assert.notEqual(s.jobs.find((x) => x.id === j.id).tabId, j.tabId);
});
await test("blocked page stays attention and never gets a successful download", async () => {
  await handleMessage({
    type: "ADD",
    text: "https://www.pinterest.com/pin/blocked/",
  });
  const w = (await latestState()).works.find((w) => w.url.includes("blocked"));
  await handleMessage({ type: "DOWNLOAD", ids: [w.id] });
  const s = await until((s) =>
    s.jobs.some((j) => j.workId === w.id && j.state === "attention"),
  );
  assert.equal(s.downloads.filter((x) => x.workId === w.id).length, 0);
  assert.match(s.jobs.find((j) => j.workId === w.id).error, /登录/);
});
await test("batch size checks give explicit errors rather than silently truncating", async () => {
  await assert.rejects(
    handleMessage({ type: "PARSE", ids: Array(101).fill("x") }),
    /100/,
  );
  await assert.rejects(
    handleMessage({
      type: "SEARCH",
      keywords: Array(21).fill("a").join("\n"),
      platforms: ["pinterest"],
    }),
    /20/,
  );
});
await test("selected image keys enqueue only chosen files and preserve videos and gallery", async () => {
  await handleMessage({
    type: "ADD",
    works: [
      {
        url: "https://www.pinterest.com/pin/777/",
        media: [
          { url: "https://i.test/single1.jpg", kind: "image" },
          { url: "https://i.test/single2.jpg", kind: "image" },
          { url: "https://v.test/single.mp4", kind: "video" },
        ],
      },
    ],
  });
  const w = (await latestState()).works.find((w) => w.url.includes("/777/"));
  const r = await handleMessage({
    type: "DOWNLOAD_ASSETS",
    keys: [w.id + ":image:1"],
  });
  assert.equal(r.queued, 1);
  const s = await latestState();
  assert.equal(s.downloads.filter((j) => j.workId === w.id).length, 1);
  assert.equal(
    s.downloads.find((j) => j.workId === w.id).url,
    "https://i.test/single2.jpg",
  );
  assert.equal(s.works.find((x) => x.id === w.id).media.length, 3);
});
await test("grabbing an image gallery preserves previously collected video assets", async () => {
  await handleMessage({
    type: "ADD",
    works: [
      {
        url: "https://www.pinterest.com/pin/778/",
        media: [{ url: "https://v.test/keep.mp4", kind: "video" }],
      },
    ],
  });
  const tab = await chrome.tabs.create({
    url: "https://www.pinterest.com/pin/778/",
  });
  const r = await handleMessage({
    type: "GRAB_IMAGES",
    tabId: tab.id,
    scope: "work",
  });
  assert.equal(r.grabbed, 2);
  const w = (await latestState()).works.find((w) => w.url.includes("/778/"));
  assert.equal(w.media.filter((a) => a.kind === "video").length, 1);
  assert.equal(w.media.filter((a) => a.kind === "image").length, 2);
});
await test("content script cannot invoke delete or arbitrary extension operations", async () => {
  const { handleAutoMessage } = await import("../extension/background.js");
  await assert.rejects(
    handleAutoMessage(
      { type: "REMOVE", ids: ["x"] },
      { frameId: 0, tab: { id: 1 } },
    ),
    /不允许/,
  );
  await assert.rejects(
    handleAutoMessage({ type: "AUTO_CAPTURE" }, { frameId: 1, tab: { id: 1 } }),
    /顶层/,
  );
});

await test("full extension tabs remain authorized UI even when sender includes a tab", async () => {
  const { dispatchMessage } = await import("../extension/background.js");
  const r = await dispatchMessage(
    { type: "GET" },
    {
      id: "test",
      url: "chrome-extension://test/app.html?view=full",
      tab: { id: 99 },
      frameId: 0,
    },
  );
  assert.ok(r.state);
  await assert.rejects(
    dispatchMessage(
      { type: "GET" },
      {
        id: "test",
        url: "https://www.xiaohongshu.com/explore/abc",
        tab: { id: 99 },
        frameId: 0,
      },
    ),
    /不允许/,
  );
});

async function galleryFixture(pin) {
  const media = Array.from({ length: 8 }, (_, i) => ({
    url: `https://i.test/${pin}-${i + 1}.jpg`,
    kind: "image",
  }));
  media.push(
    { url: `https://i.test/${pin}-cover.jpg`, kind: "cover" },
    { url: `https://v.test/${pin}.mp4`, kind: "video" },
  );
  await handleMessage({
    type: "ADD",
    works: [{ url: `https://www.pinterest.com/pin/${pin}/`, media }],
  });
  return (await latestState()).works.find((w) => w.url.includes(`/${pin}/`));
}
await test("per-note selection downloads exactly images 2 and 5 from an eight-image note", async () => {
  const w = await galleryFixture("801"),
    urls = [w.media[1].url, w.media[4].url];
  const r = await handleMessage({
    type: "DOWNLOAD_IMAGES",
    workId: w.id,
    urls,
  });
  assert.equal(r.queued, 2);
  const s = await latestState(),
    jobs = s.downloads.filter((j) => j.workId === w.id);
  assert.deepEqual(
    jobs.map((j) => j.url),
    urls,
  );
  assert.ok(jobs.every((j) => j.assetKind === "image"));
  assert.equal(s.works.find((x) => x.id === w.id).media.length, 10);
});
await test("empty or malformed image selection does not fall back to downloading the whole note", async () => {
  const w = await galleryFixture("802");
  for (const urls of [[], undefined, [null], Array(501).fill(w.media[0].url)]) {
    await assert.rejects(
      handleMessage({ type: "DOWNLOAD_IMAGES", workId: w.id, urls }),
      /勾选|无效/,
    );
  }
  assert.equal(
    (await latestState()).downloads.filter((j) => j.workId === w.id).length,
    0,
  );
});
await test("stale selection, another note, cover and video are rejected before any image is queued", async () => {
  const w = await galleryFixture("803");
  for (const bad of [
    "https://i.test/missing.jpg",
    w.media[8].url,
    w.media[9].url,
  ]) {
    await assert.rejects(
      handleMessage({
        type: "DOWNLOAD_IMAGES",
        workId: w.id,
        urls: [w.media[1].url, bad],
      }),
      /重新确认/,
    );
  }
  await assert.rejects(
    handleMessage({
      type: "DOWNLOAD_IMAGES",
      workId: "missing-note",
      urls: [w.media[1].url],
    }),
    /重新确认/,
  );
  assert.equal(
    (await latestState()).downloads.filter((j) => j.workId === w.id).length,
    0,
  );
});
await test("selected URLs keep their identity when the note image order changes", async () => {
  const w = await galleryFixture("804"),
    urls = [w.media[1].url, w.media[4].url];
  const { transact } = await import("../extension/database.js");
  await transact((s) => {
    s.works.find((x) => x.id === w.id).media.reverse();
  });
  const r = await handleMessage({
    type: "DOWNLOAD_IMAGES",
    workId: w.id,
    urls,
  });
  assert.equal(r.queued, 2);
  assert.deepEqual(
    (await latestState()).downloads
      .filter((j) => j.workId === w.id)
      .map((j) => j.url)
      .sort(),
    [...urls].sort(),
  );
});
await test("repeated selected image URLs do not create duplicate download jobs", async () => {
  const w = await galleryFixture("805"),
    url = w.media[1].url;
  const r = await handleMessage({
    type: "DOWNLOAD_IMAGES",
    workId: w.id,
    urls: [url, url],
  });
  assert.equal(r.queued, 1);
  const again = await handleMessage({
    type: "DOWNLOAD_IMAGES",
    workId: w.id,
    urls: [url],
  });
  assert.equal(again.queued, 0);
  assert.equal(again.skipped, 1);
  assert.equal(
    (await latestState()).downloads.filter((j) => j.workId === w.id).length,
    1,
  );
});
await test("reordering after a previous selection does not mistake another picture for an existing job", async () => {
  const w = await galleryFixture("806"),
    first = w.media[0].url,
    next = w.media[1].url;
  await handleMessage({ type: "DOWNLOAD_IMAGES", workId: w.id, urls: [first] });
  const { transact } = await import("../extension/database.js");
  await transact((s) => {
    const a = s.works.find((x) => x.id === w.id).media;
    [a[0], a[1]] = [a[1], a[0]];
  });
  const r = await handleMessage({
    type: "DOWNLOAD_IMAGES",
    workId: w.id,
    urls: [next],
  });
  assert.equal(r.queued, 1);
  assert.deepEqual(
    (await latestState()).downloads
      .filter((j) => j.workId === w.id)
      .map((j) => j.url),
    [first, next],
  );
});
await test("retrying an expired selected image never substitutes a different picture at the same index", async () => {
  const w = await galleryFixture("807"),
    url = w.media[0].url;
  await handleMessage({ type: "DOWNLOAD_IMAGES", workId: w.id, urls: [url] });
  const { transact } = await import("../extension/database.js");
  let jobId;
  await transact((s) => {
    const j = s.downloads.find((j) => j.workId === w.id);
    jobId = j.id;
    j.state = "failed";
    s.works.find((x) => x.id === w.id).media.shift();
  });
  await handleMessage({
    type: "DOWNLOAD_CONTROL",
    action: "retry",
    ids: [jobId],
  });
  const job = (await latestState()).downloads.find((j) => j.id === jobId);
  assert.equal(job.url, url);
  assert.equal(job.state, "failed");
  assert.match(job.error, /重新勾选/);
});

await test("unknown extension pages and absent message origins cannot invoke privileged UI commands", async () => {
  const { dispatchMessage } = await import("../extension/background.js");
  for (const url of [
    undefined,
    "chrome-extension://test/unlisted.html",
    "chrome-extension://test.evil/app.html",
    "https://test/app.html",
  ])
    await assert.rejects(
      dispatchMessage({ type: "GET" }, { id: "test", url }),
      /仅允许/,
    );
  await assert.rejects(
    dispatchMessage(
      { type: "GET" },
      { id: "other", url: "chrome-extension://test/app.html" },
    ),
    /来源/,
  );
});

await test("manual capture skips titles above 200 without importing or downloading them", async () => {
  const tab = await chrome.tabs.create({
    url: "https://www.instagram.com/p/LongCapture/",
  });
  captureTitle = "字".repeat(201);
  const before = await latestState();
  const result = await handleMessage({
    type: "CAPTURE",
    tabId: tab.id,
    mode: "detail",
  });
  captureTitle = "作品标题";
  assert.equal(result.skipped, 1);
  assert.match(result.message, /超过 200/);
  assert.equal(result.state.works.length, before.works.length);
  assert.equal(result.state.downloads.length, before.downloads.length);
});
await test("ending downloads during parse cancels the job and prevents late automatic enqueue", async () => {
  await handleMessage({ type: "DOWNLOAD_CONTROL", action: "stop" });
  await handleMessage({ type: "DOWNLOAD_CONTROL", action: "resume" });
  await handleMessage({
    type: "ADD",
    text: "https://www.instagram.com/p/StopDuringParse/",
  });
  const work = (await latestState()).works.find((w) =>
    w.url.includes("StopDuringParse"),
  );
  let release;
  hold = new Promise((r) => (release = r));
  await handleMessage({ type: "DOWNLOAD", ids: [work.id] });
  const preparing = await until((s) =>
    s.jobs.some(
      (j) => j.workId === work.id && j.state === "processing" && j.tabId,
    ),
  );
  const job = preparing.jobs.find((j) => j.workId === work.id);
  await handleMessage({ type: "DOWNLOAD_CONTROL", action: "stop" });
  release();
  hold = null;
  const s = await until((s) => !tabs.has(job.tabId));
  assert.equal(s.jobs.find((j) => j.id === job.id).state, "cancelled");
  assert.equal(s.jobs.find((j) => j.id === job.id).downloadAfter, false);
  assert.equal(s.downloads.filter((d) => d.workId === work.id).length, 0);
});
await test("a long title found during automatic download parsing is skipped, never downloaded", async () => {
  await handleMessage({ type: "DOWNLOAD_CONTROL", action: "resume" });
  await handleMessage({
    type: "ADD",
    text: "https://www.instagram.com/p/LongParsed/",
  });
  const work = (await latestState()).works.find((w) =>
    w.url.includes("LongParsed"),
  );
  captureTitle = "长".repeat(201);
  await handleMessage({ type: "DOWNLOAD", ids: [work.id] });
  const s = await until((s) =>
    s.jobs.some((j) => j.workId === work.id && j.state === "skipped"),
  );
  captureTitle = "作品标题";
  assert.equal(s.downloads.filter((d) => d.workId === work.id).length, 0);
  assert.match(s.jobs.find((j) => j.workId === work.id).error, /超过 200/);
});
