import test from "node:test";
import assert from "node:assert/strict";
import {
  describePixels,
  comparePictures,
} from "../extension/image-similarity.js";
const picture = (r, g, b) =>
  describePixels(
    Uint8ClampedArray.from(
      Array.from({ length: 256 }, () => [r, g, b, 255]).flat(),
    ),
  );
test("local pixel ranking scores identical images highest and distinguishes different colours", () => {
  const red = picture(255, 0, 0),
    blue = picture(0, 0, 255);
  assert.equal(comparePictures(red, red), 100);
  assert.ok(comparePictures(red, blue) < 65);
  assert.ok(comparePictures(picture(255, 255, 255), picture(0, 0, 0)) < 50);
  assert.ok(
    comparePictures(red, picture(245, 10, 5)) > comparePictures(red, blue),
  );
});
test("colour/layout comparison detects different spatial arrangements, not just a shared palette", () => {
  const pixels = (flip) =>
    Uint8ClampedArray.from(
      Array.from({ length: 256 }, (_, i) =>
        i % 16 < 8 !== flip ? [255, 40, 20, 255] : [10, 30, 230, 255],
      ).flat(),
    );
  const original = describePixels(pixels(false));
  assert.equal(comparePictures(original, original), 100);
  assert.ok(comparePictures(original, describePixels(pixels(true))) < 80);
});
