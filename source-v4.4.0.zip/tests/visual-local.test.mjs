import test from "node:test";
import assert from "node:assert/strict";
let data = {},
  active = 9,
  captured = 0,
  changed = false,
  captureGate = null;
const tabs = new Map([
  [
    1,
    {
      id: 1,
      windowId: 1,
      url: "https://www.instagram.com/explore/",
      status: "complete",
    },
  ],
  [
    2,
    {
      id: 2,
      windowId: 1,
      url: "https://www.xiaohongshu.com/explore",
      status: "complete",
    },
  ],
  [
    9,
    {
      id: 9,
      windowId: 1,
      url: "chrome-extension://test/app.html",
      status: "complete",
    },
  ],
]);
const copy = (x) => structuredClone(x);
globalThis.chrome = {
  storage: {
    local: {
      get: async () => copy(data),
      set: async (v) => Object.assign(data, copy(v)),
      remove: async (key) => delete data[key],
    },
  },
  permissions: { contains: async () => true },
  tabs: {
    get: async (id) => {
      if (!tabs.has(id)) throw new Error("closed");
      return { ...tabs.get(id), active: active === id };
    },
    query: async () => [{ ...tabs.get(active), active: true }],
    update: async (id, options) => {
      if (!tabs.has(id)) throw new Error("closed");
      if (options.active) active = id;
      return copy(tabs.get(id));
    },
    captureVisibleTab: async () => {
      captured++;
      if (captureGate) await captureGate;
      return "data:image/png;base64,AAAA";
    },
  },
  scripting: {
    executeScript: async ({ func, target }) => {
      if (func.name === "collectPage") return [{ result: { works: [] } }];
      const result = {
        url: tabs.get(target.tabId).url,
        viewport: { width: 1200, height: 800, x: 0, y: 0 },
        candidates: [
          {
            id: "picture-0",
            url: "https://www.instagram.com/p/First/",
            title: "第一张",
            imageUrl: "https://cdn.test/one.jpg",
            rect: { x: 0, y: 0, width: 200, height: 200 },
          },
          {
            id: "picture-1",
            url: "https://www.instagram.com/p/Long/",
            title: "长".repeat(201),
            imageUrl: "https://cdn.test/long.jpg",
            rect: { x: 200, y: 0, width: 200, height: 200 },
          },
        ],
      };
      if (changed)
        tabs.get(target.tabId).url = "https://www.xiaohongshu.com/explore";
      return [{ result }];
    },
  },
};
const { handleLocalVisualMessage } = await import(
  "../extension/visual-local.js"
);
const { handleVisualMessage } = await import("../extension/visual-service.js");
const { latestState, transact } = await import("../extension/database.js");
const reference = {
  id: "ref",
  name: "参考.png",
  type: "image",
  frames: [
    {
      id: "frame",
      dataUrl: "data:image/png;base64,AAAA",
      width: 300,
      height: 200,
    },
  ],
};
const start = (extra = {}) =>
  handleLocalVisualMessage({
    type: "VISUAL_LOCAL_START",
    sourceTabId: 1,
    reference,
    frameIds: ["frame"],
    ...extra,
  });
async function reset() {
  changed = false;
  active = 9;
  tabs.get(1).url = "https://www.instagram.com/explore/";
  await handleVisualMessage({ type: "VISUAL_CLEAR" });
}
await test("local matching reads only the chosen IG page, skips long titles and restores the workbench", async () => {
  await reset();
  const r = await start();
  assert.equal(active, 9);
  assert.equal(r.snapshot.candidates.length, 1);
  assert.equal(r.snapshot.skipped, 1);
  assert.deepEqual(r.state.visualSearch.platforms, ["instagram"]);
  assert.equal(r.state.visualSearch.sourceTabId, 1);
  assert.equal(r.state.works.length, 0);
  assert.equal(r.state.downloads.length, 0);
  const result = await handleLocalVisualMessage({
    type: "VISUAL_LOCAL_FINISH",
    visualId: r.visualId,
    matches: [
      {
        id: "picture-0",
        score: 95,
        frameIds: ["frame"],
        url: "https://www.xiaohongshu.com/explore/evil",
        thumbnail: "data:image/jpeg;base64,AAAA",
      },
      { id: "forged", score: 100, frameIds: ["frame"] },
    ],
  });
  const v = result.state.visualSearch;
  assert.equal(v.state, "completed");
  assert.equal(v.results.length, 1);
  assert.equal(v.results[0].url, "https://www.instagram.com/p/First/");
  assert.equal(v.results[0].method, "local-page");
  assert.equal(v.results[0].similarity, 95);
  assert.equal(result.state.works.length, 0);
});
await test("local search rejects unselected/closed sources and external engines without taking a screenshot", async () => {
  await reset();
  const before = captured;
  await assert.rejects(start({ sourceTabId: 9 }), /支持平台网页/);
  await assert.rejects(start({ sourceTabId: 555 }), /closed/);
  await assert.rejects(start({ engine: "bing" }), /不使用站外/);
  await assert.rejects(start({ engine: "google" }), /不使用站外/);
  assert.equal(captured, before);
});
await test("navigation to another platform aborts before a screenshot can be returned", async () => {
  await reset();
  changed = true;
  const before = captured;
  await assert.rejects(start(), /页面已切换/);
  assert.equal(captured, before);
  assert.equal((await latestState()).visualSearch.state, "attention");
});
await test("stopping during local capture prevents late results from reviving a cancelled session", async () => {
  await reset();
  let release;
  captureGate = new Promise((r) => (release = r));
  const before = captured;
  const request = start();
  for (let i = 0; i < 100 && captured === before; i++)
    await new Promise(setImmediate);
  assert.equal(captured, before + 1);
  await handleVisualMessage({ type: "VISUAL_CANCEL" });
  release();
  captureGate = null;
  await assert.rejects(request, /检索已停止/);
  const v = (await latestState()).visualSearch;
  assert.equal(v.state, "cancelled");
  assert.deepEqual(v.results, []);
});
