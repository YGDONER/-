import { normalizeWork, uid, CATEGORIES, platformOf } from "./core.js";
let chain = Promise.resolve();
export async function readState() {
  const data = await chrome.storage.local.get(["catalogV2", "notes"]);
  if (data.catalogV2?.version === 2) {
    const s = data.catalogV2;
    s.works = s.works.map((w) => {
      const platform = platformOf(w.url);
      return w.platform === "web" &&
        ["pdd", "vip", "instagram"].includes(platform)
        ? {
            ...w,
            platform,
            category:
              ["pdd", "vip"].includes(platform) && w.category === "未分类"
                ? "商品"
                : w.category,
          }
        : w;
    });
    s.settings = {
      autoCapture: true,
      autoNotice: true,
      autoSites: [],
      ...s.settings,
    };
    return s;
  }
  return {
    version: 2,
    works: (data.notes || []).map(normalizeWork).filter(Boolean),
    downloads: [],
    jobs: [],
    categories: [...CATEGORIES],
    settings: {
      concurrency: 2,
      includeCovers: false,
      autoCapture: true,
      autoNotice: true,
      autoSites: [],
    },
    updatedAt: Date.now(),
  };
}
export function transact(fn) {
  const next = chain.then(async () => {
    const state = structuredClone(await readState());
    const extra = (await fn(state)) || {};
    state.updatedAt = Date.now();
    await chrome.storage.local.set({ catalogV2: state });
    return { state, ...extra };
  });
  chain = next.catch(() => {});
  return next;
}
export async function latestState() {
  await chain;
  return readState();
}
export function newJob(data) {
  return {
    id: uid(),
    createdAt: Date.now(),
    state: "pending",
    error: "",
    ...data,
  };
}
