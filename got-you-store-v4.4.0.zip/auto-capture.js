import {
  isDetail,
  platformOf,
  workKey,
  httpUrl,
  mergeWorks,
  titleTooLong,
} from "./core.js";
import { latestState, transact } from "./database.js";
import { applyCategoryRules } from "./categories.js";
const busy = new Set(),
  seen = new Map();
export async function autoCapture(tabId, capture) {
  const state = await latestState();
  if (state.settings.autoCapture === false)
    return { captured: false, reason: "disabled" };
  if (busy.has(tabId)) return { captured: false, reason: "busy" };
  const tab = await chrome.tabs.get(tabId);
  if (!httpUrl(tab.url) || !tab.active)
    return { captured: false, reason: "inactive" };
  const platform = platformOf(tab.url);
  if (platform !== "web" && !isDetail(tab.url))
    return { captured: false, reason: "list" };
  if (
    platform === "web" &&
    !(state.settings.autoSites || []).includes(new URL(tab.url).origin)
  )
    return { captured: false, reason: "unauthorized" };
  const key = workKey(tab.url),
    recent = seen.get(tabId);
  if (recent?.key === key && Date.now() - recent.time < 600)
    return { captured: false, reason: "debounced" };
  busy.add(tabId);
  try {
    const data = await capture(tabId, {
      mode: "detail",
      settle: false,
      identityOnly: true,
    });
    if (data.blocked || !data.works?.length)
      return { captured: false, reason: data.message || "unavailable" };
    const work = data.works.find((w) => workKey(w.url) === key);
    if (!work) return { captured: false, reason: "navigation" };
    if (titleTooLong(work.title))
      return {
        captured: false,
        reason: "title-too-long",
        message: "标题超过 200 个字符，已自动跳过",
      };
    const after = await chrome.tabs.get(tabId);
    if (!after.active || workKey(after.url) !== key)
      return { captured: false, reason: "navigation" };
    if ((await latestState()).settings.autoCapture === false)
      return { captured: false, reason: "disabled" };
    const signature = JSON.stringify([
      work.title,
      work.user,
      work.media,
      work.error,
    ]);
    if (recent?.key === key && recent.signature === signature) {
      seen.set(tabId, { ...recent, time: Date.now() });
      return { captured: false, reason: "unchanged" };
    }
    const result = await transact((s) => {
      if (s.settings.autoCapture === false) return { captured: false };
      const r = mergeWorks(s.works, [{ ...work, source: "automatic" }]);
      s.works = r.works;
      applyCategoryRules(s);
      const saved = s.works.find((w) => workKey(w.url) === key);
      if (!saved) return { captured: false };
      s.autoLast = {
        workId: saved.id,
        tabId,
        url: saved.url,
        title: saved.title,
        user: saved.user,
        platform: saved.platform,
        at: Date.now(),
      };
      return {
        captured: true,
        workId: saved.id,
        title: saved.title,
        user: saved.user,
        notice: s.settings.autoNotice !== false,
        added: r.added,
      };
    });
    if (!result.captured) return { captured: false, reason: "disabled" };
    seen.set(tabId, { key, signature, time: Date.now() });
    if (seen.size > 100) {
      const oldest = seen.keys().next().value;
      seen.delete(oldest);
    }
    try {
      await chrome.action.setBadgeBackgroundColor({ color: "#dd735f" });
      await chrome.action.setBadgeText({
        text: result.added ? "+1" : "✓",
        tabId,
      });
    } catch {}
    return {
      captured: result.captured,
      workId: result.workId,
      title: result.title,
      user: result.user,
      notice: result.notice,
    };
  } finally {
    busy.delete(tabId);
  }
}
export async function enableAutoSite(tabId) {
  const tab = await chrome.tabs.get(Number(tabId));
  if (!httpUrl(tab.url)) throw new Error("请选择普通网页");
  const origin = new URL(tab.url).origin;
  if (!(await chrome.permissions.contains({ origins: [origin + "/*"] })))
    throw new Error("请先授权该网站");
  await transact((s) => {
    const sites = s.settings.autoSites || [];
    if (!sites.includes(origin)) sites.push(origin);
    s.settings.autoSites = sites;
  });
  await syncAutoSites();
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["auto-watch.js"],
  });
  return { state: await latestState() };
}
export async function syncAutoSites() {
  if (!chrome.scripting.getRegisteredContentScripts) return;
  const state = await latestState(),
    sites = state.settings.autoSites || [],
    allowed = [];
  for (const site of sites)
    if (
      httpUrl(site) &&
      (await chrome.permissions.contains({ origins: [site + "/*"] }))
    )
      allowed.push(site + "/*");
  const scripts = await chrome.scripting.getRegisteredContentScripts();
  const ids = scripts
    .filter((s) => s.id === "link-note-extra-sites")
    .map((s) => s.id);
  if (ids.length) await chrome.scripting.unregisterContentScripts({ ids });
  if (allowed.length)
    await chrome.scripting.registerContentScripts([
      {
        id: "link-note-extra-sites",
        matches: allowed,
        js: ["auto-watch.js"],
        runAt: "document_idle",
        persistAcrossSessions: true,
      },
    ]);
}
export async function injectOpenPages() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!httpUrl(tab.url)) continue;
    try {
      if (
        await chrome.permissions.contains({
          origins: [new URL(tab.url).origin + "/*"],
        })
      )
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["auto-watch.js"],
        });
    } catch {}
  }
}
