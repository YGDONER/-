import { transact, latestState } from "./database.js";
export async function updateInfo() {
  let installType = "unknown";
  try {
    installType = (await chrome.management.getSelf()).installType;
  } catch {}
  const state = await latestState();
  return {
    version: chrome.runtime.getManifest().version,
    installType,
    available: state.update?.available || "",
    checkedAt: state.update?.checkedAt || 0,
    status: state.update?.status || "",
    development: installType === "development",
  };
}
export async function checkUpdate() {
  const info = await updateInfo();
  if (info.development)
    return {
      ...info,
      status: "development",
      message:
        "当前为本地解压版。下载新版后覆盖原目录并重新加载即可保留清单；本地刷新不会自动取得远程代码。",
    };
  const now = Date.now(),
    state = await latestState();
  if (
    state.update?.checkedAt &&
    now - state.update.checkedAt < 60000 &&
    !info.available
  )
    return {
      ...info,
      status: "throttled",
      message: "刚刚检查过，请稍后再试。浏览器也会自动检查更新。",
    };
  const result = await chrome.runtime.requestUpdateCheck();
  await transact((s) => {
    s.update = {
      ...s.update,
      status: result.status,
      checkedAt: now,
      available: result.version || s.update?.available || "",
    };
  });
  return {
    ...(await updateInfo()),
    message:
      result.status === "update_available"
        ? "新版已下载，可点击“刷新启用新版”。"
        : result.status === "throttled"
          ? "浏览器限制了检查频率，请稍后重试。"
          : "当前没有可用更新，商店审核通过后浏览器会自动获取。",
  };
}
export async function applyUpdate() {
  const info = await updateInfo();
  if (!info.available) throw new Error("尚无已下载的新版，请先检查更新");
  const s = await latestState();
  if (s.visualSearch?.state === "running")
    throw new Error("请等待相似检索结束，或停止检索后再启用新版");
  if (
    s.jobs.some((j) =>
      ["processing", "loading", "collecting"].includes(j.state),
    )
  )
    throw new Error("请等待采集或解析任务结束，再刷新启用新版");
  return { ready: true, version: info.available };
}
export function registerUpdateEvents() {
  chrome.runtime.onUpdateAvailable?.addListener((details) => {
    void transact((s) => {
      s.update = {
        ...s.update,
        available: details.version,
        status: "update_available",
      };
    });
  });
  chrome.runtime.onInstalled.addListener(() => {
    void transact((s) => {
      if (s.update?.available === chrome.runtime.getManifest().version)
        s.update.available = "";
    });
  });
}
