import { installReferencePaste } from "./reference-paste.js";
import { NATIVE_SEARCH } from "./visual-core.js";
import { rankPagePictures } from "./image-similarity.js";
import { readReferenceFile } from "./reference-media.js";
import { PLATFORMS } from "./core.js";

export function setupVisualUI({
  getState,
  getView,
  send,
  run,
  toast,
  node,
  button,
  options,
  categories,
  openDetail,
}) {
  const $ = (id) => document.getElementById(id),
    names = Object.fromEntries(PLATFORMS.map((p) => [p.id, p.name]));
  let categoryReady = false,
    reference = null,
    frameIds = new Set(),
    chosen = new Set(),
    controller,
    loading = false,
    starting = false,
    signature = "",
    sourceTabs = [],
    searchController,
    platformSelection = new Set();
  const v = () => getState().visualSearch;
  function currentSource() {
    return sourceTabs.find(
      (t) => String(t.id) === $("visual-source-tab").value,
    );
  }
  function renderPlatforms() {
    const source = currentSource();
    platformSelection = new Set(source ? [source.platform] : []);
    const local = $("visual-search-method").value !== "native";
    $("visual-platforms").replaceChildren();
    if (source)
      $("visual-platforms").append(
        node("strong", "visual-platform selected", names[source.platform]),
      );
    $("visual-scope-summary").textContent = source
      ? `本次仅在：${names[source.platform]}`
      : "请先打开平台网页，再刷新列表";
    $("visual-all-platforms").hidden = true;
    $("visual-threshold-label").hidden = !local;
    $("visual-start").textContent = local
      ? "在本页图片中找相似"
      : "在当前平台原生搜图";
    $("visual-capability").textContent = !source
      ? "支持浏览器已打开的 IG、小红书、Pinterest 等平台页面。"
      : local
        ? "仅比较当前可视区域已加载的帖子图片，不搜索全站。可以滚动平台页面后再匹配。"
        : NATIVE_SEARCH[source.platform].hint;
  }
  async function refreshSourceTabs() {
    const previous = $("visual-source-tab").value;
    const data = await send("TABS");
    sourceTabs = (data?.tabs || []).filter((t) => NATIVE_SEARCH[t.platform]);
    options(
      $("visual-source-tab"),
      sourceTabs.map((t) => ({
        id: String(t.id),
        name: `${names[t.platform]} · ${t.title}`,
      })),
      ["", "选择已打开的平台网页"],
    );
    const initial = new URLSearchParams(globalThis.location?.search || "").get(
      "sourceTab",
    );
    const preferred =
      sourceTabs.find((t) => String(t.id) === previous) ||
      sourceTabs.find((t) => String(t.id) === initial) ||
      sourceTabs.find((t) => t.active) ||
      sourceTabs[0];
    $("visual-source-tab").value = preferred ? String(preferred.id) : "";
    renderPlatforms();
    renderReference();
  }
  $("visual-source-tab").addEventListener("change", () => {
    renderPlatforms();
    renderReference();
  });
  $("visual-search-method").addEventListener("change", () => {
    renderPlatforms();
    renderReference();
  });
  $("visual-refresh-tabs").addEventListener("click", () =>
    run(refreshSourceTabs, $("visual-refresh-tabs")),
  );
  renderPlatforms();
  function renderReference() {
    const frames = reference?.frames || [];
    $("visual-reference-name").textContent =
      reference?.name || "还没有参考素材";
    $("visual-reference-meta").textContent = reference
      ? reference.type === "video"
        ? `已在本机抽取 ${frames.length} 个画面；可选 1–3 帧检索，不上传整段视频。`
        : "图片已在本机生成搜索副本，原文件不变。"
      : "图片直接预览；视频自动抽帧。选择文件后，再点击开始检索。";
    $("visual-reference-clear").hidden = !reference;
    $("visual-frames").replaceChildren();
    frames.forEach((f, i) => {
      const label = node("label", "visual-frame"),
        image = node("img"),
        check = node("input");
      image.src = f.dataUrl;
      image.alt =
        reference.type === "video" ? `视频参考画面 ${i + 1}` : "上传的参考图片";
      check.type = "checkbox";
      check.checked = frameIds.has(f.id);
      check.setAttribute("aria-label", `使用参考画面 ${i + 1}`);
      check.addEventListener("change", () => {
        if (check.checked && frameIds.size >= 3) {
          check.checked = false;
          return toast("每次最多选 3 个画面");
        }
        check.checked ? frameIds.add(f.id) : frameIds.delete(f.id);
        renderReference();
      });
      label.classList.toggle("picked", check.checked);
      label.append(
        image,
        check,
        node(
          "span",
          "",
          reference.type === "video" ? `${f.time.toFixed(1)} 秒` : "参考图片",
        ),
      );
      $("visual-frames").append(label);
    });
    $("visual-frame-count").textContent = `已选 ${frameIds.size} 个参考画面`;
    $("visual-start").disabled =
      loading ||
      starting ||
      !frameIds.size ||
      !platformSelection.size ||
      v()?.state === "running";
  }
  async function loadFile(file, source = "file") {
    controller?.abort();
    const abort = new AbortController();
    controller = abort;
    loading = true;
    $("visual-error").textContent = "";
    $("visual-upload-status").textContent = "正在本机读取参考素材…";
    renderReference();
    try {
      const next = await readReferenceFile(file, {
        signal: abort.signal,
        onProgress: (s) => ($("visual-upload-status").textContent = s),
      });
      if (abort.signal.aborted) return;
      reference = next;
      if (source === "paste") reference.name = "粘贴截图 · " + reference.name;
      frameIds = new Set(
        next.type === "video"
          ? [next.frames[0].id, next.frames[2].id, next.frames[4].id]
          : [next.frames[0].id],
      );
      $("visual-upload-status").textContent =
        source === "paste"
          ? "截图已粘贴，可直接选择平台开始检索。"
          : "参考素材已就绪，可开始检索。";
      renderReference();
    } catch (e) {
      if (e.name !== "AbortError") {
        $("visual-error").textContent = e.message;
        $("visual-upload-status").textContent = "";
      }
    } finally {
      if (controller === abort) {
        loading = false;
        renderReference();
      }
    }
  }
  function results() {
    const p = $("visual-result-platform").value;
    return (v()?.results || [])
      .filter((r) => p === "all" || r.platform === p)
      .sort(
        (a, b) =>
          (b.similarity || 0) - (a.similarity || 0) ||
          b.frameIds.length - a.frameIds.length ||
          a.rank - b.rank,
      );
  }
  function counts() {
    const entries = results(),
      n = entries.filter((r) => chosen.has(r.id)).length;
    $("visual-results-count").textContent =
      `${entries.length} 条候选 · 已选 ${chosen.size} 条`;
    $("visual-select-all").checked = entries.length > 0 && n === entries.length;
    $("visual-select-all").indeterminate = n > 0 && n < entries.length;
    $("visual-results-import").disabled = !chosen.size;
  }
  function render() {
    if (getView() !== "visual") return;
    const session = v(),
      items = session?.results || [];
    chosen = new Set(
      [...chosen].filter((id) => items.some((x) => x.id === id)),
    );
    options($("visual-import-category"), categories());
    if (!categoryReady) {
      $("visual-import-category").value = categories().includes("灵感参考")
        ? "灵感参考"
        : categories()[0];
      categoryReady = true;
    }
    $("visual-cancel").hidden = !starting && session?.state !== "running";
    $("visual-continue").hidden =
      session?.state !== "attention" ||
      session?.scopeVersion !== 3 ||
      session?.localMode ||
      !session?.tasks?.some((t) => t.state === "attention");
    $("visual-start").disabled =
      loading ||
      starting ||
      !frameIds.size ||
      !platformSelection.size ||
      session?.state === "running";
    const finished =
        session?.tasks?.filter((t) => t.state === "completed").length || 0,
      total = session?.tasks?.length || 0;
    $("visual-progress").max = total || 1;
    $("visual-progress").value = finished;
    $("visual-session-status").textContent = !session
      ? "上传参考素材后选择目标平台"
      : session.state === "running"
        ? session.localMode
          ? "正在本机比较当前页面图片…"
          : `正在检查当前平台原生搜图 · ${finished} / ${total} 个检索任务完成`
        : session.state === "attention"
          ? `需要查看平台入口 · 已返回 ${items.length} 条候选`
          : session.state === "cancelled"
            ? session.legacyMessage ||
              `检索已停止 · 保留 ${items.length} 条候选`
            : `检索完成 · ${items.length} 条候选`;
    $("visual-provider-info").textContent = session
      ? `${session.localMode ? "本页画面匹配 · 未搜索全站" : "当前平台原生搜图"} · ${session.platforms.map((p) => names[p]).join("、")} · ${session.name}`
      : "";
    $("visual-task-list").replaceChildren();
    for (const t of session?.tasks || []) {
      const row = node("div", "visual-task"),
        label = `${names[t.platform]} · ${session.type === "video" ? (Number(t.time) || 0).toFixed(1) + " 秒参考帧" : "参考图"}`;
      row.append(
        node("span", "", label),
        node(
          "small",
          ["attention", "unsupported"].includes(t.state) ? "danger" : "muted",
          t.error ||
            {
              pending: "等待中",
              processing: "正在检查／检索",
              completed: `${session.localMode ? "本页比较返回" : "平台搜图返回"} ${t.count || 0} 条候选`,
              cancelled: "已停止",
            }[t.state],
        ),
      );
      if (t.tabId)
        row.append(
          button("查看平台页面 ↗", () =>
            chrome.tabs.update(t.tabId, { active: true }),
          ),
        );
      $("visual-task-list").append(row);
    }

    const resultScope = session?.platforms || [...platformSelection];
    options(
      $("visual-result-platform"),
      PLATFORMS.filter((p) => resultScope.includes(p.id)),
      ["all", "本次所选平台"],
    );
    counts();
    const sig = JSON.stringify([
      session?.id,
      items,
      $("visual-result-platform").value,
    ]);
    if (sig === signature) return;
    signature = sig;
    $("visual-results").replaceChildren();
    for (const r of results()) {
      const card = node("article", "visual-result-card"),
        photo = node("a", "visual-result-image");
      photo.href = r.url;
      photo.target = "_blank";
      photo.rel = "noopener noreferrer";
      if (r.thumbnail) {
        const image = node("img");
        image.src = r.thumbnail;
        image.alt = r.title;
        image.loading = "lazy";
        image.referrerPolicy = "no-referrer";
        photo.append(image);
      } else photo.append(node("span", "", "▧"));
      const checkLabel = node("label", "visual-result-check"),
        check = node("input");
      check.type = "checkbox";
      check.dataset.candidateId = r.id;
      check.checked = chosen.has(r.id);
      check.setAttribute("aria-label", `收录候选：${r.title}`);
      check.addEventListener("change", () => {
        check.checked ? chosen.add(r.id) : chosen.delete(r.id);
        counts();
      });
      checkLabel.append(check, node("span", "", names[r.platform]));
      const info = node("div", "visual-result-info");
      info.append(
        node("strong", "", r.title),
        node(
          "small",
          "",
          r.method === "local-page"
            ? `画面相近度 ${r.similarity} / 100 · 本页图片匹配`
            : `命中 ${r.frameIds.length} 个参考画面 · 平台原生搜图候选`,
        ),
        node(
          "p",
          "",
          r.platform === "web"
            ? "来源网页，账号需访问后补全"
            : "发布账号将在打开原作品后识别",
        ),
      );
      const actions = node("div", "visual-result-actions"),
        link = node("a", "text-button", "打开原页面 ↗");
      link.href = r.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      actions.append(
        link,
        button(
          "收录并挑图",
          async () => {
            const out = await send("VISUAL_IMPORT", {
              visualId: session.id,
              ids: [r.id],
              category: $("visual-import-category").value,
            });
            if (!out.workIds?.length)
              return toast("标题超过 200 个字符，已跳过");
            await send("PARSE", { ids: out.workIds, mediaKinds: ["image"] });
            openDetail(out.workIds[0]);
            toast("已收录，正在解析作品图集；加载后可挑图下载。");
          },
          "button",
        ),
      );
      info.append(actions);
      card.append(photo, checkLabel, info);
      $("visual-results").append(card);
    }
    $("visual-results-empty").hidden = results().length > 0;
    $("visual-results-empty").textContent = session
      ? session.localMode
        ? "本页没有达到相近度下限的图片。可以降低下限，或滚动平台页加载更多图片后再次匹配。"
        : "当前没有可确认的原生搜图候选，请查看上方平台状态。"
      : "搜索结果将按平台归类显示。勾选候选可批量收录，也可逐条收录后挑图。";
  }
  installReferencePaste({
    target: document,
    isEnabled: () =>
      getView() === "visual" && !document.querySelector("dialog[open]"),
    onImage: (file) => void loadFile(file, "paste"),
  });
  $("visual-upload").addEventListener("click", () => $("visual-file").click());
  $("visual-file").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) void loadFile(file);
    e.target.value = "";
  });
  const zone = $("visual-drop");
  zone.addEventListener("dragover", (e) => {
    e.preventDefault();
    zone.classList.add("dragging");
  });
  zone.addEventListener("dragleave", () => zone.classList.remove("dragging"));
  zone.addEventListener("drop", (e) => {
    e.preventDefault();
    zone.classList.remove("dragging");
    if (e.dataTransfer.files[0]) void loadFile(e.dataTransfer.files[0]);
  });
  $("visual-reference-clear").addEventListener("click", () =>
    run(async () => {
      controller?.abort();
      searchController?.abort();
      await send("VISUAL_CLEAR");
      reference = null;
      frameIds.clear();
      chosen.clear();
      loading = false;
      $("visual-upload-status").textContent = "";
      renderReference();
    }),
  );
  $("visual-start").addEventListener("click", async () => {
    if (starting || !reference || !frameIds.size) return;
    const platforms = [...platformSelection];
    if (!platforms.length) {
      $("visual-error").textContent = "请至少选择一个平台";
      return;
    }
    $("visual-error").textContent = "";
    starting = true;
    $("visual-start").disabled = true;
    try {
      const source = currentSource();
      if (!source) throw new Error("请先选择当前打开的平台网页");
      const abort = new AbortController();
      searchController = abort;
      if ($("visual-search-method").value === "native") {
        await send("VISUAL_START", {
          reference,
          frameIds: [...frameIds],
          platforms,
          mode: "single",
          sourceTabId: source.id,
          engine: "native",
        });
      } else {
        const result = await send("VISUAL_LOCAL_START", {
          reference,
          frameIds: [...frameIds],
          sourceTabId: source.id,
          engine: "local",
        });
        const matches = await rankPagePictures(
          result.snapshot,
          reference.frames.filter((f) => frameIds.has(f.id)),
          Number($("visual-threshold").value) || 65,
          abort.signal,
        );
        if (abort.signal.aborted) return;
        await send("VISUAL_LOCAL_FINISH", {
          visualId: result.visualId,
          matches,
        });
      }
      chosen.clear();
      signature = "";
      render();
    } catch (e) {
      if (v()?.localMode && v()?.state === "running")
        await send("VISUAL_CANCEL").catch(() => {});
      $("visual-error").textContent =
        e.name === "AbortError" ? "检索已停止" : e.message;
    } finally {
      starting = false;
      render();
    }
  });

  $("visual-continue").addEventListener("click", () =>
    run(() => send("VISUAL_CONTINUE"), $("visual-continue")),
  );
  $("visual-cancel").addEventListener("click", () =>
    run(() => {
      searchController?.abort();
      return send("VISUAL_CANCEL");
    }, $("visual-cancel")),
  );
  $("visual-select-all").addEventListener("change", () => {
    for (const r of results())
      $("visual-select-all").checked ? chosen.add(r.id) : chosen.delete(r.id);
    for (const check of $("visual-results").querySelectorAll("input")) {
      check.checked = chosen.has(check.dataset.candidateId);
    }
    counts();
  });
  $("visual-result-platform").addEventListener("change", () => {
    signature = "";
    render();
  });
  $("visual-results-import").addEventListener("click", () =>
    run(async () => {
      const r = await send("VISUAL_IMPORT", {
        visualId: v().id,
        ids: [...chosen],
        category: $("visual-import-category").value,
      });
      toast(`已收录 ${r.added} 条，更新 ${r.merged} 条。可到素材库继续整理。`);
    }, $("visual-results-import")),
  );
  $("visual-open-platform").addEventListener("click", () =>
    run(async () => {
      const source = currentSource();
      if (!source) throw new Error("请先选择已打开的平台网页");
      await chrome.tabs.update(source.id, { active: true });
    }),
  );
  $("visual-clear-session").addEventListener("click", () =>
    run(async () => {
      searchController?.abort();
      await send("VISUAL_CLEAR");
      reference = null;
      frameIds.clear();
      chosen.clear();
      signature = "";
      renderReference();
      render();
      toast("已清空本机参考副本与此次候选，素材库已收录内容保留。");
    }),
  );
  void chrome.storage.local.get("visualReferenceV4").then((data) => {
    if (!reference && data.visualReferenceV4) {
      reference = data.visualReferenceV4;
      frameIds = new Set(reference.frames.map((x) => x.id));
      renderReference();
    }
  });
  renderReference();
  void run(refreshSourceTabs);
  return { render, refreshTabs: refreshSourceTabs };
}
