// Isolated content script. Only requests capture for this tab; never reads the clipboard.
(() => {
  window.__linkNoteAutoV3?.stop?.();
  let stopped = false,
    last = "",
    lastTitle = "",
    generation = 0,
    timers = [],
    busy = false,
    shown = "",
    queued = false,
    noticeTimer;
  const runtime = () => {
    try {
      return !!chrome.runtime.id;
    } catch {
      return false;
    }
  };
  function candidate() {
    const u = new URL(location.href),
      h = u.hostname,
      host = (d) => h === d || h.endsWith("." + d);
    if (host("xiaohongshu.com"))
      return /\/(explore|discovery\/item|search_result)\/[\w-]+/.test(
        u.pathname,
      );
    if (host("instagram.com"))
      return /^\/(?:[\w.]+\/)?(?:p|reels?|tv)\/[\w-]+(?:\/|$)/.test(u.pathname);
    if (host("douyin.com"))
      return (
        /\/(video|note)\/\d+/.test(u.pathname) || u.searchParams.has("modal_id")
      );
    if (/(^|\.)pinterest\./.test(h))
      return /\/pin\/(?:[^/]*--)?\d+/.test(u.pathname);
    if (host("taobao.com") || host("tmall.com"))
      return /item\.htm/.test(u.pathname) && u.searchParams.has("id");
    if (host("yangkeduo.com") || host("pinduoduo.com"))
      return (
        /\/goods[\w-]*\.html/.test(u.pathname) &&
        /^\d+$/.test(u.searchParams.get("goods_id") || "")
      );
    if (host("vip.com"))
      return (
        /\/(?:detail|product)-(?:\d+-)?\d+\.html/.test(u.pathname) ||
        (/\/(?:product|detail)\.html/.test(u.pathname) &&
          /^\d+$/.test(
            u.searchParams.get("product_id") ||
              u.searchParams.get("goods_id") ||
              "",
          ))
      );
    if (host("pin.it") || host("xhslink.com") || host("tb.cn")) return false;
    return (
      !!document.querySelector(
        'article,main video,meta[property="og:type"][content="article"]',
      ) || /\/(post|article|note|video|pin|item)\//.test(u.pathname)
    );
  }
  function toast(result) {
    if (!result.notice || shown === result.workId || !document.body) return;
    shown = result.workId;
    document.getElementById("link-note-auto-notice")?.remove();
    const host = document.createElement("div");
    host.id = "link-note-auto-notice";
    host.style.cssText =
      "position:fixed;right:20px;bottom:24px;z-index:2147483646";
    const shadow = host.attachShadow({ mode: "closed" }),
      box = document.createElement("div");
    box.style.cssText =
      "font:12px/1.7 system-ui,sans-serif;background:#fffefa;color:#294047;border:1px solid #d8e0d4;border-radius:12px;padding:13px 16px;box-shadow:0 8px 36px #18332b22;max-width:300px";
    const title = document.createElement("strong");
    title.textContent = "✓ 已自动收录到抓到你啦";
    const line = document.createElement("div");
    line.textContent = (result.title || "未命名作品").slice(0, 48);
    const author = document.createElement("div");
    author.textContent = result.user
      ? "发布账号：" + result.user
      : "账号名字待页面加载后补全";
    author.style.color = "#819084";
    const open = document.createElement("button");
    open.textContent = "查看素材库 ↗";
    open.style.cssText =
      "border:0;background:#eaf0e7;padding:5px 9px;margin-top:8px;border-radius:5px;color:#294047;cursor:pointer";
    open.onclick = () => {
      if (runtime())
        void chrome.runtime.sendMessage({ type: "AUTO_OPEN" }).catch(() => {});
    };
    const close = document.createElement("button");
    close.textContent = "×";
    close.setAttribute("aria-label", "关闭自动收录提示");
    close.style.cssText =
      "border:0;background:transparent;float:right;font-size:18px;cursor:pointer;color:#859189";
    close.onclick = () => host.remove();
    box.append(close, title, line, author, open);
    shadow.append(box);
    document.body.append(host);
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => host.remove(), 4500);
  }
  async function capture(gen) {
    if (
      stopped ||
      gen !== generation ||
      document.visibilityState === "hidden" ||
      !candidate()
    )
      return;
    if (!runtime()) {
      stop();
      return;
    }
    if (busy) {
      queued = true;
      return;
    }
    busy = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: "AUTO_CAPTURE" });
      if (result?.ok && result.captured) toast(result);
    } catch {
      if (!runtime()) stop();
    } finally {
      busy = false;
      if (queued) {
        queued = false;
        setTimeout(() => capture(generation), 500);
      }
    }
  }
  function inspect(force = false) {
    if (stopped) return;
    if (!runtime()) {
      stop();
      return;
    }
    if (document.visibilityState === "hidden") return;
    const key = location.href,
      title =
        document.title +
        "|" +
        (
          document.querySelector('h1,#detail-title,[data-e2e="video-desc"]')
            ?.textContent || ""
        ).slice(0, 160);
    if (!force && key === last && title === lastTitle) return;
    last = key;
    lastTitle = title;
    generation++;
    for (const t of timers) clearTimeout(t);
    const gen = generation;
    timers = [700, 2300, 6000].map((ms) => setTimeout(() => capture(gen), ms));
  }
  function stop() {
    stopped = true;
    clearInterval(interval);
    observer.disconnect();
    for (const t of timers) clearTimeout(t);
    document.removeEventListener("click", onClick, true);
    document.removeEventListener("visibilitychange", onVisible);
    window.removeEventListener("popstate", onPop);
    window.removeEventListener("hashchange", onPop);
    chrome.storage?.onChanged?.removeListener?.(onSettings);
  }
  const onSettings = (changes, area) => {
    if (
      area === "local" &&
      changes.catalogV2?.newValue?.settings?.autoCapture === true &&
      changes.catalogV2?.oldValue?.settings?.autoCapture === false
    )
      inspect(true);
  };
  const onVisible = () => {
      if (document.visibilityState !== "hidden") inspect(true);
    },
    onPop = () => inspect(true),
    onClick = (e) => {
      const a = e.target?.closest?.("a[href]");
      if (a) for (const ms of [250, 1200]) setTimeout(() => inspect(), ms);
    };
  const observer = new MutationObserver(() => {
    if (location.href !== last) inspect();
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
  });
  const interval = setInterval(() => inspect(), 1500);
  document.addEventListener("visibilitychange", onVisible);
  document.addEventListener("click", onClick, true);
  window.addEventListener("popstate", onPop);
  window.addEventListener("hashchange", onPop);
  chrome.storage?.onChanged?.addListener(onSettings);
  window.__linkNoteAutoV3 = { stop };
  inspect(true);
})();
