import { uid } from "./core.js";
import { frameTimes } from "./visual-core.js";
function eventOnce(el, name, signal, ms = 18000) {
  return new Promise((resolve, reject) => {
    const done = (error) => {
        clearTimeout(timer);
        el.removeEventListener(name, onload);
        el.removeEventListener("error", onerror);
        signal?.removeEventListener("abort", onabort);
        error ? reject(error) : resolve();
      },
      onload = () => done(),
      onerror = () =>
        done(new Error("浏览器无法解码此文件，请使用 JPG／PNG 或 MP4／WebM")),
      onabort = () => done(new DOMException("已取消", "AbortError")),
      timer = setTimeout(
        () => done(new Error("素材读取超时，请换一个文件")),
        ms,
      );
    el.addEventListener(name, onload, { once: true });
    el.addEventListener("error", onerror, { once: true });
    signal?.addEventListener("abort", onabort, { once: true });
    if (signal?.aborted) onabort();
  });
}
function check(signal) {
  if (signal?.aborted) throw new DOMException("已取消", "AbortError");
}
function snapshot(source, width, height, time = 0) {
  const scale = Math.min(1, 1024 / Math.max(width, height)),
    canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  let dataUrl = canvas.toDataURL("image/jpeg", 0.86);
  if (dataUrl.length > 1300000) dataUrl = canvas.toDataURL("image/jpeg", 0.65);
  return {
    id: uid(),
    dataUrl,
    width: canvas.width,
    height: canvas.height,
    time,
  };
}
export async function readReferenceFile(
  file,
  { signal, onProgress = () => {} } = {},
) {
  if (!file || !file.size) throw new Error("请选择有效的图片或视频");
  const video =
      file.type.startsWith("video/") ||
      /\.(mp4|webm|mov|m4v)$/i.test(file.name),
    image =
      /^image\/(jpeg|png|webp|gif|avif|bmp)$/.test(file.type) ||
      /\.(jpe?g|png|webp|gif|avif|bmp)$/i.test(file.name);
  if (!video && !image)
    throw new Error(
      "请使用 JPG、PNG、WebP 等图片，或 MP4、WebM 等浏览器可播放视频",
    );
  if (file.size > (video ? 500 : 25) * 1024 * 1024)
    throw new Error(video ? "视频请小于 500MB" : "图片请小于 25MB");
  const url = URL.createObjectURL(file),
    frames = [];
  let el;
  try {
    check(signal);
    if (video) {
      el = document.createElement("video");
      el.muted = true;
      el.preload = "auto";
      const loaded = eventOnce(el, "loadedmetadata", signal);
      el.src = url;
      await loaded;
      if (!el.videoWidth || !el.videoHeight)
        throw new Error("没有可读取的视频画面");
      const times = frameTimes(el.duration);
      for (const [i, time] of times.entries()) {
        check(signal);
        onProgress(`正在抽取参考画面 ${i + 1} / ${times.length}`);
        if (Math.abs(el.currentTime - time) > 0.001 || el.readyState < 2) {
          const ready = eventOnce(el, "seeked", signal);
          el.currentTime = time;
          await ready;
        }
        check(signal);
        frames.push(snapshot(el, el.videoWidth, el.videoHeight, time));
      }
    } else {
      el = new Image();
      const loaded = eventOnce(el, "load", signal);
      el.src = url;
      await loaded;
      check(signal);
      if (el.naturalWidth * el.naturalHeight > 64000000)
        throw new Error("图片尺寸过大，请缩小到 6400 万像素以内");
      frames.push(snapshot(el, el.naturalWidth, el.naturalHeight));
    }
    return {
      id: uid(),
      name: file.name,
      type: video ? "video" : "image",
      frames,
    };
  } finally {
    if (video && el) {
      el.pause();
      el.removeAttribute("src");
      el.load();
    }
    URL.revokeObjectURL(url);
  }
}
