import { collectPage } from "./collector.js";
import { platformOf, workKey, uid, titleTooLong } from "./core.js";
import {
  NATIVE_SEARCH,
  nativeHost,
  validateReference,
  mergeVisualCandidates,
} from "./visual-core.js";
import { latestState, transact } from "./database.js";

const snapshots = new Map();
let capturing = false;

// Injected function: only visible post images with a verifiable same-platform post URL.
export async function visiblePostPictures({ platform, works = [] }) {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error("请保持目标平台页面可见后重试")),
      1800,
    );
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        clearTimeout(timer);
        resolve();
      }),
    );
  });
  const detail = (raw) => {
    try {
      const u = new URL(raw, location.href),
        path = u.pathname;
      if (u.origin !== location.origin) return false;
      return (
        {
          instagram: /^\/(?:[\w.]+\/)?(?:p|reels?|tv)\/[\w-]+(?:\/|$)/.test(
            path,
          ),
          xhs: /\/(?:explore|discovery\/item|search_result)\/[\w-]+/.test(path),
          pinterest: /\/pin\/(?:[^/]*--)?\d+/.test(path),
          douyin:
            /\/(?:video|note)\/\d+/.test(path) ||
            !!u.searchParams.get("modal_id"),
          taobao: /item\.htm/.test(path) && !!u.searchParams.get("id"),
          tmall: /item\.htm/.test(path) && !!u.searchParams.get("id"),
          pdd:
            /\/goods[\w-]*\.html/.test(path) &&
            /^\d+$/.test(u.searchParams.get("goods_id") || ""),
          vip: /\/(?:detail|product)-(?:\d+-)?\d+\.html/.test(path),
        }[platform] || false
      );
    } catch {
      return false;
    }
  };
  const viewport = {
    width: innerWidth,
    height: innerHeight,
    x: scrollX,
    y: scrollY,
  };
  const candidates = [];
  for (const img of document.querySelectorAll("img")) {
    if (
      !img.complete ||
      !img.naturalWidth ||
      img.closest("header,nav,[role=navigation]")
    )
      continue;
    const box = img.getBoundingClientRect();
    const style = getComputedStyle(img);
    if (
      style.visibility !== "visible" ||
      style.display === "none" ||
      Number(style.opacity) === 0 ||
      Math.min(box.width, box.height) < 72
    )
      continue;
    // Full images only: partial viewport crops would produce misleading scores.
    if (
      box.x < 0 ||
      box.y < 0 ||
      box.right > innerWidth ||
      box.bottom > innerHeight
    )
      continue;
    const hit = document.elementFromPoint(
      box.x + box.width / 2,
      box.y + box.height / 2,
    );
    if (
      !hit ||
      (hit !== img && !img.contains(hit) && !img.parentElement?.contains(hit))
    )
      continue;
    const anchor = img.closest("a[href]");
    const url =
      anchor && detail(anchor.href)
        ? anchor.href
        : detail(location.href) && img.closest("article,[role=dialog]")
          ? location.href
          : "";
    if (!url) continue;
    const known = works.find((w) => w.url.split("?")[0] === url.split("?")[0]);
    const title =
      known?.title ||
      anchor?.getAttribute("aria-label") ||
      img.alt ||
      "未命名帖子";
    candidates.push({
      id: "picture-" + candidates.length,
      url,
      title,
      user: known?.user || "",
      imageUrl: img.currentSrc || img.src,
      rect: { x: box.x, y: box.y, width: box.width, height: box.height },
    });
    if (candidates.length >= 40) break;
  }
  return { url: location.href, viewport, candidates };
}
export async function openPlatformTab(tabId) {
  if (!Number.isInteger(tabId)) throw new Error("请选择当前已打开的平台页面");
  const tab = await chrome.tabs.get(tabId);
  const platform = platformOf(tab.url);
  if (!NATIVE_SEARCH[platform] || !nativeHost(tab.url, platform))
    throw new Error("请选择已打开的 IG、小红书等支持平台网页");
  if (
    !(await chrome.permissions.contains({
      origins: [new URL(tab.url).origin + "/*"],
    }))
  )
    throw new Error("请先授权当前平台网页");
  return { tab, platform };
}
async function sessionActive(id) {
  const v = (await latestState()).visualSearch;
  if (v?.id !== id || v.state === "cancelled") throw new Error("检索已停止");
}
async function snapshotPage(tab, platform, id) {
  const [beforeTab] = await chrome.tabs.query({
    active: true,
    windowId: tab.windowId,
  });
  let activated = false;
  try {
    await sessionActive(id);
    if (beforeTab?.id !== tab.id) {
      await chrome.tabs.update(tab.id, { active: true });
      activated = true;
    }
    const current = await chrome.tabs.get(tab.id);
    if (current.url !== tab.url || !nativeHost(current.url, platform))
      throw new Error("平台页面已变化，请刷新网页列表后重试");
    const [page] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: collectPage,
      args: [{ mode: "auto", rounds: 0, identityOnly: true, settle: false }],
    });
    const read = async () => {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: visiblePostPictures,
        args: [{ platform, works: page?.result?.works || [] }],
      });
      return r?.result;
    };
    const before = await read();
    if (!before?.candidates?.length)
      throw new Error(
        "当前可视区域没有可比较的帖子图片。请打开帖子或图片列表，关闭遮挡弹窗，让图片完整显示后重试",
      );
    await sessionActive(id);
    const [active] = await chrome.tabs.query({
      active: true,
      windowId: tab.windowId,
    });
    if (active?.id !== tab.id || active.url !== tab.url)
      throw new Error("当前页面已切换，已停止读取");
    let screenshot;
    try {
      screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: "png",
      });
    } catch {
      throw new Error(
        "无法读取当前画面。请回到目标平台，点击浏览器工具栏里的「抓到你啦」，再打开以图找相似",
      );
    }
    const after = await read();
    const [end] = await chrome.tabs.query({
      active: true,
      windowId: tab.windowId,
    });
    if (
      end?.id !== tab.id ||
      end.url !== tab.url ||
      JSON.stringify(before) !== JSON.stringify(after)
    )
      throw new Error("读取时页面发生滚动或内容变化，请保持画面不动后重试");
    await sessionActive(id);
    const skipped = before.candidates.filter((c) =>
      titleTooLong(c.title),
    ).length;
    return {
      ...before,
      screenshot,
      candidates: before.candidates.filter((c) => !titleTooLong(c.title)),
      skipped,
    };
  } finally {
    if (activated && beforeTab?.id) {
      const [active] = await chrome.tabs.query({
        active: true,
        windowId: tab.windowId,
      });
      if (active?.id === tab.id)
        await chrome.tabs
          .update(beforeTab.id, { active: true })
          .catch(() => {});
    }
  }
}
export async function handleLocalVisualMessage(m) {
  if (m.type === "VISUAL_LOCAL_START") {
    if (capturing || (await latestState()).visualSearch?.state === "running")
      throw new Error("已有检索正在运行，请先停止");
    if (m.engine && m.engine !== "local")
      throw new Error("本地匹配不使用站外搜图引擎");
    const { tab, platform } = await openPlatformTab(m.sourceTabId);
    const reference = validateReference(m.reference, m.frameIds);
    const id = uid();
    capturing = true;
    try {
      await chrome.storage.local.set({ visualReferenceV4: reference });
      await transact((s) => {
        s.visualSearch = {
          id,
          referenceId: reference.id,
          name: reference.name,
          type: reference.type,
          platforms: [platform],
          scopeVersion: 3,
          localMode: true,
          sourceTabId: tab.id,
          sourceUrl: tab.url,
          state: "running",
          createdAt: Date.now(),
          results: [],
          tasks: [
            {
              id: uid(),
              kind: "local",
              tabId: tab.id,
              platform,
              state: "processing",
              count: 0,
              error: "正在读取当前可见帖子图片",
            },
          ],
        };
      });
      const snapshot = await snapshotPage(tab, platform, id);
      snapshots.clear();
      snapshots.set(id, {
        candidates: snapshot.candidates,
        platform,
        at: Date.now(),
        frameIds: reference.frames.map((f) => f.id),
      });
      return { state: await latestState(), visualId: id, snapshot };
    } catch (e) {
      await transact((s) => {
        if (s.visualSearch?.id !== id || s.visualSearch.state === "cancelled")
          return;
        s.visualSearch.state = "attention";
        s.visualSearch.tasks[0].state = "unsupported";
        s.visualSearch.tasks[0].error = e.message;
      });
      throw e;
    } finally {
      capturing = false;
    }
  }
  if (m.type !== "VISUAL_LOCAL_FINISH") throw new Error("本地匹配操作无效");
  const saved = snapshots.get(m.visualId);
  if (!saved || Date.now() - saved.at > 300000)
    throw new Error("本次画面已过期，请重新匹配");
  await sessionActive(m.visualId);
  if (!Array.isArray(m.matches) || m.matches.length > 40)
    throw new Error("比较结果无效");
  const incoming = [];
  for (const match of m.matches) {
    const candidate = saved.candidates.find((c) => c.id === match.id);
    if (
      !candidate ||
      !Number.isFinite(match.score) ||
      match.score < 0 ||
      match.score > 100
    )
      continue;
    const frameIds = saved.frameIds.filter((f) => match.frameIds?.includes(f));
    if (!frameIds.length) continue;
    incoming.push({
      ...candidate,
      thumbnail: match.thumbnail,
      score: Math.round(match.score),
      frameIds,
    });
  }
  incoming.sort((a, b) => b.score - a.score);
  const result = await transact((s) => {
    const v = s.visualSearch;
    if (v?.id !== m.visualId || v.state === "cancelled")
      throw new Error("检索已停止");
    const unique = [];
    for (const x of incoming)
      if (!unique.some((p) => workKey(p.url) === workKey(x.url)))
        unique.push(x);
    v.results = mergeVisualCandidates([], unique, saved.frameIds[0], [
      saved.platform,
    ]).map((r) => {
      const source = unique.find((x) => workKey(x.url) === r.key);
      return {
        ...r,
        method: "local-page",
        similarity: source.score,
        frameIds: source.frameIds,
      };
    });
    v.state = "completed";
    v.tasks[0].state = "completed";
    v.tasks[0].count = v.results.length;
    v.tasks[0].error = `只比较了当前可视区域 ${saved.candidates.length} 张图片；未搜索全站`;
  });
  snapshots.delete(m.visualId);
  return result;
}
