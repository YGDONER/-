// Download rules shared by import, queue launch, redirects, and browser results.
// No network requests or file execution happen in this module.
const activeFile =
  /\.(?:exe|com|scr|msi|msix|msixbundle|appx|appxbundle|dll|sys|cpl|bat|cmd|ps1|psm1|vbs|vbe|wsf|wsh|js|jse|mjs|cjs|hta|html?|xhtml|svgz?|lnk|url|reg|jar|sh|py|php|asp|aspx)(?:[.;\s]|$)/i;
const streamFile = /\.(?:m3u8|mpd|m4s)(?:[.;\s]|$)/i;
const scanning = new Set(["asyncScanning", "asyncLocalPasswordScanning"]);
const safeDanger = new Set(["safe", "deepScannedSafe"]);

export function mediaUrlProblem(raw, kind = "image") {
  if (!["image", "cover", "video"].includes(kind))
    return "仅下载图片或视频，不接收压缩包及其他文件。";
  let url;
  try {
    url = new URL(raw);
  } catch {
    return "资源地址无效。";
  }
  if (
    !["https:", "http:"].includes(url.protocol) ||
    url.username ||
    url.password
  )
    return "仅接收不含账号密码的 HTTP／HTTPS 媒体地址。";
  let path = url.pathname;
  for (let i = 0; i < 3; i++) {
    try {
      const decoded = decodeURIComponent(path);
      if (decoded === path) break;
      path = decoded;
    } catch {
      return "媒体地址编码异常，请重新解析。";
    }
  }
  if (activeFile.test(path))
    return "资源指向脚本、程序或网页文档，已停止下载。";
  if (streamFile.test(path)) return "分段流媒体，当前版本不合并。";
  return "";
}

export function responseProblem(mime, kind = "image") {
  const type = String(mime || "")
    .split(";", 1)[0]
    .trim()
    .toLowerCase();
  // Some CDNs provide no media MIME type. Browser safety checks still apply.
  if (
    !type ||
    ["application/octet-stream", "binary/octet-stream"].includes(type)
  )
    return "";
  if (kind === "video" && type.startsWith("video/")) return "";
  if (
    ["image", "cover"].includes(kind) &&
    type.startsWith("image/") &&
    type !== "image/svg+xml"
  )
    return "";
  return "服务器返回的不是所选图片或视频，请刷新作品后重新解析。";
}

export function assessDownload(item, kind) {
  if (
    /^FILE_(?:VIRUS_INFECTED|BLOCKED|SECURITY_CHECK_FAILED)$/.test(
      item.error || "",
    )
  )
    return {
      level: "blocked",
      message:
        "浏览器或安全软件已拦截此文件（" + item.error + "）。请保留检测记录。",
    };
  if (scanning.has(item.danger) && item.state !== "interrupted")
    return {
      level: "checking",
      message: "浏览器正在检查文件安全性，请等待检查结果。",
    };
  if (item.danger && !safeDanger.has(item.danger) && !scanning.has(item.danger))
    return {
      level: "blocked",
      message: "浏览器报告下载风险（" + item.danger + "），已停止此任务。",
    };
  const urlProblem = mediaUrlProblem(item.finalUrl || item.url, kind);
  if (urlProblem) return { level: "blocked", message: urlProblem };
  if (
    /^(?:application\/(?:javascript|x-javascript|x-msdownload|x-dosexec|x-sh|vnd\.microsoft\.portable-executable)|text\/(?:javascript|vbscript)|image\/svg\+xml)(?:;|$)/i.test(
      item.mime || "",
    )
  )
    return {
      level: "blocked",
      message: "服务器返回脚本、程序或可执行矢量文档，已停止此任务。",
    };
  const problem = responseProblem(item.mime, kind);
  if (problem) return { level: "invalid", message: problem };
  return { level: "allowed", message: "" };
}
