// Small, local pixel comparison. Scores describe colour/layout, not semantic identity.
export function describePixels(rgba, width = 16, height = 16) {
  if (width !== 16 || height !== 16 || rgba.length !== width * height * 4)
    throw new Error("比较画面必须是 16 × 16 像素");
  const colours = [],
    histogram = Array(24).fill(0),
    gray = [];
  for (let i = 0; i < rgba.length; i += 4) {
    const alpha = rgba[i + 3] / 255;
    const rgb = [0, 1, 2].map(
      (c) => (rgba[i + c] * alpha + 255 * (1 - alpha)) / 255,
    );
    colours.push(...rgb);
    rgb.forEach((v, c) => histogram[c * 8 + Math.min(7, Math.floor(v * 8))]++);
    gray.push(rgb[0] * 0.299 + rgb[1] * 0.587 + rgb[2] * 0.114);
  }
  const hash = [];
  for (let y = 0; y < 16; y++)
    for (let x = 0; x < 15; x++)
      hash.push(gray[y * 16 + x] > gray[y * 16 + x + 1]);
  return { colours, histogram, hash };
}
export function comparePictures(a, b) {
  const colour =
    1 -
    a.colours.reduce((n, v, i) => n + Math.abs(v - b.colours[i]), 0) /
      a.colours.length;
  const histogram =
    a.histogram.reduce((n, v, i) => n + Math.min(v, b.histogram[i]), 0) /
    (16 * 16 * 3);
  const shape =
    a.hash.reduce((n, v, i) => n + Number(v === b.hash[i]), 0) / a.hash.length;
  return Math.round(
    Math.max(0, Math.min(1, colour * 0.55 + histogram * 0.3 + shape * 0.15)) *
      100,
  );
}
function loadPicture(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("本地参考画面读取失败，请重新上传"));
    img.src = url;
  });
}
function pixels(image, crop) {
  const c = document.createElement("canvas");
  c.width = c.height = 16;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, 16, 16);
  const r = crop || {
    x: 0,
    y: 0,
    width: image.naturalWidth,
    height: image.naturalHeight,
  };
  ctx.drawImage(image, r.x, r.y, r.width, r.height, 0, 0, 16, 16);
  return describePixels(ctx.getImageData(0, 0, 16, 16).data);
}
export async function rankPagePictures(
  snapshot,
  frames,
  threshold = 65,
  signal,
) {
  const image = await loadPicture(snapshot.screenshot);
  const refs = await Promise.all(
    frames.map(async (f) => ({
      id: f.id,
      descriptor: pixels(await loadPicture(f.dataUrl)),
    })),
  );
  const sx = image.naturalWidth / snapshot.viewport.width;
  const sy = image.naturalHeight / snapshot.viewport.height;
  const results = [];
  for (const candidate of snapshot.candidates) {
    if (signal?.aborted) throw new DOMException("检索已停止", "AbortError");
    const box = candidate.rect;
    const crop = {
      x: box.x * sx,
      y: box.y * sy,
      width: box.width * sx,
      height: box.height * sy,
    };
    const descriptor = pixels(image, crop);
    const matches = refs
      .map((r) => ({
        id: r.id,
        score: comparePictures(descriptor, r.descriptor),
      }))
      .filter((r) => r.score >= threshold);
    if (!matches.length) continue;
    const c = document.createElement("canvas");
    const scale = Math.min(1, 180 / Math.max(crop.width, crop.height));
    c.width = Math.max(1, Math.round(crop.width * scale));
    c.height = Math.max(1, Math.round(crop.height * scale));
    c.getContext("2d").drawImage(
      image,
      crop.x,
      crop.y,
      crop.width,
      crop.height,
      0,
      0,
      c.width,
      c.height,
    );
    results.push({
      id: candidate.id,
      score: Math.max(...matches.map((r) => r.score)),
      frameIds: matches.map((r) => r.id),
      thumbnail: c.toDataURL("image/jpeg", 0.8),
    });
  }
  return results.sort((a, b) => b.score - a.score);
}
