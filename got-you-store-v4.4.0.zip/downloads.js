import { transact, latestState, newJob } from "./database.js";
import { downloadCandidates, fileName } from "./core.js";
import { mediaUrlProblem, assessDownload } from "./media-policy.js";
let pumping = false,
  repump = false;
export async function enqueueWorks(
  ids,
  includeCovers,
  onlyKeys = null,
  onlyAssets = null,
  expectedEpoch = null,
) {
  const result = await transact((state) => {
    if (
      expectedEpoch !== null &&
      expectedEpoch !== (state.settings.downloadEpoch || 0)
    )
      return { queued: 0, skipped: 0, stopped: true };
    const works = state.works.filter((w) => ids.includes(w.id)),
      candidates = downloadCandidates(
        works,
        includeCovers ?? state.settings.includeCovers,
      ).filter(
        (x) =>
          (!onlyKeys || onlyKeys.includes(x.key)) &&
          (!onlyAssets ||
            onlyAssets.some(
              (a) =>
                a.workId === x.work.id &&
                a.kind === x.asset.kind &&
                a.url === x.asset.url,
            )),
      );
    if (onlyAssets && candidates.length !== onlyAssets.length)
      throw new Error("笔记图片已更新或所选图片不可用，请重新确认后下载");
    let queued = 0,
      skipped = 0;
    for (const x of candidates) {
      if (
        state.downloads.some(
          (j) =>
            (onlyAssets
              ? j.workId === x.work.id &&
                j.assetKind === x.asset.kind &&
                j.url === x.asset.url
              : j.assetKey === x.key) &&
            !["failed", "cancelled"].includes(j.state),
        )
      ) {
        skipped++;
        continue;
      }
      state.downloads.push(
        newJob({
          kind: "download",
          workId: x.work.id,
          assetKey: x.key,
          url: x.asset.url,
          filename: fileName(x.work, x.asset, x.index),
          platform: x.work.platform,
          title: x.work.title,
          assetKind: x.asset.kind,
          ...(onlyAssets ? { selectedUrl: x.asset.url } : {}),
          bytesReceived: 0,
          totalBytes: 0,
          downloadId: null,
        }),
      );
      queued++;
    }
    return { queued, skipped };
  });
  void pump();
  return result;
}
export async function updateDownload(id) {
  try {
    const [item] = await chrome.downloads.search({ id });
    if (!item) {
      await transact((s) => {
        const j = s.downloads.find((j) => j.downloadId === id);
        if (
          j &&
          !["completed", "failed", "cancelled", "blocked"].includes(j.state)
        ) {
          j.state = "failed";
          j.error = "浏览器下载记录已移除，请重试。";
        }
      });
      return;
    }
    let cancelUnsafe = false;
    await transact((state) => {
      const job = state.downloads.find((j) => j.downloadId === id);
      if (!job) return;
      job.bytesReceived = item.bytesReceived || 0;
      job.totalBytes = item.totalBytes > 0 ? item.totalBytes : 0;
      const safety = assessDownload(
        { ...item, url: item.url || job.url },
        job.assetKind,
      );
      if (job.safetyBlocked || safety.level === "blocked") {
        const firstBlock = !job.safetyBlocked;
        job.state = "blocked";
        job.safetyBlocked = true;
        job.error =
          job.error && safety.level !== "blocked" ? job.error : safety.message;
        cancelUnsafe = firstBlock && item.state === "in_progress";
        job.updatedAt = Date.now();
        return;
      }
      if (job.cancelRequested) {
        job.state = item.state === "complete" ? "completed" : "cancelled";
        job.error = item.state === "complete" ? "" : "已结束下载";
        cancelUnsafe = item.state === "in_progress";
        job.updatedAt = Date.now();
        return;
      }
      if (safety.level === "checking") {
        job.state = "checking";
        job.error = safety.message;
        job.updatedAt = Date.now();
        return;
      }
      if (safety.level === "invalid") {
        job.state = "failed";
        job.error = safety.message;
        cancelUnsafe = item.state === "in_progress";
        job.updatedAt = Date.now();
        return;
      }
      job.state =
        item.state === "complete"
          ? "completed"
          : item.state === "interrupted"
            ? item.error === "USER_CANCELED"
              ? "cancelled"
              : "failed"
            : item.paused
              ? "paused"
              : "in_progress";
      job.error = item.state === "interrupted" ? item.error || "下载中断" : "";
      job.updatedAt = Date.now();
    });
    if (cancelUnsafe) await chrome.downloads.cancel(id).catch(() => {});
  } catch {}
}
export async function reconcile() {
  const state = await latestState();
  for (const j of state.downloads.filter(
    (j) =>
      j.downloadId !== null &&
      ["in_progress", "starting", "paused", "checking"].includes(j.state),
  ))
    await updateDownload(j.downloadId);
  void pump();
}
export async function pump() {
  if (pumping) {
    repump = true;
    return;
  }
  pumping = true;
  try {
    do {
      repump = false;
      let launch = [];
      await transact((state) => {
        if (state.settings.paused) return;
        const limit = Math.max(
          1,
          Math.min(5, Number(state.settings.concurrency) || 2),
        );
        const active = state.downloads.filter(
          (j) =>
            ["starting", "in_progress", "checking"].includes(j.state) ||
            (j.state === "paused" && j.downloadId !== null),
        ).length;
        launch = state.downloads
          .filter((j) => j.state === "pending")
          .slice(0, Math.max(0, limit - active))
          .map((j) => {
            j.state = "starting";
            j.updatedAt = Date.now();
            return { ...j };
          });
      });
      for (const job of launch) {
        try {
          let mayStart = false;
          await transact((s) => {
            const j = s.downloads.find((x) => x.id === job.id);
            if (!j || j.state !== "starting" || j.cancelRequested) return;
            if (s.settings.paused || j.pauseRequested) {
              j.state = "paused";
              j.pauseRequested = true;
              return;
            }
            mayStart = true;
            j.launching = true;
          });
          if (!mayStart) continue;
          const problem = mediaUrlProblem(job.url, job.assetKind);
          if (problem) {
            await transact((s) => {
              const current = s.downloads.find((j) => j.id === job.id);
              if (current) {
                current.state = "blocked";
                current.safetyBlocked = true;
                current.error = problem;
              }
            });
            repump = true;
            continue;
          }
          const id = await chrome.downloads.download({
            url: job.url,
            filename: job.filename,
            saveAs: false,
            conflictAction: "uniquify",
          });
          let intent = "cancel";
          await transact((state) => {
            const j = state.downloads.find((x) => x.id === job.id);
            if (j) {
              j.launching = false;
              j.downloadId = id;
              intent = j.cancelRequested
                ? "cancel"
                : state.settings.paused || j.pauseRequested
                  ? "pause"
                  : "run";
              j.state =
                intent === "cancel"
                  ? "cancelled"
                  : intent === "pause"
                    ? "paused"
                    : "in_progress";
            }
          });
          if (intent === "cancel")
            await chrome.downloads.cancel(id).catch(() => {});
          if (intent === "pause")
            await chrome.downloads.pause(id).catch(() => {});
          await updateDownload(id);
        } catch (e) {
          await transact((state) => {
            const j = state.downloads.find((x) => x.id === job.id);
            if (j) {
              j.launching = false;
              if (j.cancelRequested) {
                j.state = "cancelled";
                return;
              }
              const message = e?.message || "下载启动失败";
              j.safetyBlocked =
                /FILE_(?:VIRUS_INFECTED|BLOCKED|SECURITY_CHECK_FAILED)|dangerous|malware|virus/i.test(
                  message,
                );
              j.state = j.safetyBlocked ? "blocked" : "failed";
              j.error = message;
            }
          });
          repump = true;
        }
      }
    } while (repump);
  } finally {
    pumping = false;
  }
}
export async function controlDownloads(action, ids = []) {
  if (
    !["pause", "resume", "cancel", "stop", "retry", "clearFinished"].includes(
      action,
    )
  )
    throw new Error("下载操作无效");
  if (!Array.isArray(ids)) throw new Error("下载任务选择无效");
  if (action === "stop" && ids.length)
    throw new Error("结束下载用于整个下载批次");
  const stopping = !ids.length && ["stop", "cancel"].includes(action);
  // Persist intent before browser calls: onChanged and late parse results must see it.
  await transact((s) => {
    if (!ids.length && ["pause", "resume"].includes(action))
      s.settings.paused = action === "pause";
    if (stopping) {
      s.settings.paused = true;
      s.settings.downloadEpoch = (s.settings.downloadEpoch || 0) + 1;
      for (const j of s.jobs) {
        if (
          j.kind === "parse" &&
          j.downloadAfter &&
          ["pending", "processing"].includes(j.state)
        ) {
          j.downloadAfter = false;
          j.state = "cancelled";
          j.error = "已结束本批下载及其解析任务";
        }
      }
    }
    for (const j of s.downloads.filter(
      (j) => !ids.length || ids.includes(j.id),
    )) {
      if (
        j.safetyBlocked ||
        ["completed", "failed", "blocked", "cancelled"].includes(j.state)
      )
        continue;
      if (action === "pause") {
        j.pauseRequested = true;
        if (j.downloadId === null && !j.launching) j.state = "paused";
      }
      if (action === "resume") {
        j.pauseRequested = false;
        if (j.downloadId === null && !j.launching) j.state = "pending";
      }
      if (stopping || action === "cancel") {
        j.cancelRequested = true;
        j.state = "cancelled";
        j.error = "已结束下载";
      }
    }
  });
  const state = await latestState(),
    items = state.downloads.filter((j) => !ids.length || ids.includes(j.id));
  for (const j of items) {
    if (j.downloadId === null || j.safetyBlocked) continue;
    try {
      if (
        action === "pause" &&
        ["in_progress", "starting", "checking", "paused"].includes(j.state)
      )
        await chrome.downloads.pause(j.downloadId);
      if (action === "resume" && j.state === "paused")
        await chrome.downloads.resume(j.downloadId);
      if ((action === "cancel" || action === "stop") && j.cancelRequested)
        await chrome.downloads.cancel(j.downloadId);
    } catch (e) {
      await transact((s) => {
        const x = s.downloads.find((x) => x.id === j.id);
        if (x) x.error = e.message || "浏览器未能执行该操作";
      });
    }
    if (["pause", "resume", "cancel", "stop"].includes(action))
      await updateDownload(j.downloadId);
  }
  const result = await transact((s) => {
    for (const j of s.downloads.filter(
      (j) => !ids.length || ids.includes(j.id),
    )) {
      if (j.safetyBlocked) continue;
      if (action === "cancel" && j.state === "pending") j.state = "cancelled";
      if (
        action === "retry" &&
        (j.state === "failed" || (ids.length && j.state === "cancelled"))
      ) {
        if (j.launching) {
          j.error = "正在结束启动中的文件，请稍后重试";
          continue;
        }
        const work = s.works.find((w) => w.id === j.workId),
          index = Number(j.assetKey.split(":").at(-1)),
          asset = j.selectedUrl
            ? work?.media.find(
                (a) => a.kind === j.assetKind && a.url === j.selectedUrl,
              )
            : work?.media[index];
        if (j.selectedUrl && !asset) {
          j.error = "所选图片已变化，请在笔记内重新勾选下载";
          continue;
        }
        const problem =
          asset?.blockedReason ||
          mediaUrlProblem(asset?.url || j.url, asset?.kind || j.assetKind);
        if (problem) {
          j.error = problem;
          continue;
        }
        if (asset) j.url = asset.url;
        j.state = "pending";
        j.cancelRequested = false;
        j.pauseRequested = false;
        j.error = "";
        j.downloadId = null;
        j.bytesReceived = 0;
        j.totalBytes = 0;
      }
    }
    if (action === "clearFinished")
      s.downloads = s.downloads.filter(
        (j) =>
          !["completed", "failed", "cancelled", "blocked"].includes(j.state),
      );
  });
  void pump();
  return result;
}
export function registerDownloadEvents() {
  chrome.downloads.onChanged.addListener((delta) => {
    void updateDownload(delta.id).then(pump);
  });
  chrome.downloads.onErased.addListener((id) => {
    void transact((s) => {
      const j = s.downloads.find(
        (j) =>
          j.downloadId === id &&
          !["completed", "failed", "cancelled", "blocked"].includes(j.state),
      );
      if (j) {
        j.state = "failed";
        j.error = "浏览器下载记录已移除";
      }
    });
  });
}
