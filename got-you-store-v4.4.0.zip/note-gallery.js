// Per-note selection is based on media URLs so automatic reordering cannot select another image.
export function setupNoteGallery({ getState, send, run, toast, node }) {
  const $ = (id) => document.getElementById(id);
  let workId = "",
    selected = new Set(),
    signature = "",
    previewIndex = 0,
    feedback = "";
  const work = () => getState().works.find((w) => w.id === workId);
  const images = () => work()?.media.filter((a) => a.kind === "image") || [];
  const available = () => images().filter((a) => !a.blockedReason);
  function counts() {
    const entries = available(),
      count = entries.filter((a) => selected.has(a.url)).length;
    $("note-images-count").textContent = `已选 ${count} / ${entries.length} 张`;
    $("note-images-all").checked =
      entries.length > 0 && count === entries.length;
    $("note-images-all").indeterminate = count > 0 && count < entries.length;
    $("note-images-all").disabled = !entries.length;
    $("note-images-invert").disabled = !entries.length;
    $("note-images-clear").disabled = !count;
    $("note-images-download").disabled = !count;
    $("note-images-download").textContent = `↓ 下载所选图片（${count}）`;
    $("note-download-hint").textContent = count
      ? `仅保存已勾选的 ${count} 张图片`
      : "勾选想要的图片";
  }
  function change(url, on) {
    feedback = "";
    on ? selected.add(url) : selected.delete(url);
    render();
    for (const label of $("note-images-grid").querySelectorAll(
      ".note-picture-check",
    )) {
      const check = label.querySelector("input");
      check.checked = selected.has(check.value);
      label.closest(".note-picture").classList.toggle("picked", check.checked);
    }
  }
  function preview() {
    const entries = images(),
      entry = entries[previewIndex];
    if (!entry) {
      $("note-image-preview").close();
      return;
    }
    const im = $("note-preview-image");
    if (im.getAttribute("src") !== entry.url) im.src = entry.url;
    im.alt = `${work()?.title || "笔记图片"} 第 ${previewIndex + 1} 张`;
    im.referrerPolicy = "no-referrer";
    $("note-preview-position").textContent =
      `${previewIndex + 1} / ${entries.length}`;
    $("note-preview-check").checked = selected.has(entry.url);
    $("note-preview-check").disabled = !!entry.blockedReason;
    $("note-preview-prev").disabled = previewIndex === 0;
    $("note-preview-next").disabled = previewIndex === entries.length - 1;
  }
  function openPreview(index) {
    previewIndex = index;
    preview();
    if (!$("note-image-preview").open) $("note-image-preview").showModal();
  }
  function render(force = false) {
    if (!$("detail").open && !force) return;
    const w = work(),
      entries = images(),
      valid = new Set(available().map((a) => a.url));
    selected = new Set([...selected].filter((url) => valid.has(url)));
    $("detail-note-subtitle").textContent = w
      ? `${w.title || "未命名笔记"}${w.user ? " · " + w.user : ""}`
      : "这条笔记已从素材库移除";
    $("note-image-total").textContent = entries.length + " 张";
    $("note-images-empty").hidden = !!entries.length;
    const jobs = getState().jobs.filter(
        (j) => j.kind === "parse" && j.workId === workId,
      ),
      active = jobs.some((j) => ["pending", "processing"].includes(j.state)),
      last = jobs.at(-1);
    $("note-image-status").textContent = active
      ? "正在解析图集，加载完成后可逐张勾选…"
      : !entries.length && last?.state === "attention"
        ? last.error || "未识别到图集，请打开原作品加载后重试。"
        : feedback
          ? feedback
          : entries.length
            ? "默认不勾选图片；点击缩略图可放大查看。"
            : "";
    counts();
    const next = JSON.stringify([workId, entries]);
    if (!force && next === signature) return;
    signature = next;
    $("note-images-grid").replaceChildren();
    entries.forEach((a, i) => {
      const card = node("article", "note-picture"),
        visual = node("button", "note-picture-visual"),
        im = node("img");
      visual.setAttribute("aria-label", `放大第 ${i + 1} 张图片`);
      im.src = a.url;
      im.alt = `第 ${i + 1} 张图片`;
      im.loading = "lazy";
      im.referrerPolicy = "no-referrer";
      im.addEventListener(
        "error",
        () => {
          im.alt = "预览加载失败，可打开原作品检查";
        },
        { once: true },
      );
      visual.append(im, node("span", "note-picture-zoom", "放大 ↗"));
      visual.addEventListener("click", () => openPreview(i));
      const checkLabel = node("label", "note-picture-check"),
        check = node("input");
      check.type = "checkbox";
      check.value = a.url;
      check.checked = selected.has(a.url);
      check.disabled = !!a.blockedReason;
      check.setAttribute("aria-label", `选择本篇第 ${i + 1} 张图片`);
      check.addEventListener("change", () => change(a.url, check.checked));
      checkLabel.append(check, node("span", "", `第 ${i + 1} 张`));
      const info = node("div", "note-picture-caption");
      info.append(
        checkLabel,
        node(
          "small",
          "",
          a.width && a.height ? `${a.width} × ${a.height}` : "原图资源",
        ),
      );
      card.append(visual, info);
      if (a.blockedReason)
        card.append(node("small", "danger", a.blockedReason));
      card.classList.toggle("picked", check.checked);
      $("note-images-grid").append(card);
    });
    if ($("note-image-preview").open) {
      previewIndex = Math.min(previewIndex, entries.length - 1);
      preview();
    }
  }
  $("note-images-all").addEventListener("change", () => {
    feedback = "";
    selected = $("note-images-all").checked
      ? new Set(available().map((a) => a.url))
      : new Set();
    render(true);
  });
  $("note-images-invert").addEventListener("click", () => {
    feedback = "";
    selected = new Set(
      available()
        .filter((a) => !selected.has(a.url))
        .map((a) => a.url),
    );
    render(true);
  });
  $("note-images-clear").addEventListener("click", () => {
    feedback = "";
    selected.clear();
    render(true);
  });
  $("note-images-download").addEventListener("click", async () => {
    await run(async () => {
      try {
        const urls = available()
          .filter((a) => selected.has(a.url))
          .map((a) => a.url);
        if (!urls.length) throw new Error("请先勾选需要下载的图片");
        const r = await send("DOWNLOAD_IMAGES", { workId, urls });
        feedback = `已加入 ${r.queued} 张所选图片${r.skipped ? `，${r.skipped} 张已在队列中` : ""}。可关闭此窗口，到下载队列查看进度。`;
        toast(feedback);
        render();
      } catch (e) {
        feedback = e.message || "下载未能开始，请重试";
        render();
        throw e;
      }
    }, $("note-images-download"));
    counts();
  });
  $("note-images-refresh").addEventListener("click", () =>
    run(async () => {
      feedback = "";
      const r = await send("PARSE", { ids: [workId], mediaKinds: ["image"] });
      toast(r.queued ? "已开始解析本篇图集" : "本篇图集正在解析中");
      render();
    }, $("note-images-refresh")),
  );
  $("note-preview-close").addEventListener("click", () =>
    $("note-image-preview").close(),
  );
  $("note-preview-prev").addEventListener("click", () => {
    previewIndex--;
    preview();
  });
  $("note-preview-next").addEventListener("click", () => {
    previewIndex++;
    preview();
  });
  $("note-preview-check").addEventListener("change", () => {
    const a = images()[previewIndex];
    if (a && !a.blockedReason) change(a.url, $("note-preview-check").checked);
  });
  return {
    open(id, { reset = true } = {}) {
      workId = id;
      if (reset) {
        selected.clear();
        feedback = "";
      }
      signature = "";
      render(true);
    },
    render,
  };
}
