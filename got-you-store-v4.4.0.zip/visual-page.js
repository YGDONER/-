// Serialized into a selected platform tab; keep both functions self-contained.
export async function submitReferenceImage({ platform, dataUrl }) {
  const host = () => {
    const h = location.hostname,
      match = (d) => h === d || h.endsWith("." + d),
      domains = {
        pinterest: [
          "pinterest.com",
          "pinterest.co.uk",
          "pinterest.fr",
          "pinterest.de",
          "pinterest.jp",
          "pinterest.ca",
          "pinterest.com.au",
          "pinterest.es",
          "pinterest.it",
        ],
        xhs: ["xiaohongshu.com"],
        instagram: ["instagram.com"],
        douyin: ["douyin.com"],
        taobao: ["taobao.com"],
        tmall: ["tmall.com"],
        pdd: ["yangkeduo.com", "pinduoduo.com"],
        vip: ["vip.com"],
      };
    return (
      location.protocol === "https:" &&
      !location.username &&
      !location.password &&
      (domains[platform] || []).some(match)
    );
  };
  if (!host()) throw new Error("页面已离开所选平台，停止传送参考图");
  if (platform === "instagram")
    return {
      submitted: false,
      unsupported: true,
      message: "尚未确认 ins 网页端的原生以图搜图入口；参考图保留在本机。",
    };
  const body = (document.body?.innerText || "").slice(0, 10000);
  if (
    /安全验证|人机验证|Verify you are human|Just a moment|unusual traffic/i.test(
      document.title + " " + body,
    )
  )
    return {
      submitted: false,
      message: "平台要求验证，请在该平台页面处理后继续。",
    };
  if (
    /^(登录|注册|Log in|Sign up)(?:\s*[-|｜]|$)/i.test(document.title) ||
    document.querySelector(
      'input[type="password"],input[autocomplete="one-time-code"]',
    )
  )
    return {
      submitted: false,
      message: "请先在平台页面完成登录，再回插件继续。",
    };
  if (
    typeof dataUrl !== "string" ||
    dataUrl.length > 1400000 ||
    !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(dataUrl)
  )
    throw new Error("参考画面无效");
  const scopes =
    '[role="search"],form[role="search"],header,[data-test-id*="search"],[class*="image-search"],[class*="ImageSearch"],[class*="search-by-image"],[class*="visual-search"]';
  const imageSearch =
    /以图搜|图片搜|搜图|拍照搜|搜同款|search by image|search with an image|visual[-_ ]search|image[-_ ]search|pinterest lens/i;
  const uploadContext =
    /上传.{0,8}(图片|照片).{0,12}(搜索|检索)|upload.{0,12}image.{0,12}search/i;
  const label = (el) =>
    [
      el.getAttribute("aria-label"),
      el.getAttribute("title"),
      el.getAttribute("data-test-id"),
      el.textContent,
    ]
      .filter(Boolean)
      .join(" ")
      .slice(0, 600);
  const safeInput = (el) => {
    if (
      el.disabled ||
      el.closest(
        '[contenteditable="true"],[data-test-id*="pin-builder"],[data-test-id*="create-pin"]',
      )
    )
      return false;
    const scope = el.closest(scopes);
    if (!scope) return false;
    const direct = label(el),
      accept = el.getAttribute("accept") || "";
    if (accept && !/image|\.(?:jpe?g|png|webp)/i.test(accept)) return false;
    if (scope.tagName === "HEADER" && !imageSearch.test(direct)) return false;
    const info = direct + " " + label(scope);
    return imageSearch.test(info) || uploadContext.test(info);
  };
  const find = () =>
    [...document.querySelectorAll('input[type="file"]')].find(safeInput);
  let input = find();
  if (!input) {
    const trigger = [
      ...document.querySelectorAll('button,[role="button"]'),
    ].find(
      (el) =>
        el.getClientRects().length &&
        el.closest(scopes) &&
        imageSearch.test(label(el)),
    );
    if (trigger) {
      trigger.click();
      await new Promise((r) => setTimeout(r, 600));
      if (!host()) throw new Error("页面已离开所选平台，停止传送参考图");
      input = find();
    }
  }
  if (!input)
    return {
      submitted: false,
      message:
        "未找到可确认的站内搜图上传框。请打开平台的相机／以图搜图入口后继续；若该网页没有此入口，本次无法原生搜图。",
    };
  if (!host() || !safeInput(input))
    throw new Error("搜图入口已变化，未传送参考图");
  const type = dataUrl.slice(5, dataUrl.indexOf(";")),
    binary = atob(dataUrl.split(",")[1]),
    bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  const file = new File(
      [bytes],
      "reference." + (type === "image/jpeg" ? "jpg" : type.split("/")[1]),
      { type },
    ),
    transfer = new DataTransfer();
  transfer.items.add(file);
  const beforeUrl = location.href;
  input.files = transfer.files;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  // The native site submits on change. Never click a generic submit/publish button.
  return { submitted: true, beforeUrl };
}

export function collectVisualPage({ platform } = {}) {
  const domains = {
    pinterest: [
      "pinterest.com",
      "pinterest.co.uk",
      "pinterest.fr",
      "pinterest.de",
      "pinterest.jp",
      "pinterest.ca",
      "pinterest.com.au",
      "pinterest.es",
      "pinterest.it",
    ],
    xhs: ["xiaohongshu.com"],
    instagram: ["instagram.com"],
    douyin: ["douyin.com"],
    taobao: ["taobao.com"],
    tmall: ["tmall.com"],
    pdd: ["yangkeduo.com", "pinduoduo.com"],
    vip: ["vip.com"],
  };
  const local = (raw) => {
    try {
      const u = new URL(raw, location.href);
      return (
        u.protocol === "https:" &&
        !u.username &&
        !u.password &&
        (domains[platform] || []).some(
          (d) => u.hostname === d || u.hostname.endsWith("." + d),
        )
      );
    } catch {
      return false;
    }
  };
  if (!local(location.href))
    return {
      blocked: true,
      candidates: [],
      message: "搜索页已离开所选平台，未读取候选。",
    };
  const body = (document.body?.innerText || "").slice(0, 12000);
  if (
    /安全验证|人机验证|Verify you are human|Just a moment|unusual traffic/i.test(
      document.title + " " + body,
    ) ||
    document.querySelector(
      'input[type="password"],input[autocomplete="one-time-code"]',
    )
  )
    return {
      blocked: true,
      candidates: [],
      message: "请在所选平台页面完成登录／验证后继续。",
    };
  const u = new URL(location.href),
    route = /visual[_/-]?search|image[_/-]?search|searchbyimage/i.test(
      u.pathname,
    );
  const param = [...u.searchParams].some(
    ([key, value]) =>
      value &&
      /^(image_signature|image_url|image_id|imageId|image_search_id|imageSearchId|img_id|imgId|search_by_image|lens|cropSource)$/i.test(
        key,
      ),
  );
  const context = document.querySelector(
    '[data-test-id="visual-search-results"],[data-test-id="image-search-results"],[data-testid="image-search-results"],[aria-label="以图搜图结果"],[aria-label="Image search results"]',
  );
  const imageContext = route || param || !!context;
  if (!imageContext)
    return {
      ready: document.readyState === "complete",
      imageContext: false,
      candidates: [],
      message:
        "尚未确认平台已进入图片搜索结果页；不会收集首页推荐或普通关键词结果。",
    };
  const candidates = [],
    seen = new Set();
  for (const a of document.querySelectorAll("a[href]")) {
    if (candidates.length >= 150) break;
    let url;
    try {
      url = new URL(a.href, location.href).href;
    } catch {
      continue;
    }
    if (!local(url) || seen.has(url)) continue;
    const card =
        a.closest(
          'article,section,[data-test-id="pin"],[class*="note-item"],[class*="card"],[class*="Card"],li',
        ) || a,
      image = card.querySelector("img");
    if (!image) continue;
    seen.add(url);
    const imageUrl = (() => {
      try {
        const raw = image.currentSrc || image.src || "";
        if (!raw.trim()) return "";
        const v = new URL(raw, location.href);
        return ["https:", "http:"].includes(v.protocol) ? v.href : "";
      } catch {
        return "";
      }
    })();
    candidates.push({
      url,
      title: (
        a.getAttribute("title") ||
        image.alt ||
        a.textContent ||
        "平台搜图候选"
      )
        .trim()
        .slice(0, 300),
      thumbnail: imageUrl,
      imageUrl,
    });
  }
  const empty = /没有找到|暂无结果|未找到相关|No results|Couldn't find/i.test(
    body,
  );
  return {
    ready: document.readyState === "complete",
    imageContext: true,
    candidates,
    empty,
  };
}
