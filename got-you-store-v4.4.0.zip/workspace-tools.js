import {
  PLATFORMS,
  downloadCandidates,
  httpUrl,
  buildDownloadPlan,
} from "./core.js";
export function setupTools(ctx) {
  const {
      getState,
      getView,
      targets,
      categories,
      setView,
      send,
      run,
      toast,
      node,
      button,
      options,
      refreshTabs,
    } = ctx,
    $ = (id) => document.getElementById(id);
  let imageIds = [],
    selectedImages = new Set(),
    knownImages = new Set(),
    deleteCategory = "",
    update = {};
  const names = Object.fromEntries(PLATFORMS.map((p) => [p.id, p.name]));
  const scopeText = () =>
    `当前操作范围：${targets().length} 条作品（来自素材库的勾选或筛选结果）`;
  function renderAuto() {
    const s = getState(),
      enabled = s.settings.autoCapture !== false;
    $("auto-enabled").checked = enabled;
    $("auto-notice").checked = s.settings.autoNotice !== false;
    $("auto-status").textContent = enabled
      ? "自动收录已开启"
      : "自动收录已暂停";
    $("auto-status").parentElement.classList.toggle("paused", !enabled);
    const last = s.works.find((w) => w.id === s.autoLast?.workId);
    $("auto-last").replaceChildren();
    if (!last) {
      $("auto-last").append(
        node(
          "span",
          "muted",
          "打开 Pinterest、小红书、抖音作品或淘宝天猫商品，识别结果会自动填写在这里。",
        ),
      );
      return;
    }
    const row = node("div", "auto-data");
    for (const [label, value] of [
      ["素材地址", last.url],
      ["标题", last.title || "标题待补全"],
      ["发布账号名字", last.user || "账号名字待补全"],
    ]) {
      const cell = node("div");
      cell.append(node("small", "", label), node("span", "", value));
      row.append(cell);
    }
    const foot = node("div", "auto-recent-meta");
    foot.append(
      node(
        "span",
        "",
        `${names[last.platform]} · ${new Date(s.autoLast.at).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })} 自动填写`,
      ),
    );
    const a = node("a", "text-button", "打开原作品 ↗");
    a.href = last.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    foot.append(a);
    $("auto-last").append(row, foot);
  }
  function renderCategories() {
    const s = getState(),
      list = $("category-list");
    if (!document.activeElement?.matches("#category-list input")) {
      list.replaceChildren();
      for (const name of categories()) {
        const row = node("div", "category-row"),
          dot = node("span", "category-color");
        dot.style.background = ["#c8d2b2", "#e2b9a7", "#c0cdd7", "#dfd3a9"][
          list.children.length % 4
        ];
        const input = node("input");
        input.value = name;
        input.maxLength = 32;
        input.setAttribute("aria-label", "分类名称：" + name);
        const count = node(
          "span",
          "category-count",
          s.works.filter((w) => w.category === name).length + " 条",
        );
        row.append(dot, input, count);
        if (name === "未分类") {
          input.disabled = true;
          row.append(node("span", "muted", "默认分类"));
        } else {
          row.append(
            button("改名", async () => {
              const newName = input.value,
                wasSelected = $("category-target").value === name;
              await send("CATEGORY", { action: "rename", name, newName });
              if (wasSelected) $("category-target").value = newName;
              toast("分类及作品归属已同步修改");
            }),
            button(
              "删除",
              () => {
                deleteCategory = name;
                $("category-confirm-text").textContent =
                  `“${name}”下的 ${s.works.filter((w) => w.category === name).length} 条作品会移入“未分类”。`;
                $("category-confirm").showModal();
              },
              "text-button danger",
            ),
          );
        }
        list.append(row);
      }
    }
    options($("category-target"), categories());
    $("category-scope").textContent = scopeText();
    $("category-assign").disabled = !targets().length;
  }
  function imageWorks() {
    const s = getState(),
      scope = $("image-scope").value;
    if (scope === "all") return s.works;
    if (scope === "recent")
      return s.works.filter((w) =>
        (imageIds.length ? imageIds : s.imageLast?.workIds || []).includes(
          w.id,
        ),
      );
    return targets();
  }
  function imageEntries() {
    const covers = $("image-covers").checked;
    return imageWorks().flatMap((w) =>
      w.media
        .map((a, i) => ({ w, a, index: i, key: w.id + ":" + a.kind + ":" + i }))
        .filter(
          (x) =>
            (x.a.kind === "image" || (covers && x.a.kind === "cover")) &&
            !x.a.blockedReason,
        ),
    );
  }
  function renderImages() {
    const entries = imageEntries();
    $("image-count").textContent = entries.length;
    $("image-empty").hidden = entries.length > 0;
    $("image-grid").replaceChildren();
    for (const x of entries) {
      if (!knownImages.has(x.key)) {
        knownImages.add(x.key);
        selectedImages.add(x.key);
      }
      const card = node("article", "image-card"),
        label = node("label", "image-check"),
        input = node("input");
      input.type = "checkbox";
      input.checked = selectedImages.has(x.key);
      input.setAttribute(
        "aria-label",
        "选择图片：" + (x.w.title || "未命名") + " 第" + (x.index + 1) + "张",
      );
      input.addEventListener("change", () => {
        input.checked
          ? selectedImages.add(x.key)
          : selectedImages.delete(x.key);
        renderImageCounts();
      });
      label.append(input);
      const im = node("img");
      im.src = x.a.url;
      im.alt = x.w.title || "素材图片";
      im.loading = "lazy";
      im.referrerPolicy = "no-referrer";
      im.addEventListener(
        "error",
        () => {
          im.classList.add("image-broken");
          im.alt = "预览加载失败，可打开原图检查";
        },
        { once: true },
      );
      const info = node("div", "image-caption");
      info.append(
        node("strong", "", x.w.title || "未命名作品"),
        node(
          "small",
          "",
          (x.w.user || "账号待补全") +
            (x.a.width && x.a.height ? ` · ${x.a.width} × ${x.a.height}` : "") +
            (x.a.kind === "cover" ? " · 封面" : ""),
        ),
      );
      const link = node("a", "image-open", "原图 ↗");
      link.href = x.a.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      card.append(im, label, info, link);
      $("image-grid").append(card);
    }
    renderImageCounts();
    $("image-batch-scope").textContent = scopeText();
    $("image-grab-batch").disabled = !targets().length;
    const jobs = getState().jobs.filter(
      (j) =>
        j.kind === "parse" &&
        j.mediaKinds?.length === 1 &&
        j.mediaKinds[0] === "image",
    );
    const active = jobs.filter((j) =>
        ["pending", "processing"].includes(j.state),
      ).length,
      attention = jobs.filter((j) => j.state === "attention").length;
    $("image-jobs-status").textContent = active
      ? `正在抓取 ${active} 条作品，图片会自动出现在预览区。`
      : attention
        ? `${attention} 条图集任务需要处理，可到“跨平台检索”查看原因。`
        : "";
  }
  function renderImageCounts() {
    const entries = imageEntries(),
      count = entries.filter((x) => selectedImages.has(x.key)).length;
    $("image-selected-count").textContent =
      `已选 ${count} / ${entries.length} 张`;
    $("image-select-all").checked =
      !!entries.length && count === entries.length;
    $("image-select-all").indeterminate = count > 0 && count < entries.length;
    $("image-download").disabled = !count;
  }
  const downloadWorks = () =>
    document.querySelector('input[name="download-scope"]:checked')?.value ===
    "all"
      ? getState().works
      : targets();
  const downloadKinds = () =>
    [
      $("download-images").checked ? "image" : null,
      $("download-videos").checked ? "video" : null,
      $("download-covers").checked ? "cover" : null,
    ].filter(Boolean);
  function renderDownload() {
    const works = downloadWorks(),
      kinds = downloadKinds(),
      plan = buildDownloadPlan(works, {
        includeCovers: $("download-covers").checked,
        mediaKinds: kinds,
      }),
      assets = plan.assets,
      missing = plan.pending;
    $("plan-works").textContent = works.length;
    $("plan-images").textContent = assets.filter((x) =>
      ["image", "cover"].includes(x.asset.kind),
    ).length;
    $("plan-videos").textContent = assets.filter(
      (x) => x.asset.kind === "video",
    ).length;
    $("plan-pending").textContent = missing.length;
    $("download-plan-summary").textContent =
      `${works.length} 条作品，当前可下载 ${assets.length} 个文件${missing.length ? `；${missing.length} 条作品会先解析所选类型的资源` : ""}${plan.skipped.length ? `；${plan.skipped.length} 条不含可用的所选类型，已跳过` : ""}。`;
    $("download-preview").replaceChildren();
    for (const w of works.slice(0, 8)) {
      const row = node("div", "plan-row");
      row.append(
        node("strong", "", w.title || "未命名作品"),
        node(
          "span",
          "",
          `${names[w.platform]} · ${w.user || "账号待补全"} · ${assets.filter((x) => x.work.id === w.id).length} 个文件`,
        ),
      );
      $("download-preview").append(row);
    }
    if (works.length > 8)
      $("download-preview").append(
        node("p", "muted", `还有 ${works.length - 8} 条作品…`),
      );
    $("download-start").disabled = !works.length || !kinds.length;
    $("download-start-label").textContent = works.length
      ? `准备保存 ${works.length} 条作品`
      : "先去素材库收录或选择作品";
  }
  function renderUpdate() {
    const available = getState().update?.available;
    if (available && available !== update.available) {
      update = {
        ...update,
        available,
        message: `新版 ${available} 已下载，刷新后启用。`,
      };
    }
    $("installed-version").textContent =
      "当前版本 " + (update.version || "4.1.0");
    $("install-channel").textContent = update.development
      ? "本地测试版 · 需手动替换文件"
      : update.installType === "normal"
        ? "正式安装 · 支持浏览器更新"
        : "安装来源待确认";
    $("update-status").textContent =
      update.message ||
      (update.available
        ? `新版 ${update.available} 已下载，刷新后启用。`
        : update.development
          ? "本地解压版可通过安装包更新：覆盖原目录，再重新加载。刷新工作台数据不会取得远程新代码。"
          : "浏览器会自动检查已发布版本，也可在这里手动检查。");
    $("update-apply").disabled = !update.available;
    $("update-apply").textContent = update.available
      ? "刷新启用 " + update.available
      : "刷新启用新版";
  }
  async function refreshUpdate() {
    return run(async () => {
      const r = await send("UPDATE_INFO");
      update = r.update;
      renderUpdate();
    });
  }
  $("auto-enabled").addEventListener("change", () =>
    run(() => send("SETTINGS", { autoCapture: $("auto-enabled").checked })),
  );
  $("auto-notice").addEventListener("change", () =>
    run(() => send("SETTINGS", { autoNotice: $("auto-notice").checked })),
  );
  $("auto-current").addEventListener("click", () =>
    run(async () => {
      const tabs = await refreshTabs(),
        s = getState(),
        tab =
          tabs.find((t) => t.active) ||
          tabs.find((t) => t.id === s.autoLast?.tabId) ||
          tabs[0];
      if (!tab) throw new Error("请先打开作品页面");
      const r = await send("CAPTURE", { tabId: tab.id, mode: "detail" });
      toast(r.message || "已识别当前作品");
    }, $("auto-current")),
  );
  $("category-add").addEventListener("click", () =>
    run(async () => {
      await send("CATEGORY", { action: "add", name: $("category-new").value });
      $("category-new").value = "";
      toast("已新增分类");
    }, $("category-add")),
  );
  $("category-assign").addEventListener("click", () =>
    run(async () => {
      const ids = targets().map((w) => w.id);
      await send("CATEGORY", {
        action: "assign",
        name: $("category-target").value,
        ids,
      });
      toast(`已将 ${ids.length} 条作品归入所选分类`);
    }, $("category-assign")),
  );
  $("category-cancel").addEventListener("click", () =>
    $("category-confirm").close(),
  );
  $("category-confirm-delete").addEventListener("click", () =>
    run(async () => {
      await send("CATEGORY", { action: "delete", name: deleteCategory });
      $("category-confirm").close();
      toast("分类已删除，作品已移入未分类");
    }),
  );
  $("image-refresh-tabs").addEventListener("click", () =>
    run(refreshTabs, $("image-refresh-tabs")),
  );
  $("image-grab-page").addEventListener("click", () =>
    run(async () => {
      if (!$("image-tab").value) await refreshTabs();
      if (!$("image-tab").value) throw new Error("请先打开图片来源网页");
      const r = await send("GRAB_IMAGES", {
        tabId: Number($("image-tab").value),
        scope: $("image-mode").value,
        minWidth: Number($("image-min").value),
      });
      imageIds = r.grabbedWorkIds || [];
      $("image-scope").value = "recent";
      renderImages();
      toast(`已抓取 ${r.grabbed} 张图片，请勾选后下载`);
    }, $("image-grab-page")),
  );
  $("image-grab-batch").addEventListener("click", () =>
    run(async () => {
      const r = await send("PARSE", {
        ids: targets().map((w) => w.id),
        mediaKinds: ["image"],
      });
      $("image-scope").value = "targets";
      renderImages();
      toast(`已提交 ${r.queued} 条图集抓取任务`);
    }, $("image-grab-batch")),
  );
  for (const id of ["image-scope", "image-covers"])
    $(id).addEventListener("change", renderImages);
  $("image-select-all").addEventListener("change", () => {
    for (const x of imageEntries())
      $("image-select-all").checked
        ? selectedImages.add(x.key)
        : selectedImages.delete(x.key);
    renderImages();
  });
  $("image-download").addEventListener("click", () =>
    run(async () => {
      const keys = imageEntries()
        .filter((x) => selectedImages.has(x.key))
        .map((x) => x.key);
      const r = await send("DOWNLOAD_ASSETS", { keys });
      toast(
        `已加入 ${r.queued} 张图片${r.skipped ? `，跳过 ${r.skipped} 个已有任务` : ""}`,
      );
      setView("queue");
    }, $("image-download")),
  );
  for (const input of document.querySelectorAll(
    'input[name="download-scope"],#download-images,#download-videos,#download-covers',
  ))
    input.addEventListener("change", renderDownload);
  $("download-start").addEventListener("click", () =>
    run(async () => {
      const r = await send("DOWNLOAD", {
        ids: downloadWorks().map((w) => w.id),
        mediaKinds: downloadKinds(),
        includeCovers: $("download-covers").checked,
      });
      toast(
        `已加入 ${r.queued} 个文件${r.parsing ? `，${r.parsing} 条作品先解析后下载` : ""}${r.skipped ? `，跳过 ${r.skipped} 个已有任务` : ""}${r.unsupported ? `，${r.unsupported} 条没有所选类型的可用资源` : ""}`,
      );
      setView("queue");
    }, $("download-start")),
  );
  $("update-check").addEventListener("click", () =>
    run(async () => {
      const r = await send("UPDATE_CHECK");
      update = r.update;
      renderUpdate();
      toast(update.message);
    }, $("update-check")),
  );
  $("update-apply").addEventListener("click", () =>
    run(async () => {
      await send("UPDATE_APPLY");
      toast("正在启用新版，扩展将重新加载。");
    }, $("update-apply")),
  );
  $("workspace-refresh").addEventListener("click", () => location.reload());
  return {
    refreshUpdate,
    render() {
      renderAuto();
      if (getView() === "categories") renderCategories();
      if (getView() === "images") renderImages();
      if (getView() === "download") renderDownload();
      if (getView() === "updates") renderUpdate();
    },
  };
}
