export function applyResolvedNote(row, page) {
  const accountName = (page.accountName || page.user || "").trim();
  return {
    ...row,
    url: page.url || row.url,
    title: row.title || page.title || "",
    user: accountName || row.user,
    status: "resolved",
  };
}
export function isNoteUrl(value) {
  try {
    const u = new URL(value);
    if (
      !["https:", "http:"].includes(u.protocol) ||
      u.username ||
      u.password ||
      u.port
    )
      return false;
    const host = u.hostname.toLowerCase();
    if (host === "xhslink.com" || host === "www.xhslink.com")
      return u.pathname.length > 1;
    return (
      (host === "xiaohongshu.com" || host === "www.xiaohongshu.com") &&
      /^\/(explore|discovery\/item|search_result)\/[a-zA-Z0-9]+\/?$/.test(
        u.pathname,
      )
    );
  } catch {
    return false;
  }
}
export function noteKey(value) {
  try {
    const u = new URL(value);
    const id = u.pathname.match(
      /\/(?:explore|discovery\/item|search_result)\/([a-zA-Z0-9]+)/,
    )?.[1];
    return id
      ? "note:" + id.toLowerCase()
      : u.hostname.toLowerCase().replace(/^www\./, "") +
          u.pathname.replace(/\/$/, "");
  } catch {
    return value;
  }
}
const clean = (s) => s.replace(/\s+/g, " ").trim();
const cleanTitle = (s) =>
  clean(s)
    .replace(/\s*[-|｜]\s*小红书.*$/, "")
    .replace(/^\d+\s+/, "")
    .trim();
const unescapeShare = (s) => s.replace(/\\([:/.?=&_#%\-])/g, "$1");
export function splitShareHeading(value) {
  const wrapped = [
    ...value.matchAll(
      /[【\[]([\s\S]*?)[|｜]\s*小红书(?:\s*[-—]\s*[^】\]\r\n]*)?[】\]]/g,
    ),
  ].at(-1);
  const plain = wrapped
    ? null
    : value.match(
        /(?:^|\n)\s*(?:\d+\s+)?([^\r\n]+?)[|｜]\s*小红书(?:\s*[-—]\s*[^\r\n😆]*)?/,
      );
  const heading = (wrapped?.[1] || plain?.[1] || "").trim();
  if (!heading) return null;
  const separators = [...heading.matchAll(/\s+[-—–]\s+/g)];
  const separator = separators.at(-1);
  if (!separator || separator.index === undefined) return null;
  const title = heading.slice(0, separator.index).trim(),
    user = heading.slice(separator.index + separator[0].length).trim();
  return title && user ? { title, user } : null;
}
function fromObject(x) {
  if (!x || typeof x !== "object") return null;
  const rawUrl = x.url || x.link || x["素材地址"],
    url = typeof rawUrl === "string" ? unescapeShare(rawUrl) : "",
    title = x.title || x["标题"],
    share = typeof title === "string" ? splitShareHeading(title) : null,
    user =
      x.accountName ||
      x["账号名字"] ||
      x["账号昵称"] ||
      x.user ||
      x.author ||
      x["博主网名"] ||
      x["博主昵称"] ||
      x["用户"] ||
      share?.user;
  return isNoteUrl(url)
    ? {
        id: "",
        url,
        title:
          share?.title ||
          (typeof title === "string"
            ? clean(title).replace(/\s*[-|｜]\s*小红书.*$/, "")
            : ""),
        user: typeof user === "string" ? clean(user) : "",
      }
    : null;
}
export function parseInput(raw) {
  const text = raw.trim();
  if (!text) return [];
  try {
    const d = JSON.parse(text);
    const a = Array.isArray(d) ? d : Array.isArray(d?.rows) ? d.rows : [d];
    const notes = a.map(fromObject).filter((n) => !!n);
    if (notes.length) return notes;
  } catch {}
  const normalized = unescapeShare(text);
  const tsv = normalized
    .split(/\r?\n/)
    .filter((l) => l.includes("\t"))
    .map((l) => {
      const [url, title = "", user = ""] = l.split("\t");
      return fromObject({ url: url.trim(), title, user });
    })
    .filter((n) => !!n);
  if (tsv.length) return tsv;
  const result = [];
  for (const block of normalized.split(/\n\s*\n/)) {
    const urls = [
      ...block.matchAll(
        /https?:\/\/[^\s<>"'\u3000\uFF0C\u3002\uFF01\uFF1F\uFF1B\uFF09\u300B\u3011]+/gi,
      ),
    ]
      .map((m) => ({
        raw: m[0],
        index: m.index || 0,
        url: m[0].replace(/[)\],;.]+$/, ""),
      }))
      .filter((m) => isNoteUrl(m.url));
    let lastEnd = 0;
    for (const m of urls) {
      const prefix = block.slice(lastEnd, m.index),
        suffix = urls.length === 1 ? block.slice(m.index + m.raw.length) : "",
        context = prefix + "\n" + suffix;
      let title =
          context.match(
            /(?:^|\n)\s*(?:标题|笔记标题|title)\s*[:：]\s*([^\n]+)/i,
          )?.[1] || "",
        user =
          context.match(
            /(?:^|\n)\s*(?:账号名字|账号昵称|账号名称|博主网名|博主昵称|发布者|用户|作者|博主|昵称|user|author)\s*[:：]\s*([^\n]+)/i,
          )?.[1] || "";
      const explicitlyLabeled = !!title;
      const share = splitShareHeading(prefix);
      if (share) {
        title = share.title;
        user = share.user;
      }
      if (!user)
        user =
          context.match(
            /(?:^|\n)\s*([^\n]{1,40}?)\s*发布了一篇(?:小红书)?笔记/,
          )?.[1] || "";
      if (!title) {
        title =
          prefix.match(/\[([^\]\n]+)\]\($/)?.[1] ||
          prefix
            .split(/\n/)
            .map((v) => v.trim())
            .filter(
              (v) =>
                v &&
                !/(?:复制|打开|发布了一篇|快来看|小红书APP|http[s]?:|^(账号名字|账号昵称|账号名称|博主网名|博主昵称|发布者|用户|作者|博主|昵称|链接|素材地址)\s*[:：]|^-+$)/i.test(
                  v,
                ),
            )
            .join(" ")
            .replace(/\s*[😆😀].*$/u, "")
            .trim();
      }
      result.push({
        id: "",
        url: m.url,
        title: share || explicitlyLabeled ? clean(title) : cleanTitle(title),
        user: clean(user),
      });
      lastEnd = m.index + m.raw.length;
    }
  }
  return result;
}
export function toTsv(rows, headers = false) {
  const safe = (s) => s.replace(/[\t\r\n]+/g, " ").replace(/^[=+@-]/, "'$&");
  const matrix = rows.map((r) => [r.url, r.title, r.user]);
  if (headers) matrix.unshift(["素材地址", "标题", "用户"]);
  return matrix.map((row) => row.map(safe).join("\t")).join("\n");
}
