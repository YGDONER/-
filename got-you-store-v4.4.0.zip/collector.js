// Serialized into the page by chrome.scripting; deliberately self-contained.
export async function collectPage(options = {}) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  if (options.settle !== false) await sleep(1200);
  const absolute = (raw) => {
    if (typeof raw !== "string" || !raw.trim()) return "";
    try {
      const u = new URL(raw, location.href);
      return ["https:", "http:"].includes(u.protocol) &&
        !u.username &&
        !u.password
        ? u.href
        : "";
    } catch {
      return "";
    }
  };
  const platform = (raw = location.href) => {
    const h = new URL(raw).hostname,
      host = (d) => h === d || h.endsWith("." + d);
    return host("pinterest.com") ||
      host("pin.it") ||
      /^([\w-]+\.)?pinterest\.(co\.uk|fr|de|jp|ca|com\.au|es|it)$/.test(h)
      ? "pinterest"
      : host("xiaohongshu.com") || host("xhslink.com")
        ? "xhs"
        : host("instagram.com")
          ? "instagram"
          : host("douyin.com")
            ? "douyin"
            : host("yangkeduo.com") || host("pinduoduo.com")
              ? "pdd"
              : host("vip.com")
                ? "vip"
                : host("tmall.com")
                  ? "tmall"
                  : host("taobao.com") || host("tb.cn")
                    ? "taobao"
                    : "web";
  };
  const detail = (raw) => {
    try {
      const u = new URL(raw),
        p = platform(raw);
      return p === "xhs"
        ? /\/(explore|discovery\/item|search_result)\/[\w-]+/.test(u.pathname)
        : p === "instagram"
          ? /^\/(?:[\w.]+\/)?(?:p|reels?|tv)\/[\w-]+(?:\/|$)/.test(u.pathname)
          : p === "douyin"
            ? /\/(video|note)\/\d+/.test(u.pathname) ||
              u.searchParams.has("modal_id")
            : p === "pinterest"
              ? /\/pin\/(?:[^/]*--)?\d+/.test(u.pathname)
              : p === "pdd"
                ? /\/goods[\w-]*\.html/.test(u.pathname) &&
                  /^\d+$/.test(u.searchParams.get("goods_id") || "")
                : p === "vip"
                  ? /\/(?:detail|product)-(?:\d+-)?\d+\.html/.test(
                      u.pathname,
                    ) ||
                    (/\/(?:product|detail)\.html/.test(u.pathname) &&
                      /^\d+$/.test(
                        u.searchParams.get("product_id") ||
                          u.searchParams.get("goods_id") ||
                          "",
                      ))
                  : p === "taobao" || p === "tmall"
                    ? /item\.htm/.test(u.pathname) && u.searchParams.has("id")
                    : false;
    } catch {
      return false;
    }
  };
  const text = (selector) =>
    (document.querySelector(selector)?.textContent || "").trim();
  const meta = (name) =>
    document.querySelector(`meta[property="${name}"],meta[name="${name}"]`)
      ?.content || "";
  const visible = (el) => !!el && el.getClientRects().length > 0;
  const p = platform(),
    url = new URL(location.href);
  const limit = Math.max(1, Math.min(Number(options.limit) || 60, 200));
  if (
    /安全验证|人机验证|Just a moment|Access Denied|Verify you are human/i.test(
      document.title,
    )
  )
    return {
      works: [],
      message: "页面要求验证，请在该标签页处理后重新采集。",
      blocked: true,
    };
  const list = new Map();
  function readList() {
    for (const a of document.querySelectorAll("a[href]")) {
      if (list.size >= limit) break;
      let link = absolute(a.href);
      if (!link || !detail(link) || platform(link) !== p) continue;
      const u = new URL(link);
      if (p === "douyin" && u.searchParams.get("modal_id"))
        link = "https://www.douyin.com/video/" + u.searchParams.get("modal_id");
      const card =
        a.closest(
          'section,article,[data-test-id="pin"],[data-e2e="search-result"],li,[class*="note-item"],[class*="Card"],[class*="card"]',
        ) || a;
      const title = (
        a.getAttribute("title") ||
        a.getAttribute("aria-label") ||
        card.querySelector('[class*="title"],[class*="desc"],h2,h3')
          ?.textContent ||
        a.querySelector("img")?.alt ||
        a.textContent ||
        ""
      )
        .trim()
        .slice(0, 200);
      const user = (
        card.querySelector(
          '[class*="author"] [class*="name"],[class*="nickname"],[class*="user-name"],[class*="userName"],[class*="shopName"]',
        )?.textContent || ""
      )
        .trim()
        .slice(0, 100);
      const img = card.querySelector("img");
      const cover = absolute(img?.currentSrc || img?.src || "");
      if (!list.has(link))
        list.set(link, {
          url: link,
          title,
          user,
          platform: p,
          source: "search-list",
          media: cover ? [{ url: cover, kind: "cover" }] : [],
        });
    }
  }
  const isCurrentDetail =
    options.mode === "detail" ||
    detail(location.href) ||
    (p === "web" && options.mode !== "list");
  if (!isCurrentDetail) {
    const original = [window.scrollX, window.scrollY];
    const rounds = Math.min(5, Math.max(0, Number(options.rounds) || 0));
    try {
      for (let i = 0; i <= rounds; i++) {
        readList();
        if (i < rounds && list.size < limit) {
          window.scrollBy(0, window.innerHeight * 0.9);
          await sleep(750);
        }
      }
    } finally {
      if (rounds) window.scrollTo(...original);
    }
    const works = [...list.values()];
    const login =
      /登录后查看|登录后搜索|请先登录|Log in to continue|Sign up to see more/i.test(
        (document.body?.innerText || "").slice(0, 12000),
      );
    return {
      works,
      message: works.length
        ? `收集 ${works.length} 个结果，选中后可批量解析或一键下载。`
        : login
          ? "请在此标签页登录后重新采集。"
          : "当前没有已渲染的作品链接，请向下滚动或等待加载后重试。",
      blocked: !works.length && login,
    };
  }
  let title = "",
    user = "",
    media = [],
    notes = [],
    instagramScope = null;
  const add = (raw, kind = "image", extra = {}) => {
    const link = absolute(raw);
    if (link) media.push({ url: link, kind, ...extra });
  };
  const unwrap = (o) =>
    o && typeof o === "object" && "_value" in o ? o._value : o;
  const roots = [];
  for (const key of [
    "__INITIAL_STATE__",
    "_ROUTER_DATA",
    "__NEXT_DATA__",
    "__PWS_DATA__",
    "__PWS_INITIAL_PROPS__",
    "__INIT_DATA__",
    "__ICE_APP_CONTEXT__",
    "rawData",
    "__STORE__",
    "__PRELOADED_STATE__",
    "__INITIAL_DATA__",
    "__NUXT__",
    "_sharedData",
    "__additionalData",
  ])
    try {
      if (window[key]) roots.push(unwrap(window[key]));
    } catch {}
  for (const el of document.querySelectorAll(
    'script#__NEXT_DATA__,script#RENDER_DATA,script#__PWS_DATA__,script[data-relay-response="true"],script[type="application/json"][data-sjs]',
  ))
    try {
      const raw = el.textContent || "";
      if (raw.length < 5000000)
        roots.push(
          JSON.parse(el.id === "RENDER_DATA" ? decodeURIComponent(raw) : raw),
        );
    } catch {}
  try {
    const preload = document.querySelector('meta[name="preload-data"]');
    if (preload?.content) roots.push(JSON.parse(preload.content));
  } catch {}
  function walk(objects, predicate) {
    const found = [],
      seen = new WeakSet();
    let count = 0;
    const stack = [...objects];
    while (stack.length && count++ < 16000) {
      let o = unwrap(stack.pop());
      if (!o || typeof o !== "object" || seen.has(o)) continue;
      seen.add(o);
      if (predicate(o)) found.push(o);
      for (const v of Object.values(o))
        if (v && typeof v === "object") stack.push(v);
    }
    return found;
  }
  if (p === "xhs") {
    const id = url.pathname.split("/").filter(Boolean).pop();
    const state = unwrap(window.__INITIAL_STATE__);
    const map = unwrap(unwrap(state?.note)?.noteDetailMap);
    const entry = unwrap(map?.[id]);
    const n =
      unwrap(entry?.note || entry) ||
      walk(roots, (o) => o.noteId === id && o.user)[0];
    if (options.identityOnly && map && !n)
      return { works: [], message: "正在等待当前作品数据加载" };
    if (n) {
      title = n.title || n.desc || "";
      const author = unwrap(n.user);
      user = author?.nickname || author?.nickName || "";
      for (const image of n.imageList || [])
        add(
          image.urlDefault || image.url || image.urlPre,
          n.video ? "cover" : "image",
          { width: image.width, height: image.height },
        );
      const stream = n.video?.media?.stream;
      const videos = [...(stream?.h264 || []), ...(stream?.h265 || [])].sort(
        (a, b) =>
          (b.width * b.height || b.avgBitrate || 0) -
          (a.width * a.height || a.avgBitrate || 0),
      );
      if (videos[0])
        add(
          videos[0].masterUrl || videos[0].url || videos[0].backupUrls?.[0],
          "video",
        );
      if (!videos.length) add(n.video?.url || n.video?.playUrl, "video");
    }
    if (!title) title = text("#detail-title,.note-content .title");
    if (!user)
      user = text(
        ".note-detail-mask .author-wrapper .username,.note-detail-mask .author-wrapper .name,.note-container .author-container .username",
      );
  }
  if (p === "douyin") {
    const id =
      url.pathname.match(/\/(?:video|note)\/(\d+)/)?.[1] ||
      url.searchParams.get("modal_id");
    const n = walk(
      roots,
      (o) =>
        String(o.aweme_id || o.awemeId || "") === id &&
        (o.video || o.images || o.image_post_info),
    )[0];
    if (n) {
      title = n.desc || n.caption || "";
      user = n.author?.nickname || n.authorInfo?.nickname || "";
      const rates = [...(n.video?.bit_rate || [])].sort(
        (a, b) => (b.bit_rate || 0) - (a.bit_rate || 0),
      );
      const video =
        rates[0]?.play_addr || n.video?.play_addr || n.video?.playAddr;
      add(video?.url_list?.[0] || video?.urlList?.[0], "video");
      for (const im of n.images || n.image_post_info?.images || [])
        add(
          im.url_list?.[0] || im.display_image?.url_list?.[0] || im.url,
          "image",
        );
    }
    if (!title)
      title = text('[data-e2e="video-desc"],[data-e2e="detail-video-desc"]');
    if (!user)
      user =
        text('[data-e2e="video-author-name"]') ||
        (
          document
            .querySelector('[data-e2e="detail-video"]')
            ?.querySelector('[data-e2e="user-title"]')?.textContent || ""
        ).trim();
  }
  if (p === "pinterest") {
    const id = url.pathname.match(/\/pin\/(?:[^/]*--)?(\d+)/)?.[1];
    const pins = walk(
      roots,
      (o) =>
        String(o.id || "") === id && (o.images || o.videos || o.story_pin_data),
    );
    const n = pins[0];
    if (n) {
      title = n.title || n.grid_title || n.description || "";
      user =
        n.pinner?.full_name ||
        n.pinner?.username ||
        n.native_creator?.full_name ||
        n.creator?.name ||
        "";
      const imgs = n.images || {};
      const best =
        imgs.orig ||
        Object.values(imgs)
          .filter((v) => v?.url)
          .sort((a, b) => (b.width || 0) - (a.width || 0))[0];
      if (best)
        add(
          best.url,
          Object.values(n.videos?.video_list || {}).some((v) => v?.url)
            ? "cover"
            : "image",
          { width: best.width, height: best.height },
        );
      const vs = Object.values(n.videos?.video_list || {})
        .filter((v) => v?.url)
        .sort(
          (a, b) =>
            Number(/\.(m3u8|mpd)(?:\?|$)/i.test(a.url)) -
              Number(/\.(m3u8|mpd)(?:\?|$)/i.test(b.url)) ||
            (b.width * b.height || 0) - (a.width * a.height || 0),
        );
      for (const v of vs.slice(0, 1))
        add(v.url, "video", {
          blockedReason:
            n.is_downloadable === false || n.can_download === false
              ? "作者未开放视频下载"
              : "",
        });
      for (const page of n.story_pin_data?.pages || [])
        for (const block of page.blocks || []) {
          if (block.image?.images) {
            const image =
              block.image.images.originals || block.image.images.orig;
            if (image) add(image.url, "image");
          }
          const video = Object.values(block.video?.video_list || {}).filter(
            (v) => v?.url && !/\.(m3u8|mpd)(?:\?|$)/i.test(v.url),
          )[0];
          if (video)
            add(video.url, "video", {
              blockedReason:
                n.is_downloadable === false || n.can_download === false
                  ? "作者未开放视频下载"
                  : "",
            });
        }
    }
    if (!title)
      title = text(
        '[data-test-id="pin-title"] h1,[data-test-id="pin-title"],h1',
      );
    if (!user)
      user = text(
        '[data-test-id="creator-profile-name"],[data-test-id="pin-creator-name"],[data-test-id="pinner-name"]',
      );
  }
  if (p === "instagram") {
    const code = (raw) => {
      if (typeof raw !== "string" || !raw.trim()) return "";
      try {
        return (
          new URL(raw, location.href).pathname.match(
            /^\/(?:[\w.]+\/)?(?:p|reels?|tv)\/([\w-]+)(?:\/|$)/,
          )?.[1] || ""
        );
      } catch {
        return "";
      }
    };
    const id = code(location.href),
      matches = walk(
        roots,
        (o) =>
          (o.shortcode || o.code) === id &&
          (o.owner || o.user) &&
          (o.display_url ||
            o.image_versions2 ||
            o.video_url ||
            o.video_versions ||
            o.edge_sidecar_to_children ||
            o.carousel_media),
      );
    const n = matches[0];
    const articles = [
      ...document.querySelectorAll('[role="dialog"] article,article'),
    ].filter(visible);
    instagramScope =
      articles.find((a) =>
        [...a.querySelectorAll("a[href]")].some(
          (link) => code(link.href) === id,
        ),
      ) || null;
    const canonical = meta("og:url");
    if (!instagramScope && articles.length === 1 && code(canonical) === id)
      instagramScope = articles[0];
    if (!n && !instagramScope && code(canonical) !== id)
      return {
        works: [],
        blocked: /Log in|登录|Sign up/i.test(document.title),
        message:
          "正在等待当前 Instagram 帖子加载；请打开具体帖子或 Reels，并检查登录状态。",
      };
    if (n) {
      const owner = n.owner || n.user;
      user = owner.full_name || owner.fullName || owner.username || "";
      title =
        n.edge_media_to_caption?.edges?.[0]?.node?.text ||
        n.caption?.text ||
        n.accessibility_caption ||
        "";
      const children = n.edge_sidecar_to_children?.edges
        ?.map((e) => e.node)
        .filter(Boolean) ||
        n.carousel_media || [n];
      for (const item of children) {
        const isVideo =
          item.is_video === true ||
          item.media_type === 2 ||
          !!item.video_url ||
          !!item.video_versions?.length;
        const images = (
          item.image_versions2?.candidates ||
          item.display_resources ||
          []
        )
          .filter((i) => i?.url || i?.src)
          .sort(
            (a, b) =>
              (b.width || b.config_width || 0) *
                (b.height || b.config_height || 0) -
              (a.width || a.config_width || 0) *
                (a.height || a.config_height || 0),
          );
        const image = images[0];
        add(
          image?.url || image?.src || item.display_url || item.thumbnail_src,
          isVideo ? "cover" : "image",
          {
            width:
              image?.width || image?.config_width || item.dimensions?.width,
            height:
              image?.height || image?.config_height || item.dimensions?.height,
          },
        );
        if (isVideo) {
          const videos = (item.video_versions || [])
            .filter((v) => v?.url)
            .sort(
              (a, b) => (b.width * b.height || 0) - (a.width * a.height || 0),
            );
          add(videos[0]?.url || item.video_url, "video");
          if (!videos.length && !item.video_url)
            notes.push("该视频尚未提供可保存的文件直链");
        }
      }
    }
    if (instagramScope) {
      const ownerLink = instagramScope.querySelector("header a[href]");
      if (!user && ownerLink) {
        try {
          const path = new URL(ownerLink.href, location.href).pathname;
          if (
            /^\/[\w.]+\/?$/.test(path) &&
            !/^\/(?:accounts|explore|direct|reels)\/?$/.test(path)
          )
            user = (ownerLink.textContent || path.replace(/\//g, "")).trim();
        } catch {}
      }
      if (!title)
        title = (instagramScope.querySelector("h1")?.textContent || "").trim();
      if (!n) {
        for (const video of instagramScope.querySelectorAll("video")) {
          const src =
            video.currentSrc || video.src || video.querySelector("source")?.src;
          if (/^blob:/.test(src || ""))
            notes.push("播放器是 Blob / 分段源，未得到可直接保存的视频文件");
          else add(src, "video");
          add(video.poster, "cover");
        }
        for (const image of instagramScope.querySelectorAll("img")) {
          const width = image.naturalWidth || image.width || 0,
            height = image.naturalHeight || image.height || 0;
          if (
            Math.max(width, height) < 160 ||
            image.closest(
              'header,[class*="avatar"],[class*="Avatar"],[class*="comment"],[class*="recommend"]',
            )
          )
            continue;
          add(
            image.currentSrc || image.src,
            media.some((m) => m.kind === "video") ? "cover" : "image",
            { width, height },
          );
        }
        notes.push(
          "当前图集来自本帖已加载的媒体；可切换轮播后重新识别补充图片",
        );
      }
    }
    const og = meta("og:title"),
      match = og.match(/^(.+?)\s+on Instagram:\s*[“"]?([\s\S]*)$/i);
    if (match) {
      if (!user) user = match[1].trim();
      if (!title) title = match[2].replace(/[”"]$/, "").trim();
    }
  }
  if (p === "taobao" || p === "tmall") {
    title =
      text('#J_Title h3,[class*="ItemTitle"],[class*="itemTitle"],h1') ||
      meta("og:title");
    user = text(
      '[class*="ShopHeader"] [class*="name"],[class*="shopName"],.tb-shop-name a,.shop-name-link',
    );
    const gallery = document.querySelector(
      '[class*="PicGallery"],[class*="mainPic"],[class*="picGallery"],#J_DivItemDesc,.tb-gallery',
    );
    if (gallery)
      for (const im of gallery.querySelectorAll("img")) {
        const src = im.currentSrc || im.src || im.getAttribute("data-src");
        if ((im.naturalWidth || im.width || 200) >= 120) add(src, "image");
      }
  }
  if (p === "pdd" || p === "vip") {
    const id =
      p === "pdd"
        ? url.searchParams.get("goods_id")
        : url.pathname.match(
            /\/(?:detail|product)-(?:\d+-)?(\d+)\.html/,
          )?.[1] ||
          url.searchParams.get("product_id") ||
          url.searchParams.get("goods_id");
    const matches = walk(
      roots,
      (o) =>
        String(o.goods_id || o.goodsId || o.product_id || o.productId || "") ===
          id &&
        (o.goods_name ||
          o.goodsName ||
          o.productName ||
          o.gallery ||
          o.productImages),
    );
    const n = matches[0];
    if (n) {
      title = n.goods_name || n.goodsName || n.productName || n.title || "";
      if (p === "pdd") {
        const mall = n.mall || n.mall_info || n.mallInfo;
        user =
          n.mall_name || n.mallName || mall?.mall_name || mall?.mallName || "";
        if (!user && n.mall_id) {
          const shop = walk(
            roots,
            (o) =>
              String(o.mall_id || o.mallId || "") === String(n.mall_id) &&
              (o.mall_name || o.mallName),
          )[0];
          user = shop?.mall_name || shop?.mallName || "";
        }
      } else
        user =
          n.shopName ||
          n.merchantName ||
          n.vendorName ||
          n.shop?.shopName ||
          "";
      const gallery =
        n.gallery ||
        n.goods_gallery ||
        n.images ||
        n.imageList ||
        n.mainImages ||
        n.productImages ||
        n.imgList ||
        [];
      const rows = Array.isArray(gallery) ? gallery : Object.values(gallery);
      for (const image of rows) {
        if (!image) continue;
        add(
          typeof image === "string"
            ? image
            : image.url ||
                image.img_url ||
                image.imageUrl ||
                image.image_url ||
                image.src,
          "image",
          { width: image?.width, height: image?.height },
        );
      }
      add(
        n.video_url || n.videoUrl || n.video?.url || n.video?.playUrl,
        "video",
      );
    }
    if (!title)
      title = text(
        p === "pdd"
          ? 'h1,[class*="goodsName"],[class*="goods-name"]'
          : 'h1,[class*="product-title"],[class*="productTitle"],.pib-title',
      );
    if (!user)
      user = text(
        p === "pdd"
          ? '[class*="mallName"],[class*="mall-name"],[data-testid="shop-name"]'
          : '[class*="shopName"],[class*="shop-name"],[class*="vendorName"]',
      );
    const gallery = document.querySelector(
      p === "pdd"
        ? '[class*="goods-gallery"],[class*="GoodsGallery"],[class*="swiper"],[class*="Swiper"]'
        : '[class*="product-image"],[class*="ProductImage"],.J-mer-bigImg,.pic-slider',
    );
    if (!media.some((m) => m.kind === "image") && gallery)
      for (const image of gallery.querySelectorAll("img")) {
        const width = image.naturalWidth || image.width || 0,
          height = image.naturalHeight || image.height || 0;
        if (Math.max(width, height) >= 120)
          add(
            image.currentSrc ||
              image.src ||
              image.getAttribute("data-original") ||
              image.getAttribute("data-src"),
            "image",
            { width, height },
          );
      }
  }
  const hasImage = () => media.some((m) => m.kind === "image");
  const hasVideo = () => media.some((m) => m.kind === "video");
  const scope =
    p === "instagram"
      ? { querySelectorAll: () => [] }
      : document.querySelector(
          p === "pinterest"
            ? '[data-test-id="pin-closeup"]'
            : p === "xhs"
              ? ".note-detail-mask .note-content,.note-container"
              : p === "douyin"
                ? '[data-e2e="detail-video"]'
                : p === "taobao" || p === "tmall"
                  ? '[class*="PicGallery"],.tb-gallery'
                  : p === "pdd"
                    ? '[class*="goods-gallery"],[class*="GoodsGallery"],[class*="swiper"],[class*="Swiper"]'
                    : p === "vip"
                      ? '[class*="product-image"],[class*="ProductImage"],.J-mer-bigImg,.pic-slider'
                      : "main,article",
        ) || document;
  if (!hasVideo())
    for (const video of scope.querySelectorAll("video")) {
      const src =
        video.currentSrc || video.src || video.querySelector("source")?.src;
      if (/^blob:/.test(src || ""))
        notes.push("播放器是 Blob / 分段源，未得到可直接保存的视频文件");
      else add(src, "video");
      if (video.poster) add(video.poster, "cover");
    }
  if (!hasImage() && !hasVideo())
    for (const im of scope.querySelectorAll("img")) {
      const width = im.naturalWidth || im.width || 0,
        height = im.naturalHeight || im.height || 0;
      if (
        (width >= 160 || height >= 160) &&
        !im.closest(
          '[class*="avatar"],[class*="Avatar"],[class*="recommend"],[data-test-id="related-pins"]',
        )
      )
        add(im.currentSrc || im.src || im.getAttribute("data-src"), "image", {
          width,
          height,
        });
      if (media.length >= 200) break;
    }
  if (!title)
    title =
      meta("og:title") ||
      document.title.replace(
        /\s*[-|｜]\s*(小红书|抖音|Pinterest|Instagram|淘宝|天猫|拼多多|唯品会).*$/i,
        "",
      );
  if (!user && p !== "instagram") {
    const author = meta("author") || meta("article:author");
    if (author && !/^https?:/i.test(author)) user = author;
  }
  if (!hasVideo() && !hasImage())
    add(meta("og:video:url") || meta("og:video"), "video");
  if (!media.length || (hasVideo() && !media.some((m) => m.kind === "cover")))
    add(meta("og:image"), "cover");
  if (p === "xhs") {
    const caption = (meta("og:title") || document.title).split(
      /\s*[|｜]\s*小红书/,
    )[0];
    const cut = [...caption.matchAll(/\s+-\s+/g)].pop();
    if (cut) {
      if (!user) user = caption.slice(cut.index + cut[0].length).trim();
      if (!title || title === caption || title === document.title)
        title = caption.slice(0, cut.index).trim();
    }
  }
  if (
    /安全验证|验证码|页面不存在|Access Denied|^(登录|注册|Log in|Sign up)(?:$|\s*[-|｜])/i.test(
      title,
    )
  )
    return {
      works: [],
      blocked: true,
      message: "页面没有可读取的作品，请在标签页检查登录、验证或访问状态。",
    };
  return {
    works: [
      {
        url: location.href,
        platform: p,
        title: String(title).trim(),
        user: String(user).trim(),
        media,
        source: "page-detail",
        error: notes.join("；"),
      },
    ],
    message: media.length
      ? `识别到 ${media.length} 项页面资源`
      : "已保存链接信息，未发现可直接下载的图片或视频。",
  };
}

// Whole-page image browser. Runs only on an explicit click in the image tool.
export function collectPageImages(options = {}) {
  const min = Math.max(50, Number(options.minWidth) || 200),
    limit = Math.min(500, Number(options.limit) || 300),
    seen = new Set(),
    media = [];
  const root = options.wholePage
    ? document
    : document.querySelector('main,article,[role="main"]') || document;
  for (const im of root.querySelectorAll("img")) {
    if (media.length >= limit) break;
    const width = im.naturalWidth || im.width || 0,
      height = im.naturalHeight || im.height || 0;
    if (
      Math.max(width, height) < min ||
      im.closest(
        '[class*="avatar"],[class*="Avatar"],[class*="emoji"],nav,header',
      )
    )
      continue;
    let src =
      im.currentSrc ||
      im.src ||
      im.getAttribute("data-original") ||
      im.getAttribute("data-src");
    if (!src) continue;
    try {
      const u = new URL(src, location.href);
      if (
        !["https:", "http:"].includes(u.protocol) ||
        u.username ||
        u.password ||
        seen.has(u.href)
      )
        continue;
      seen.add(u.href);
      media.push({ url: u.href, kind: "image", width, height });
    } catch {}
  }
  return {
    works: media.length
      ? [
          {
            url: location.href,
            title:
              document.querySelector('meta[property="og:title"]')?.content ||
              document.title,
            user: "",
            media,
            source: "page-images",
          },
        ]
      : [],
    message: media.length
      ? `已抓取 ${media.length} 张已加载图片`
      : "没有符合尺寸的图片，请先加载图片或调低最小尺寸。",
  };
}
