import {httpUrl,platformOf,isDetail,workKey} from './core.js';

// Reference search uses only the selected platform's own webpage.
export const NATIVE_SEARCH={
 pinterest:{home:'https://www.pinterest.com/',status:'detect',hint:'检查站内图片搜索入口；入口可用时提交选中的参考画面'},
 instagram:{home:'https://www.instagram.com/explore/',status:'unverified',hint:'尚未确认 ins 网页端提供参考图上传检索入口；支持帖子收录、挑图下载和独立关键词检索'},
 xhs:{home:'https://www.xiaohongshu.com/explore',status:'detect',hint:'打开小红书检查原生搜图入口；若网页未开放入口，将显示待处理'},
 douyin:{home:'https://www.douyin.com/',status:'detect',hint:'检查抖音网页的原生搜图入口；是否可用取决于当前页面'},
 taobao:{home:'https://s.taobao.com/',status:'detect',hint:'检查淘宝网页的原生图片检索入口'},
 tmall:{home:'https://list.tmall.com/',status:'detect',hint:'检查天猫网页的原生图片检索入口，不跳转到其他平台'},
 pdd:{home:'https://mobile.yangkeduo.com/',status:'detect',hint:'检查拼多多网页的原生图片检索入口'},
 vip:{home:'https://www.vip.com/',status:'detect',hint:'检查唯品会网页的原生图片检索入口'}
};
export function nativeHost(raw,platform){try{const u=new URL(raw);return u.protocol==='https:'&&!u.username&&!u.password&&platform in NATIVE_SEARCH&&platformOf(raw)===platform;}catch{return false;}}
export function selectedPlatforms(raw,mode='multi'){
 if(!Array.isArray(raw))throw new Error('请先选择搜索平台');const platforms=[...new Set(raw.filter(p=>Object.hasOwn(NATIVE_SEARCH,p)))];if(!platforms.length)throw new Error('请至少选择一个支持的平台');if(mode==='single'&&platforms.length!==1)throw new Error('指定平台模式只能选择一个平台');return platforms;
}
export function validateReference(reference,frameIds){if(!Array.isArray(frameIds))throw new Error('请选择参考画面');if(!reference||typeof reference.id!=='string'||!reference.id||!Array.isArray(reference.frames))throw new Error('请先上传参考图片或视频');const chosen=reference.frames.filter(f=>frameIds?.includes(f.id));if(!chosen.length||chosen.length>3)throw new Error('请选择 1–3 个参考画面');let bytes=0;const frames=chosen.map(f=>{if(typeof f.dataUrl!=='string'||!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(f.dataUrl)||f.dataUrl.length>1400000)throw new Error('参考画面无效或过大，请重新选择文件');bytes+=f.dataUrl.length;return {id:String(f.id).slice(0,100),dataUrl:f.dataUrl,time:Math.max(0,Number(f.time)||0),width:Math.max(1,Number(f.width)||1),height:Math.max(1,Number(f.height)||1)};});if(bytes>3500000)throw new Error('参考画面总量过大，请减少画面');return {id:reference.id.slice(0,100),name:String(reference.name||'参考素材').slice(0,180),type:reference.type==='video'?'video':'image',frames};}
export function frameTimes(duration,count=5){if(!Number.isFinite(duration)||duration<=0)throw new Error('无法读取视频时长，请更换浏览器可播放的文件');const size=Math.max(1,Math.min(8,Number(count)||5));return Array.from({length:size},(_,i)=>Math.max(0,Math.min(Math.max(0,duration-.001),duration*(i+1)/(size+1))));}
function previewDataUrl(url){return typeof url==='string'&&url.length<250000&&/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(url)?url:'';}
export function candidateKey(x){return workKey(x.url);}
export function mergeVisualCandidates(old,incoming,frameId,platforms){
 const out=old.map(x=>({...x,frameIds:[...x.frameIds]}));let previewBytes=out.reduce((n,x)=>n+(x.thumbnail?.startsWith('data:')?x.thumbnail.length:0),0);
 for(const x of incoming.slice(0,150)){const url=httpUrl(x.url);if(!url)continue;const platform=platformOf(url);if(!platforms.includes(platform)||platform!=='web'&&!isDetail(url))continue;const key=candidateKey({url}),prior=out.find(a=>a.key===key);if(prior){if(!prior.frameIds.includes(frameId))prior.frameIds.push(frameId);if(!prior.imageUrl)prior.imageUrl=httpUrl(x.imageUrl);if(!prior.thumbnail)prior.thumbnail=httpUrl(x.thumbnail)||httpUrl(x.imageUrl);continue;}
 let thumbnail=httpUrl(x.thumbnail)||previewDataUrl(x.thumbnail)||httpUrl(x.imageUrl);if(thumbnail.startsWith('data:')){if(previewBytes+thumbnail.length>512000)thumbnail=httpUrl(x.imageUrl);else previewBytes+=thumbnail.length;}
 out.push({id:key,key,url,platform,title:String(x.title||'未命名候选').slice(0,300),user:'',imageUrl:httpUrl(x.imageUrl),thumbnail,frameIds:[frameId],method:'visual',rank:out.length});if(out.length>=400)break;
 }return out.slice(0,400);
}
export function candidateWork(candidate,category='灵感参考'){const preview=httpUrl(candidate.thumbnail)||httpUrl(candidate.imageUrl);return {url:candidate.url,title:candidate.title,user:'',category,source:'visual-search',media:preview?[{url:preview,kind:'cover'}]:[]};}
